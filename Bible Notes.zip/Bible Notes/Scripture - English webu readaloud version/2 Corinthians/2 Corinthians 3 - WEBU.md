---
book: 2 Corinthians
chapter: 3
version: WEBU
---
# 2 Corinthians 3 (WEBU)

← [[2 Corinthians 2 - WEBU]] | [[2 Corinthians 4 - WEBU]] →

**1** Are we beginning again to commend ourselves? Or do we need, as do some, letters of commendation to you or from you? ^1

**2** You are our letter, written in our hearts, known and read by all men, ^2

**3** being revealed that you are a letter of Christ, served by us, written not with ink, but with the Spirit of the living God; not in tablets of stone, but in tablets that are hearts of flesh. ^3

**4** Such confidence we have through Christ toward God, ^4

**5** not that we are sufficient of ourselves to account anything as from ourselves; but our sufficiency is from God, ^5

**6** who also made us sufficient as servants of a new covenant, not of the letter but of the Spirit. For the letter kills, but the Spirit gives life. ^6

**7** But if the service of death, written engraved on stones, came with glory, so that the children of Israel could not look steadfastly on the face of Moses for the glory of his face, which was passing away, ^7

**8** won’t service of the Spirit be with much more glory? ^8

**9** For if the service of condemnation has glory, the service of righteousness exceeds much more in glory. ^9

**10** For most certainly that which has been made glorious has not been made glorious in this respect, by reason of the glory that surpasses. ^10

**11** For if that which passes away was with glory, much more that which remains is in glory. ^11

**12** Having therefore such a hope, we use great boldness of speech, ^12

**13** and not as Moses, who put a veil on his face so that the children of Israel wouldn’t look steadfastly on the end of that which was passing away. ^13

**14** But their minds were hardened, for until this very day at the reading of the old covenant the same veil remains, because in Christ it passes away. ^14

**15** But to this day, when Moses is read, a veil lies on their heart. ^15

**16** But whenever someone turns to the Lord, the veil is taken away. ^16

**17** Now the Lord is the Spirit; and where the Spirit of the Lord is, there is liberty. ^17

**18** But we all, with unveiled face seeing the glory of the Lord as in a mirror, are transformed into the same image from glory to glory, even as from the Lord, the Spirit. ^18

← [[2 Corinthians 2 - WEBU]] | [[2 Corinthians 4 - WEBU]] →
