---
book: 2 Corinthians
chapter: 10
version: WEBU
---
# 2 Corinthians 10 (WEBU)

← [[2 Corinthians 9 - WEBU]] | [[2 Corinthians 11 - WEBU]] →

**1** Now I Paul, myself, entreat you by the humility and gentleness of Christ, I who in your presence am lowly among you, but being absent am bold toward you. ^1

**2** Yes, I beg you that I may not, when present, show courage with the confidence with which I intend to be bold against some, who consider us to be walking according to the flesh. ^2

**3** For though we walk in the flesh, we don’t wage war according to the flesh; ^3

**4** for the weapons of our warfare are not of the flesh, but mighty before God to the throwing down of strongholds, ^4

**5** throwing down imaginations and every high thing that is exalted against the knowledge of God and bringing every thought into captivity to the obedience of Christ, ^5

**6** and being in readiness to avenge all disobedience when your obedience is made full. ^6

**7** Do you look at things only as they appear in front of your face? If anyone trusts in himself that he is Christ’s, let him consider this again with himself, that even as he is Christ’s, so we also are Christ’s. ^7

**8** For even if I boast somewhat abundantly concerning our authority, which the Lord gave for building you up and not for casting you down, I will not be ashamed, ^8

**9** that I may not seem as if I desire to terrify you by my letters. ^9

**10** For, “His letters”, they say, “are weighty and strong, but his bodily presence is weak, and his speech is despised.” ^10

**11** Let such a person consider this, that what we are in word by letters when we are absent, such are we also in deed when we are present. ^11

**12** For we are not bold to number or compare ourselves with some of those who commend themselves. But they themselves, measuring themselves by themselves, and comparing themselves with themselves, are without understanding. ^12

**13** But we will not boast beyond proper limits, but within the boundaries with which God appointed to us, which reach even to you. ^13

**14** For we don’t stretch ourselves too much, as though we didn’t reach to you. For we came even as far as to you with the Good News of Christ, ^14

**15** not boasting beyond proper limits in other men’s labors, but having hope that as your faith grows, we will be abundantly enlarged by you in our sphere of influence, ^15

**16** so as to preach the Good News even to the parts beyond you, not to boast in what someone else has already done. ^16

**17** But “he who boasts, let him boast in the Lord.” ^17

**18** For it isn’t he who commends himself who is approved, but whom the Lord commends. ^18

← [[2 Corinthians 9 - WEBU]] | [[2 Corinthians 11 - WEBU]] →
