---
book: 2 Corinthians
chapter: 7
version: WEBU
---
# 2 Corinthians 7 (WEBU)

← [[2 Corinthians 6 - WEBU]] | [[2 Corinthians 8 - WEBU]] →

**1** Having therefore these promises, beloved, let’s cleanse ourselves from all defilement of flesh and spirit, perfecting holiness in the fear of God. ^1

**2** Open your hearts to us. We wronged no one. We corrupted no one. We took advantage of no one. ^2

**3** I say this not to condemn you, for I have said before that you are in our hearts to die together and live together. ^3

**4** Great is my boldness of speech toward you. Great is my boasting on your behalf. I am filled with comfort. I overflow with joy in all our affliction. ^4

**5** For even when we had come into Macedonia, our flesh had no relief, but we were afflicted on every side. Fightings were outside. Fear was inside. ^5

**6** Nevertheless, he who comforts the lowly, God, comforted us by the coming of Titus, ^6

**7** and not by his coming only, but also by the comfort with which he was comforted in you while he told us of your longing, your mourning, and your zeal for me, so that I rejoiced still more. ^7

**8** For though I grieved you with my letter, I do not regret it, though I did regret it. For I see that my letter made you grieve, though just for a while. ^8

**9** I now rejoice, not that you were grieved, but that you were grieved to repentance. For you were grieved in a godly way, that you might suffer loss by us in nothing. ^9

**10** For godly sorrow produces repentance leading to salvation, which brings no regret. But the sorrow of the world produces death. ^10

**11** For behold, this same thing, that you were grieved in a godly way, what earnest care it worked in you. Yes, what defense, indignation, fear, longing, zeal, and vindication! In everything you demonstrated yourselves to be pure in the matter. ^11

**12** So although I wrote to you, I wrote not for his cause that did the wrong, nor for his cause that suffered the wrong, but that your earnest care for us might be revealed in you in the sight of God. ^12

**13** Therefore we have been comforted. In our comfort we rejoiced the more exceedingly for the joy of Titus, because his spirit has been refreshed by you all. ^13

**14** For if in anything I have boasted to him on your behalf, I was not disappointed. But as we spoke all things to you in truth, so our glorying also which I made before Titus was found to be truth. ^14

**15** His affection is more abundantly toward you, while he remembers all of your obedience, how with fear and trembling you received him. ^15

**16** I rejoice that in everything I am confident concerning you. ^16

← [[2 Corinthians 6 - WEBU]] | [[2 Corinthians 8 - WEBU]] →
