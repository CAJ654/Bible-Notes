---
book: 2 Corinthians
chapter: 12
version: WEBU
---
# 2 Corinthians 12 (WEBU)

← [[2 Corinthians 11 - WEBU]] | [[2 Corinthians 13 - WEBU]] →

**1** It is doubtless not profitable for me to boast, but I will come to visions and revelations of the Lord. ^1

**2** I know a man in Christ who was caught up into the third heaven fourteen years ago—whether in the body, I don’t know, or whether out of the body, I don’t know; God knows. ^2

**3** I know such a man (whether in the body, or outside of the body, I don’t know; God knows), ^3

**4** how he was caught up into Paradise and heard unspeakable words, which it is not lawful for a man to utter. ^4

**5** On behalf of such a one I will boast, but on my own behalf I will not boast, except in my weaknesses. ^5

**6** For if I would desire to boast, I will not be foolish; for I will speak the truth. But I refrain, so that no man may think more of me than that which he sees in me or hears from me. ^6

**7** By reason of the exceeding greatness of the revelations, that I should not be exalted excessively, a thorn in the flesh was given to me: a messenger of Satan to torment me, that I should not be exalted excessively. ^7

**8** Concerning this thing, I begged the Lord three times that it might depart from me. ^8

**9** He has said to me, “My grace is sufficient for you, for my power is made perfect in weakness.” Most gladly therefore I will rather glory in my weaknesses, that the power of Christ may rest on me. ^9

**10** Therefore I take pleasure in weaknesses, in injuries, in necessities, in persecutions, and in distresses, for Christ’s sake. For when I am weak, then am I strong. ^10

**11** I have become foolish in boasting. You compelled me, for I ought to have been commended by you, for I am in no way inferior to the very best apostles, though I am nothing. ^11

**12** Truly the signs of an apostle were worked among you in all perseverance, in signs and wonders and mighty works. ^12

**13** For what is there in which you were made inferior to the rest of the assemblies, unless it is that I myself was not a burden to you? Forgive me this wrong! ^13

**14** Behold, this is the third time I am ready to come to you, and I will not be a burden to you; for I seek not your possessions, but you. For the children ought not to save up for the parents, but the parents for the children. ^14

**15** I will most gladly spend and be spent for your souls. If I love you more abundantly, am I loved the less? ^15

**16** Even so, I myself didn’t burden you. But you might say that being crafty, I caught you with deception. ^16

**17** Did I take advantage of you by anyone of those whom I have sent to you? ^17

**18** I exhorted Titus, and I sent the brother with him. Did Titus take any advantage of you? Didn’t we walk in the same spirit? Didn’t we walk in the same steps? ^18

**19** Again, do you think that we are excusing ourselves to you? In the sight of God we speak in Christ. But all things, beloved, are for your edifying. ^19

**20** For I am afraid that perhaps when I come, I might find you not the way I want to, and that I might be found by you as you don’t desire, that perhaps there would be strife, jealousy, outbursts of anger, factions, slander, whisperings, proud thoughts, or riots, ^20

**21** that again when I come my God would humble me before you, and I would mourn for many of those who have sinned before now, and not repented of the uncleanness, sexual immorality, and lustfulness which they committed. ^21

← [[2 Corinthians 11 - WEBU]] | [[2 Corinthians 13 - WEBU]] →
