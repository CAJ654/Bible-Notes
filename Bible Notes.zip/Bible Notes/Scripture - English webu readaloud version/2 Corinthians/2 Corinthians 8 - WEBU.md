---
book: 2 Corinthians
chapter: 8
version: WEBU
---
# 2 Corinthians 8 (WEBU)

← [[2 Corinthians 7 - WEBU]] | [[2 Corinthians 9 - WEBU]] →

**1** Moreover, brothers, we make known to you the grace of God which has been given in the assemblies of Macedonia, ^1

**2** how in a severe ordeal of affliction, the abundance of their joy and their deep poverty abounded to the riches of their generosity. ^2

**3** For according to their power, I testify, yes and beyond their power, they gave of their own accord, ^3

**4** begging us with much entreaty to receive this grace and the fellowship in the service to the saints. ^4

**5** This was not as we had expected, but first they gave their own selves to the Lord, and to us through the will of God. ^5

**6** So we urged Titus, that as he had made a beginning before, so he would also complete in you this grace. ^6

**7** But as you abound in everything—in faith, utterance, knowledge, all earnestness, and in your love to us—see that you also abound in this grace. ^7

**8** I speak not by way of commandment, but as proving through the earnestness of others the sincerity also of your love. ^8

**9** For you know the grace of our Lord Jesus Christ, that though he was rich, yet for your sakes he became poor, that you through his poverty might become rich. ^9

**10** I give advice in this: it is expedient for you who were the first to start a year ago, not only to do, but also to be willing. ^10

**11** But now complete the doing also, that as there was the readiness to be willing, so there may be the completion also out of your ability. ^11

**12** For if the readiness is there, it is acceptable according to what you have, not according to what you don’t have. ^12

**13** For this is not that others may be eased and you distressed, ^13

**14** but for equality. Your abundance at this present time supplies their lack, that their abundance also may become a supply for your lack, that there may be equality. ^14

**15** As it is written, “He who gathered much had nothing left over, and he who gathered little had no lack.” ^15

**16** But thanks be to God, who puts the same earnest care for you into the heart of Titus. ^16

**17** For he indeed accepted our exhortation, but being himself very earnest, he went out to you of his own accord. ^17

**18** We have sent together with him the brother whose praise in the Good News is known throughout all the assemblies. ^18

**19** Not only so, but he was also appointed by the assemblies to travel with us in this grace, which is served by us to the glory of the Lord himself, and to show our readiness. ^19

**20** We are avoiding this, that any man should blame us concerning this abundance which is administered by us. ^20

**21** Having regard for honorable things, not only in the sight of the Lord, but also in the sight of men. ^21

**22** We have sent with them our brother whom we have many times proved earnest in many things, but now much more earnest, by reason of the great confidence which he has in you. ^22

**23** As for Titus, he is my partner and fellow worker for you. As for our brothers, they are the apostles of the assemblies, the glory of Christ. ^23

**24** Therefore show the proof of your love to them before the assemblies, and of our boasting on your behalf. ^24

← [[2 Corinthians 7 - WEBU]] | [[2 Corinthians 9 - WEBU]] →
