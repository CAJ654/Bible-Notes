---
book: 2 Corinthians
chapter: 1
version: WEBU
---
# 2 Corinthians 1 (WEBU)

[[2 Corinthians 2 - WEBU]] →

**1** Paul, an apostle of Christ Jesus through the will of God, and Timothy our brother, to the assembly of God which is at Corinth, with all the saints who are in the whole of Achaia: ^1

**2** Grace to you and peace from God our Father and the Lord Jesus Christ. ^2

**3** Blessed be the God and Father of our Lord Jesus Christ, the Father of mercies and God of all comfort, ^3

**4** who comforts us in all our affliction, that we may be able to comfort those who are in any affliction, through the comfort with which we ourselves are comforted by God. ^4

**5** For as the sufferings of Christ abound to us, even so our comfort also abounds through Christ. ^5

**6** But if we are afflicted, it is for your comfort and salvation. If we are comforted, it is for your comfort, which produces in you the patient enduring of the same sufferings which we also suffer. ^6

**7** Our hope for you is steadfast, knowing that, since you are partakers of the sufferings, so you are also of the comfort. ^7

**8** For we don’t desire to have you uninformed, brothers, concerning our affliction which happened to us in Asia: that we were weighed down exceedingly, beyond our power, so much that we despaired even of life. ^8

**9** Yes, we ourselves have had the sentence of death within ourselves, that we should not trust in ourselves, but in God who raises the dead, ^9

**10** who delivered us out of so great a death, and does deliver, on whom we have set our hope that he will also still deliver us, ^10

**11** you also helping together on our behalf by your supplication; that, for the gift given to us by means of many, thanks may be given by many persons on your behalf. ^11

**12** For our boasting is this: the testimony of our conscience that in holiness and sincerity of God, not in fleshly wisdom but in the grace of God, we behaved ourselves in the world, and more abundantly toward you. ^12

**13** For we write no other things to you than what you read or even acknowledge, and I hope you will acknowledge to the end— ^13

**14** as also you acknowledged us in part—that we are your boasting, even as you also are ours, in the day of our Lord Jesus. ^14

**15** In this confidence, I was determined to come first to you, that you might have a second benefit, ^15

**16** and by you to pass into Macedonia, and again from Macedonia to come to you, and to be sent forward by you on my journey to Judea. ^16

**17** When I therefore planned this, did I show fickleness? Or the things that I plan, do I plan according to the flesh, that with me there should be the “Yes, yes” and the “No, no?” ^17

**18** But as God is faithful, our word toward you was not “Yes and no.” ^18

**19** For the Son of God, Jesus Christ, who was preached among you by us—by me, Silvanus, and Timothy—was not “Yes and no,” but in him is “Yes.” ^19

**20** For however many are the promises of God, in him is the “Yes.” Therefore also through him is the “Amen”, to the glory of God through us. ^20

**21** Now he who establishes us with you in Christ and anointed us is God, ^21

**22** who also sealed us and gave us the down payment of the Spirit in our hearts. ^22

**23** But I call God for a witness to my soul, that to spare you, I didn’t come to Corinth. ^23

**24** We don’t control your faith, but are fellow workers with you for your joy. For you stand firm in faith. ^24

[[2 Corinthians 2 - WEBU]] →
