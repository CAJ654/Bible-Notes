---
book: 2 Corinthians
chapter: 2
version: WEBU
---
# 2 Corinthians 2 (WEBU)

← [[2 Corinthians 1 - WEBU]] | [[2 Corinthians 3 - WEBU]] →

**1** But I determined this for myself, that I would not come to you again in sorrow. ^1

**2** For if I make you grieve, then who will make me glad but he who is made to grieve by me? ^2

**3** And I wrote this very thing to you, so that when I came, I wouldn’t have sorrow from them of whom I ought to rejoice; having confidence in you all that my joy would be shared by all of you. ^3

**4** For out of much affliction and anguish of heart I wrote to you with many tears, not that you should be made to grieve, but that you might know the love that I have so abundantly for you. ^4

**5** But if any has caused sorrow, he has caused sorrow not to me, but in part (that I not press too heavily) to you all. ^5

**6** This punishment which was inflicted by the many is sufficient for such a one; ^6

**7** so that, on the contrary, you should rather forgive him and comfort him, lest by any means such a one should be swallowed up with his excessive sorrow. ^7

**8** Therefore I beg you to confirm your love toward him. ^8

**9** For to this end I also wrote, that I might know the proof of you, whether you are obedient in all things. ^9

**10** Now I also forgive whomever you forgive anything. For if indeed I have forgiven anything, I have forgiven that one for your sakes in the presence of Christ, ^10

**11** that no advantage may be gained over us by Satan, for we are not ignorant of his schemes. ^11

**12** Now when I came to Troas for the Good News of Christ, and when a door was opened to me in the Lord, ^12

**13** I had no relief for my spirit, because I didn’t find Titus my brother, but taking my leave of them, I went out into Macedonia. ^13

**14** Now thanks be to God who always leads us in triumph in Christ, and reveals through us the sweet aroma of his knowledge in every place. ^14

**15** For we are a sweet aroma of Christ to God in those who are being saved and in those who perish: ^15

**16** to the one a stench from death to death, to the other a sweet aroma from life to life. Who is sufficient for these things? ^16

**17** For we are not as so many, peddling the word of God. But as of sincerity, but as of God, in the sight of God, we speak in Christ. ^17

← [[2 Corinthians 1 - WEBU]] | [[2 Corinthians 3 - WEBU]] →
