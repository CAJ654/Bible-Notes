---
book: 2 Chronicles
chapter: 15
version: WEBU
---
# 2 Chronicles 15 (WEBU)

← [[2 Chronicles 14 - WEBU]] | [[2 Chronicles 16 - WEBU]] →

**1** The Spirit of God came on Azariah the son of Oded. ^1

**2** He went out to meet Asa, and said to him, “Hear me, Asa, and all Judah and Benjamin! The LORD is with you while you are with him; and if you seek him, he will be found by you; but if you forsake him, he will forsake you. ^2

**3** Now for a long time Israel was without the true God, without a teaching priest, and without law. ^3

**4** But when in their distress they turned to the LORD, the God of Israel, and sought him, he was found by them. ^4

**5** In those times there was no peace to him who went out, nor to him who came in; but great troubles were on all the inhabitants of the lands. ^5

**6** They were broken in pieces, nation against nation, and city against city; for God troubled them with all adversity. ^6

**7** But you be strong! Don’t let your hands be slack, for your work will be rewarded.” ^7

**8** When Asa heard these words and the prophecy of Oded the prophet, he took courage, and put away the abominations out of all the land of Judah and Benjamin, and out of the cities which he had taken from the hill country of Ephraim; and he renewed the LORD’s altar that was before the LORD’s porch. ^8

**9** He gathered all Judah and Benjamin, and those who lived with them out of Ephraim, Manasseh, and Simeon; for they came to him out of Israel in abundance when they saw that the LORD his God was with him. ^9

**10** So they gathered themselves together at Jerusalem in the third month, in the fifteenth year of Asa’s reign. ^10

**11** They sacrificed to the LORD in that day, from the plunder which they had brought, seven hundred head of cattle and seven thousand sheep. ^11

**12** They entered into the covenant to seek the LORD, the God of their fathers, with all their heart and with all their soul; ^12

**13** and that whoever would not seek the LORD, the God of Israel, should be put to death, whether small or great, whether man or woman. ^13

**14** They swore to the LORD with a loud voice, with shouting, with trumpets, and with cornets. ^14

**15** All Judah rejoiced at the oath, for they had sworn with all their heart and sought him with their whole desire; and he was found by them. Then the LORD gave them rest all around. ^15

**16** Also Maacah, the mother of Asa the king, he removed from being queen mother, because she had made an abominable image for an Asherah; so Asa cut down her image, ground it into dust, and burned it at the brook Kidron. ^16

**17** But the high places were not taken away out of Israel; nevertheless the heart of Asa was perfect all his days. ^17

**18** He brought the things that his father had dedicated and that he himself had dedicated, silver, gold, and vessels into God’s house. ^18

**19** There was no more war to the thirty-fifth year of Asa’s reign. ^19

← [[2 Chronicles 14 - WEBU]] | [[2 Chronicles 16 - WEBU]] →
