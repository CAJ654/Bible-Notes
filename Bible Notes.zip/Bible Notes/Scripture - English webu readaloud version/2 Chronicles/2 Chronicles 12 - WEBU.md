---
book: 2 Chronicles
chapter: 12
version: WEBU
---
# 2 Chronicles 12 (WEBU)

← [[2 Chronicles 11 - WEBU]] | [[2 Chronicles 13 - WEBU]] →

**1** When the kingdom of Rehoboam was established and he was strong, he abandoned the LORD’s law, and all Israel with him. ^1

**2** In the fifth year of King Rehoboam, Shishak king of Egypt came up against Jerusalem, because they had trespassed against the LORD, ^2

**3** with twelve hundred chariots and sixty thousand horsemen. The people were without number who came with him out of Egypt: the Lubim, the Sukkiim, and the Ethiopians. ^3

**4** He took the fortified cities which belonged to Judah, and came to Jerusalem. ^4

**5** Now Shemaiah the prophet came to Rehoboam and to the princes of Judah, who were gathered together to Jerusalem because of Shishak, and said to them, “The LORD says, ‘You have forsaken me, therefore I have also left you in the hand of Shishak.’” ^5

**6** Then the princes of Israel and the king humbled themselves; and they said, “The LORD is righteous.” ^6

**7** When the LORD saw that they humbled themselves, the LORD’s word came to Shemaiah, saying, “They have humbled themselves. I will not destroy them, but I will grant them some deliverance, and my wrath won’t be poured out on Jerusalem by the hand of Shishak. ^7

**8** Nevertheless they will be his servants, that they may know my service, and the service of the kingdoms of the countries.” ^8

**9** So Shishak king of Egypt came up against Jerusalem and took away the treasures of the LORD’s house and the treasures of the king’s house. He took it all away. He also took away the shields of gold which Solomon had made. ^9

**10** King Rehoboam made shields of bronze in their place, and committed them to the hands of the captains of the guard, who kept the door of the king’s house. ^10

**11** As often as the king entered into the LORD’s house, the guard came and bore them, then brought them back into the guard room. ^11

**12** When he humbled himself, the LORD’s wrath turned from him, so as not to destroy him altogether. Moreover, there were good things found in Judah. ^12

**13** So King Rehoboam strengthened himself in Jerusalem and reigned; for Rehoboam was forty-one years old when he began to reign, and he reigned seventeen years in Jerusalem, the city which the LORD had chosen out of all the tribes of Israel to put his name there. His mother’s name was Naamah the Ammonitess. ^13

**14** He did that which was evil, because he didn’t set his heart to seek the LORD. ^14

**15** Now the acts of Rehoboam, first and last, aren’t they written in the histories of Shemaiah the prophet and of Iddo the seer, in the genealogies? There were wars between Rehoboam and Jeroboam continually. ^15

**16** Rehoboam slept with his fathers, and was buried in David’s city; and Abijah his son reigned in his place. ^16

← [[2 Chronicles 11 - WEBU]] | [[2 Chronicles 13 - WEBU]] →
