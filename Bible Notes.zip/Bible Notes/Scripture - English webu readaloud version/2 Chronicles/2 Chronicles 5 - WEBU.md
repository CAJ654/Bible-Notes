---
book: 2 Chronicles
chapter: 5
version: WEBU
---
# 2 Chronicles 5 (WEBU)

← [[2 Chronicles 4 - WEBU]] | [[2 Chronicles 6 - WEBU]] →

**1** Thus all the work that Solomon did for the LORD’s house was finished. Solomon brought in the things that David his father had dedicated, even the silver, the gold, and all the vessels, and put them in the treasuries of God’s house. ^1

**2** Then Solomon assembled the elders of Israel and all the heads of the tribes, the princes of the fathers’ households of the children of Israel, to Jerusalem, to bring up the ark of the LORD’s covenant out of David’s city, which is Zion. ^2

**3** So all the men of Israel assembled themselves to the king at the feast, which was in the seventh month. ^3

**4** All the elders of Israel came. The Levites took up the ark. ^4

**5** They brought up the ark, the Tent of Meeting, and all the holy vessels that were in the Tent. The Levitical priests brought these up. ^5

**6** King Solomon and all the congregation of Israel who were assembled to him were before the ark, sacrificing sheep and cattle that could not be counted or numbered for multitude. ^6

**7** The priests brought in the ark of the LORD’s covenant to its place, into the inner sanctuary of the house, to the most holy place, even under the wings of the cherubim. ^7

**8** For the cherubim spread out their wings over the place of the ark, and the cherubim covered the ark and its poles above. ^8

**9** The poles were so long that the ends of the poles were seen from the ark in front of the inner sanctuary, but they were not seen outside; and it is there to this day. ^9

**10** There was nothing in the ark except the two tablets which Moses put there at Horeb, when the LORD made a covenant with the children of Israel, when they came out of Egypt. ^10

**11** When the priests had come out of the holy place (for all the priests who were present had sanctified themselves, and didn’t keep their divisions; ^11

**12** also the Levites who were the singers, all of them, even Asaph, Heman, Jeduthun, and their sons and their brothers, arrayed in fine linen, with cymbals and stringed instruments and harps, stood at the east end of the altar, and with them one hundred twenty priests sounding with trumpets); ^12

**13** when the trumpeters and singers were as one, to make one sound to be heard in praising and thanking the LORD; and when they lifted up their voice with the trumpets and cymbals and instruments of music, and praised the LORD, saying, “For he is good, for his loving kindness endures forever!” then the house was filled with a cloud, even the LORD’s house, ^13

**14** so that the priests could not stand to minister by reason of the cloud; for the LORD’s glory filled God’s house. ^14

← [[2 Chronicles 4 - WEBU]] | [[2 Chronicles 6 - WEBU]] →
