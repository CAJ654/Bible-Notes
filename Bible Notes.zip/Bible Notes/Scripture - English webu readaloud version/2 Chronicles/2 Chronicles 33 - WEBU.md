---
book: 2 Chronicles
chapter: 33
version: WEBU
---
# 2 Chronicles 33 (WEBU)

← [[2 Chronicles 32 - WEBU]] | [[2 Chronicles 34 - WEBU]] →

**1** Manasseh was twelve years old when he began to reign, and he reigned fifty-five years in Jerusalem. ^1

**2** He did that which was evil in the LORD’s sight, after the abominations of the nations whom the LORD cast out before the children of Israel. ^2

**3** For he built again the high places which Hezekiah his father had broken down; and he raised up altars for the Baals, made Asheroth, and worshiped all the army of the sky, and served them. ^3

**4** He built altars in the LORD’s house, of which the LORD said, “My name shall be in Jerusalem forever.” ^4

**5** He built altars for all the army of the sky in the two courts of the LORD’s house. ^5

**6** He also made his children to pass through the fire in the valley of the son of Hinnom. He practiced sorcery, divination, and witchcraft, and dealt with those who had familiar spirits and with wizards. He did much evil in the LORD’s sight, to provoke him to anger. ^6

**7** He set the engraved image of the idol, which he had made, in God’s house, of which God said to David and to Solomon his son, “In this house, and in Jerusalem, which I have chosen out of all the tribes of Israel, I will put my name forever. ^7

**8** I will not any more remove the foot of Israel from off the land which I have appointed for your fathers, if only they will observe to do all that I have commanded them, even all the law, the statutes, and the ordinances given by Moses.” ^8

**9** Manasseh seduced Judah and the inhabitants of Jerusalem, so that they did more evil than did the nations whom the LORD destroyed before the children of Israel. ^9

**10** The LORD spoke to Manasseh and to his people, but they didn’t listen. ^10

**11** Therefore the LORD brought on them the captains of the army of the king of Assyria, who took Manasseh in chains, bound him with fetters, and carried him to Babylon. ^11

**12** When he was in distress, he begged the LORD his God, and humbled himself greatly before the God of his fathers. ^12

**13** He prayed to him; and he was entreated by him, and heard his supplication, and brought him again to Jerusalem into his kingdom. Then Manasseh knew that the LORD was God. ^13

**14** Now after this, he built an outer wall to David’s city on the west side of Gihon, in the valley, even to the entrance at the fish gate. He encircled Ophel with it, and raised it up to a very great height; and he put valiant captains in all the fortified cities of Judah. ^14

**15** He took away the foreign gods and the idol out of the LORD’s house, and all the altars that he had built in the mountain of the LORD’s house and in Jerusalem, and cast them out of the city. ^15

**16** He built up the LORD’s altar, and offered sacrifices of peace offerings and of thanksgiving on it, and commanded Judah to serve the LORD, the God of Israel. ^16

**17** Nevertheless the people still sacrificed in the high places, but only to the LORD their God. ^17

**18** Now the rest of the acts of Manasseh, and his prayer to his God, and the words of the seers who spoke to him in the name of the LORD, the God of Israel, behold, they are written among the acts of the kings of Israel. ^18

**19** His prayer also, and how God listened to his request, and all his sin and his trespass, and the places in which he built high places and set up the Asherah poles and the engraved images before he humbled himself: behold, they are written in the history of Hozai. ^19

**20** So Manasseh slept with his fathers, and they buried him in his own house; and Amon his son reigned in his place. ^20

**21** Amon was twenty-two years old when he began to reign; and he reigned two years in Jerusalem. ^21

**22** He did that which was evil in the LORD’s sight, as did Manasseh his father; and Amon sacrificed to all the engraved images which Manasseh his father had made, and served them. ^22

**23** He didn’t humble himself before the LORD, as Manasseh his father had humbled himself; but this same Amon trespassed more and more. ^23

**24** His servants conspired against him, and put him to death in his own house. ^24

**25** But the people of the land killed all those who had conspired against King Amon; and the people of the land made Josiah his son king in his place. ^25

← [[2 Chronicles 32 - WEBU]] | [[2 Chronicles 34 - WEBU]] →
