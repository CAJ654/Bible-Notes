---
book: 2 Chronicles
chapter: 1
version: WEBU
---
# 2 Chronicles 1 (WEBU)

[[2 Chronicles 2 - WEBU]] →

**1** Solomon the son of David was firmly established in his kingdom, and the LORD his God was with him, and made him exceedingly great. ^1

**2** Solomon spoke to all Israel, to the captains of thousands and of hundreds, to the judges, and to every prince in all Israel, the heads of the fathers’ households. ^2

**3** Then Solomon, and all the assembly with him, went to the high place that was at Gibeon; for God’s Tent of Meeting was there, which the LORD’s servant Moses had made in the wilderness. ^3

**4** But David had brought God’s ark up from Kiriath Jearim to the place that David had prepared for it; for he had pitched a tent for it at Jerusalem. ^4

**5** Moreover the bronze altar that Bezalel the son of Uri, the son of Hur, had made was there before the LORD’s tabernacle; and Solomon and the assembly were seeking counsel there. ^5

**6** Solomon went up there to the bronze altar before the LORD, which was at the Tent of Meeting, and offered one thousand burnt offerings on it. ^6

**7** That night, God appeared to Solomon and said to him, “Ask for what you want me to give you.” ^7

**8** Solomon said to God, “You have shown great loving kindness to David my father, and have made me king in his place. ^8

**9** Now, LORD God, let your promise to David my father be established; for you have made me king over a people like the dust of the earth in multitude. ^9

**10** Now give me wisdom and knowledge, that I may go out and come in before this people; for who can judge this great people of yours?” ^10

**11** God said to Solomon, “Because this was in your heart, and you have not asked riches, wealth, honor, or the life of those who hate you, nor yet have you asked for long life; but have asked for wisdom and knowledge for yourself, that you may judge my people, over whom I have made you king, ^11

**12** therefore wisdom and knowledge is granted to you. I will give you riches, wealth, and honor, such as none of the kings have had who have been before you, and none after you will have.” ^12

**13** So Solomon came from the high place that was at Gibeon, from before the Tent of Meeting, to Jerusalem; and he reigned over Israel. ^13

**14** Solomon gathered chariots and horsemen. He had one thousand four hundred chariots and twelve thousand horsemen that he placed in the chariot cities, and with the king at Jerusalem. ^14

**15** The king made silver and gold to be as common as stones in Jerusalem, and he made cedars to be as common as the sycamore trees that are in the lowland. ^15

**16** The horses which Solomon had were brought out of Egypt and from Kue. The king’s merchants purchased them from Kue. ^16

**17** They imported from Egypt then exported a chariot for six hundred pieces of silver and a horse for one hundred fifty. They also exported them to the Hittite kings and the Syrian kings. ^17

[[2 Chronicles 2 - WEBU]] →
