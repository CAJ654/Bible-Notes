---
book: 2 Chronicles
chapter: 22
version: WEBU
---
# 2 Chronicles 22 (WEBU)

← [[2 Chronicles 21 - WEBU]] | [[2 Chronicles 23 - WEBU]] →

**1** The inhabitants of Jerusalem made Ahaziah his youngest son king in his place, because the band of men who came with the Arabians to the camp had slain all the oldest. So Ahaziah the son of Jehoram king of Judah reigned. ^1

**2** Ahaziah was forty-two years old when he began to reign, and he reigned one year in Jerusalem. His mother’s name was Athaliah the daughter of Omri. ^2

**3** He also walked in the ways of Ahab’s house, because his mother was his counselor in acting wickedly. ^3

**4** He did that which was evil in the LORD’s sight, as did Ahab’s house, for they were his counselors after the death of his father, to his destruction. ^4

**5** He also followed their counsel, and went with Jehoram the son of Ahab king of Israel to war against Hazael king of Syria at Ramoth Gilead; and the Syrians wounded Joram. ^5

**6** He returned to be healed in Jezreel of the wounds which they had given him at Ramah, when he fought against Hazael king of Syria. Azariah the son of Jehoram, king of Judah, went down to see Jehoram the son of Ahab in Jezreel, because he was sick. ^6

**7** Now the destruction of Ahaziah was of God, in that he went to Joram; for when he had come, he went out with Jehoram against Jehu the son of Nimshi, whom the LORD had anointed to cut off Ahab’s house. ^7

**8** When Jehu was executing judgment on Ahab’s house, he found the princes of Judah and the sons of the brothers of Ahaziah serving Ahaziah, and killed them. ^8

**9** He sought Ahaziah, and they caught him (now he was hiding in Samaria), and they brought him to Jehu and killed him; and they buried him, for they said, “He is the son of Jehoshaphat, who sought the LORD with all his heart.” The house of Ahaziah had no power to hold the kingdom. ^9

**10** Now when Athaliah the mother of Ahaziah saw that her son was dead, she arose and destroyed all the royal offspring of the house of Judah. ^10

**11** But Jehoshabeath, the king’s daughter, took Joash the son of Ahaziah, and stealthily rescued him from among the king’s sons who were slain, and put him and his nurse in the bedroom. So Jehoshabeath, the daughter of King Jehoram, the wife of Jehoiada the priest (for she was the sister of Ahaziah), hid him from Athaliah, so that she didn’t kill him. ^11

**12** He was with them hidden in God’s house six years while Athaliah reigned over the land. ^12

← [[2 Chronicles 21 - WEBU]] | [[2 Chronicles 23 - WEBU]] →
