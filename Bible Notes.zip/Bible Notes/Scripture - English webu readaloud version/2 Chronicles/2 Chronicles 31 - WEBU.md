---
book: 2 Chronicles
chapter: 31
version: WEBU
---
# 2 Chronicles 31 (WEBU)

← [[2 Chronicles 30 - WEBU]] | [[2 Chronicles 32 - WEBU]] →

**1** Now when all this was finished, all Israel who were present went out to the cities of Judah and broke the pillars in pieces, cut down the Asherah poles, and broke down the high places and the altars out of all Judah and Benjamin, also in Ephraim and Manasseh, until they had destroyed them all. Then all the children of Israel returned, every man to his possession, into their own cities. ^1

**2** Hezekiah appointed the divisions of the priests and the Levites after their divisions, every man according to his service, both the priests and the Levites, for burnt offerings and for peace offerings, to minister, to give thanks, and to praise in the gates of the LORD’s camp. ^2

**3** He also appointed the king’s portion of his possessions for the burnt offerings: for the morning and evening burnt offerings, and the burnt offerings for the Sabbaths, for the new moons, and for the set feasts, as it is written in the LORD’s law. ^3

**4** Moreover he commanded the people who lived in Jerusalem to give the portion of the priests and the Levites, that they might give themselves to the LORD’s law. ^4

**5** As soon as the commandment went out, the children of Israel gave in abundance the first fruits of grain, new wine, oil, honey, and of all the increase of the field; and they brought in the tithe of all things abundantly. ^5

**6** The children of Israel and Judah, who lived in the cities of Judah, also brought in the tithe of cattle and sheep, and the tithe of dedicated things which were consecrated to the LORD their God, and laid them in heaps. ^6

**7** In the third month, they began to lay the foundation of the heaps, and finished them in the seventh month. ^7

**8** When Hezekiah and the princes came and saw the heaps, they blessed the LORD and his people Israel. ^8

**9** Then Hezekiah questioned the priests and the Levites about the heaps. ^9

**10** Azariah the chief priest, of the house of Zadok, answered him and said, “Since people began to bring the offerings into the LORD’s house, we have eaten and had enough, and have plenty left over, for the LORD has blessed his people; and that which is left is this great store.” ^10

**11** Then Hezekiah commanded them to prepare rooms in the LORD’s house, and they prepared them. ^11

**12** They brought in the offerings, the tithes, and the dedicated things faithfully. Conaniah the Levite was ruler over them, and Shimei his brother was second. ^12

**13** Jehiel, Azaziah, Nahath, Asahel, Jerimoth, Jozabad, Eliel, Ismachiah, Mahath, and Benaiah were overseers under the hand of Conaniah and Shimei his brother, by the appointment of Hezekiah the king and Azariah the ruler of God’s house. ^13

**14** Kore the son of Imnah the Levite, the gatekeeper at the east gate, was over the free will offerings of God, to distribute the LORD’s offerings and the most holy things. ^14

**15** Under him were Eden, Miniamin, Jeshua, Shemaiah, Amariah, and Shecaniah, in the cities of the priests, in their office of trust, to give to their brothers by divisions, to the great as well as to the small; ^15

**16** in addition to those who were listed by genealogy of males, from three years old and upward, even everyone who entered into the LORD’s house, as the duty of every day required, for their service in their offices according to their divisions; ^16

**17** and those who were listed by genealogy of the priests by their fathers’ houses, and the Levites from twenty years old and upward, in their offices by their divisions; ^17

**18** and those who were listed by genealogy of all their little ones, their wives, their sons, and their daughters, through all the congregation; for in their office of trust they sanctified themselves in holiness. ^18

**19** Also for the sons of Aaron the priests, who were in the fields of the pasture lands of their cities, in every city, there were men who were mentioned by name to give portions to all the males among the priests and to all who were listed by genealogy among the Levites. ^19

**20** Hezekiah did so throughout all Judah; and he did that which was good, right, and faithful before the LORD his God. ^20

**21** In every work that he began in the service of God’s house, in the law, and in the commandments, to seek his God, he did it with all his heart and prospered. ^21

← [[2 Chronicles 30 - WEBU]] | [[2 Chronicles 32 - WEBU]] →
