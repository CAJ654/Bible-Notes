---
book: 2 Chronicles
chapter: 35
version: WEBU
---
# 2 Chronicles 35 (WEBU)

← [[2 Chronicles 34 - WEBU]] | [[2 Chronicles 36 - WEBU]] →

**1** Josiah kept a Passover to the LORD in Jerusalem. They killed the Passover on the fourteenth day of the first month. ^1

**2** He set the priests in their offices and encouraged them in the service of the LORD’s house. ^2

**3** He said to the Levites who taught all Israel, who were holy to the LORD, “Put the holy ark in the house which Solomon the son of David king of Israel built. It will no longer be a burden on your shoulders. Now serve the LORD your God and his people Israel. ^3

**4** Prepare yourselves after your fathers’ houses by your divisions, according to the writing of David king of Israel, and according to the writing of Solomon his son. ^4

**5** Stand in the holy place according to the divisions of the fathers’ houses of your brothers the children of the people, and let there be for each a portion of a fathers’ house of the Levites. ^5

**6** Kill the Passover lamb, sanctify yourselves, and prepare for your brothers, to do according to the LORD’s word by Moses.” ^6

**7** Josiah gave to the children of the people, of the flock, lambs and young goats, all of them for the Passover offerings, to all who were present, to the number of thirty thousand, and three thousand bulls. These were of the king’s substance. ^7

**8** His princes gave a free will offering to the people, to the priests, and to the Levites. Hilkiah, Zechariah, and Jehiel, the rulers of God’s house, gave to the priests for the Passover offerings two thousand six hundred small livestock, and three hundred head of cattle. ^8

**9** Conaniah also, and Shemaiah and Nethanel, his brothers, and Hashabiah, Jeiel, and Jozabad, the chiefs of the Levites, gave to the Levites for the Passover offerings five thousand small livestock and five hundred head of cattle. ^9

**10** So the service was prepared, and the priests stood in their place, and the Levites by their divisions, according to the king’s commandment. ^10

**11** They killed the Passover lambs, and the priests sprinkled the blood which they received from their hands, and the Levites skinned them. ^11

**12** They removed the burnt offerings, that they might give them according to the divisions of the fathers’ houses of the children of the people, to offer to the LORD, as it is written in the book of Moses. They did the same with the cattle. ^12

**13** They roasted the Passover with fire according to the ordinance. They boiled the holy offerings in pots, in cauldrons, and in pans, and carried them quickly to all the children of the people. ^13

**14** Afterward they prepared for themselves and for the priests, because the priests the sons of Aaron were busy with offering the burnt offerings and the fat until night. Therefore the Levites prepared for themselves and for the priests the sons of Aaron. ^14

**15** The singers, the sons of Asaph, were in their place, according to the commandment of David, Asaph, Heman, and Jeduthun the king’s seer; and the gatekeepers were at every gate. They didn’t need to depart from their service, because their brothers the Levites prepared for them. ^15

**16** So all the service of the LORD was prepared the same day, to keep the Passover, and to offer burnt offerings on the LORD’s altar, according to the commandment of King Josiah. ^16

**17** The children of Israel who were present kept the Passover at that time, and the feast of unleavened bread seven days. ^17

**18** There was no Passover like that kept in Israel from the days of Samuel the prophet, nor did any of the kings of Israel keep such a Passover as Josiah kept—with the priests, the Levites, and all Judah and Israel who were present, and the inhabitants of Jerusalem. ^18

**19** This Passover was kept in the eighteenth year of the reign of Josiah. ^19

**20** After all this, when Josiah had prepared the temple, Neco king of Egypt went up to fight against Carchemish by the Euphrates, and Josiah went out against him. ^20

**21** But he sent ambassadors to him, saying, “What have I to do with you, you king of Judah? I come not against you today, but against the house with which I have war. God has commanded me to make haste. Beware that it is God who is with me, that he not destroy you.” ^21

**22** Nevertheless Josiah would not turn his face from him, but disguised himself, that he might fight with him, and didn’t listen to the words of Neco from the mouth of God, and came to fight in the valley of Megiddo. ^22

**23** The archers shot at King Josiah; and the king said to his servants, “Take me away, because I am seriously wounded!” ^23

**24** So his servants took him out of the chariot, and put him in the second chariot that he had, and brought him to Jerusalem; and he died, and was buried in the tombs of his fathers. All Judah and Jerusalem mourned for Josiah. ^24

**25** Jeremiah lamented for Josiah, and all the singing men and singing women spoke of Josiah in their lamentations to this day; and they made them an ordinance in Israel. Behold, they are written in the lamentations. ^25

**26** Now the rest of the acts of Josiah and his good deeds, according to that which is written in the LORD’s law, ^26

**27** and his acts, first and last, behold, they are written in the book of the kings of Israel and Judah. ^27

← [[2 Chronicles 34 - WEBU]] | [[2 Chronicles 36 - WEBU]] →
