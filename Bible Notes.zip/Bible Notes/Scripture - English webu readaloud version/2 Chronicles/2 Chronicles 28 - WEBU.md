---
book: 2 Chronicles
chapter: 28
version: WEBU
---
# 2 Chronicles 28 (WEBU)

← [[2 Chronicles 27 - WEBU]] | [[2 Chronicles 29 - WEBU]] →

**1** Ahaz was twenty years old when he began to reign, and he reigned sixteen years in Jerusalem. He didn’t do that which was right in the LORD’s eyes, like David his father, ^1

**2** but he walked in the ways of the kings of Israel, and also made molten images for the Baals. ^2

**3** Moreover he burned incense in the valley of the son of Hinnom, and burned his children in the fire, according to the abominations of the nations whom the LORD cast out before the children of Israel. ^3

**4** He sacrificed and burned incense in the high places, and on the hills, and under every green tree. ^4

**5** Therefore the LORD his God delivered him into the hand of the king of Syria. They struck him, and carried away from him a great multitude of captives, and brought them to Damascus. He was also delivered into the hand of the king of Israel, who struck him with a great slaughter. ^5

**6** For Pekah the son of Remaliah killed in Judah one hundred twenty thousand in one day, all of them valiant men, because they had forsaken the LORD, the God of their fathers. ^6

**7** Zichri, a mighty man of Ephraim, killed Maaseiah the king’s son, Azrikam the ruler of the house, and Elkanah who was next to the king. ^7

**8** The children of Israel carried away captive of their brothers two hundred thousand women, sons, and daughters, and also took away much plunder from them, and brought the plunder to Samaria. ^8

**9** But a prophet of the LORD was there, whose name was Oded; and he went out to meet the army that came to Samaria, and said to them, “Behold, because the LORD, the God of your fathers, was angry with Judah, he has delivered them into your hand, and you have slain them in a rage which has reached up to heaven. ^9

**10** Now you intend to degrade the children of Judah and Jerusalem as male and female slaves for yourselves. Aren’t there even with you trespasses of your own against the LORD your God? ^10

**11** Now hear me therefore, and send back the captives that you have taken captive from your brothers, for the fierce wrath of the LORD is on you.” ^11

**12** Then some of the heads of the children of Ephraim, Azariah the son of Johanan, Berechiah the son of Meshillemoth, Jehizkiah the son of Shallum, and Amasa the son of Hadlai, stood up against those who came from the war, ^12

**13** and said to them, “You must not bring in the captives here, for you intend that which will bring on us a trespass against the LORD, to add to our sins and to our guilt; for our guilt is great, and there is fierce wrath against Israel.” ^13

**14** So the armed men left the captives and the plunder before the princes and all the assembly. ^14

**15** The men who have been mentioned by name rose up and took the captives, and with the plunder clothed all who were naked among them, dressed them, gave them sandals, gave them something to eat and to drink, anointed them, carried all the feeble of them on donkeys, and brought them to Jericho, the city of palm trees, to their brothers. Then they returned to Samaria. ^15

**16** At that time King Ahaz sent to the kings of Assyria to help him. ^16

**17** For again the Edomites had come and struck Judah, and carried away captives. ^17

**18** The Philistines also had invaded the cities of the lowland and of the South of Judah, and had taken Beth Shemesh, Aijalon, Gederoth, Soco with its villages, Timnah with its villages, and also Gimzo and its villages; and they lived there. ^18

**19** For the LORD brought Judah low because of Ahaz king of Israel, because he acted without restraint in Judah and trespassed severely against the LORD. ^19

**20** Tilgath-pilneser king of Assyria came to him and gave him trouble, but didn’t strengthen him. ^20

**21** For Ahaz took away a portion out of the LORD’s house, and out of the house of the king and of the princes, and gave it to the king of Assyria; but it didn’t help him. ^21

**22** In the time of his distress, he trespassed yet more against the LORD, this same King Ahaz. ^22

**23** For he sacrificed to the gods of Damascus which had defeated him. He said, “Because the gods of the kings of Syria helped them, I will sacrifice to them, that they may help me.” But they were the ruin of him and of all Israel. ^23

**24** Ahaz gathered together the vessels of God’s house, cut the vessels of God’s house in pieces, and shut up the doors of the LORD’s house; and he made himself altars in every corner of Jerusalem. ^24

**25** In every city of Judah he made high places to burn incense to other gods, and provoked the LORD, the God of his fathers, to anger. ^25

**26** Now the rest of his acts, and all his ways, first and last, behold, they are written in the book of the kings of Judah and Israel. ^26

**27** Ahaz slept with his fathers, and they buried him in the city, even in Jerusalem, because they didn’t bring him into the tombs of the kings of Israel; and Hezekiah his son reigned in his place. ^27

← [[2 Chronicles 27 - WEBU]] | [[2 Chronicles 29 - WEBU]] →
