---
book: 2 Chronicles
chapter: 4
version: WEBU
---
# 2 Chronicles 4 (WEBU)

← [[2 Chronicles 3 - WEBU]] | [[2 Chronicles 5 - WEBU]] →

**1** Then he made an altar of bronze, twenty cubits long, twenty cubits wide, and ten cubits high. ^1

**2** Also he made the molten sea of ten cubits from brim to brim. It was round, five cubits high, and thirty cubits in circumference. ^2

**3** Under it was the likeness of oxen, which encircled it, for ten cubits, encircling the sea. The oxen were in two rows, cast when it was cast. ^3

**4** It stood on twelve oxen, three looking toward the north, three looking toward the west, three looking toward the south, and three looking toward the east; and the sea was set on them above, and all their hindquarters were inward. ^4

**5** It was a handbreadth thick. Its brim was made like the brim of a cup, like the flower of a lily. It received and held three thousand baths. ^5

**6** He also made ten basins, and put five on the right hand and five on the left, to wash in them. The things that belonged to the burnt offering were washed in them, but the sea was for the priests to wash in. ^6

**7** He made the ten lamp stands of gold according to the ordinance concerning them; and he set them in the temple, five on the right hand and five on the left. ^7

**8** He made also ten tables, and placed them in the temple, five on the right side and five on the left. He made one hundred basins of gold. ^8

**9** Furthermore he made the court of the priests, the great court, and doors for the court, and overlaid their doors with bronze. ^9

**10** He set the sea on the right side of the house eastward, toward the south. ^10

**11** Huram made the pots, the shovels, and the basins. So Huram finished doing the work that he did for King Solomon in God’s house: ^11

**12** the two pillars, the bowls, the two capitals which were on the top of the pillars, the two networks to cover the two bowls of the capitals that were on the top of the pillars, ^12

**13** and the four hundred pomegranates for the two networks—two rows of pomegranates for each network, to cover the two bowls of the capitals that were on the pillars. ^13

**14** He also made the bases, and he made the basins on the bases— ^14

**15** one sea, and the twelve oxen under it. ^15

**16** Huram-abi also made the pots, the shovels, the forks, and all its vessels for King Solomon, for the LORD’s house, of bright bronze. ^16

**17** The king cast them in the plain of the Jordan, in the clay ground between Succoth and Zeredah. ^17

**18** Thus Solomon made all these vessels in great abundance, so that the weight of the bronze could not be determined. ^18

**19** Solomon made all the vessels that were in God’s house: the golden altar, the tables with the show bread on them, ^19

**20** and the lamp stands with their lamps to burn according to the ordinance before the inner sanctuary, of pure gold; ^20

**21** and the flowers, the lamps, and the tongs of gold that was purest gold; ^21

**22** and the snuffers, the basins, the spoons, and the fire pans of pure gold. As for the entry of the house, its inner doors for the most holy place and the doors of the main hall of the temple were of gold. ^22

← [[2 Chronicles 3 - WEBU]] | [[2 Chronicles 5 - WEBU]] →
