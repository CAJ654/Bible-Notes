---
book: 2 Chronicles
chapter: 13
version: WEBU
---
# 2 Chronicles 13 (WEBU)

← [[2 Chronicles 12 - WEBU]] | [[2 Chronicles 14 - WEBU]] →

**1** In the eighteenth year of King Jeroboam, Abijah began to reign over Judah. ^1

**2** He reigned three years in Jerusalem. His mother’s name was Micaiah the daughter of Uriel of Gibeah. There was war between Abijah and Jeroboam. ^2

**3** Abijah joined battle with an army of valiant men of war, even four hundred thousand chosen men; and Jeroboam set the battle in array against him with eight hundred thousand chosen men, who were mighty men of valor. ^3

**4** Abijah stood up on Mount Zemaraim, which is in the hill country of Ephraim, and said, “Hear me, Jeroboam and all Israel: ^4

**5** Ought you not to know that the LORD, the God of Israel, gave the kingdom over Israel to David forever, even to him and to his sons by a covenant of salt? ^5

**6** Yet Jeroboam the son of Nebat, the servant of Solomon the son of David, rose up, and rebelled against his lord. ^6

**7** Worthless men were gathered to him, wicked fellows who strengthened themselves against Rehoboam the son of Solomon, when Rehoboam was young and tender hearted, and could not withstand them. ^7

**8** “Now you intend to withstand the kingdom of the LORD in the hand of the sons of David. You are a great multitude, and the golden calves which Jeroboam made you for gods are with you. ^8

**9** Haven’t you driven out the priests of the LORD, the sons of Aaron, and the Levites, and made priests for yourselves according to the ways of the peoples of other lands? Whoever comes to consecrate himself with a young bull and seven rams may be a priest of those who are no gods. ^9

**10** “But as for us, the LORD is our God, and we have not forsaken him. We have priests serving the LORD, the sons of Aaron, and the Levites in their work. ^10

**11** They burn to the LORD every morning and every evening burnt offerings and sweet incense. They also set the show bread in order on the pure table, and care for the gold lamp stand with its lamps, to burn every evening; for we keep the instruction of the LORD our God, but you have forsaken him. ^11

**12** Behold, God is with us at our head, and his priests with the trumpets of alarm to sound an alarm against you. Children of Israel, don’t fight against the LORD, the God of your fathers; for you will not prosper.” ^12

**13** But Jeroboam caused an ambush to come about behind them; so they were before Judah, and the ambush was behind them. ^13

**14** When Judah looked back, behold, the battle was before and behind them; and they cried to the LORD, and the priests sounded with the trumpets. ^14

**15** Then the men of Judah gave a shout. As the men of Judah shouted, God struck Jeroboam and all Israel before Abijah and Judah. ^15

**16** The children of Israel fled before Judah, and God delivered them into their hand. ^16

**17** Abijah and his people killed them with a great slaughter, so five hundred thousand chosen men of Israel fell down slain. ^17

**18** Thus the children of Israel were brought under at that time, and the children of Judah prevailed, because they relied on the LORD, the God of their fathers. ^18

**19** Abijah pursued Jeroboam, and took cities from him: Bethel with its villages, Jeshanah with its villages, and Ephron with its villages. ^19

**20** Jeroboam didn’t recover strength again in the days of Abijah. The LORD struck him, and he died. ^20

**21** But Abijah grew mighty and took for himself fourteen wives, and became the father of twenty-two sons and sixteen daughters. ^21

**22** The rest of the acts of Abijah, his ways, and his sayings are written in the commentary of the prophet Iddo. ^22

← [[2 Chronicles 12 - WEBU]] | [[2 Chronicles 14 - WEBU]] →
