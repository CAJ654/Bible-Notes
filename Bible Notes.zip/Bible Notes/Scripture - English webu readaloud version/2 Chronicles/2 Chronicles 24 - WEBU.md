---
book: 2 Chronicles
chapter: 24
version: WEBU
---
# 2 Chronicles 24 (WEBU)

← [[2 Chronicles 23 - WEBU]] | [[2 Chronicles 25 - WEBU]] →

**1** Joash was seven years old when he began to reign, and he reigned forty years in Jerusalem. His mother’s name was Zibiah, of Beersheba. ^1

**2** Joash did that which was right in the LORD’s eyes all the days of Jehoiada the priest. ^2

**3** Jehoiada took for him two wives, and he became the father of sons and daughters. ^3

**4** After this, Joash intended to restore the LORD’s house. ^4

**5** He gathered together the priests and the Levites, and said to them, “Go out to the cities of Judah, and gather money to repair the house of your God from all Israel from year to year. See that you expedite this matter.” However the Levites didn’t do it right away. ^5

**6** The king called for Jehoiada the chief, and said to him, “Why haven’t you required of the Levites to bring in the tax of Moses the servant of the LORD, and of the assembly of Israel, out of Judah and out of Jerusalem, for the Tent of the Testimony?” ^6

**7** For the sons of Athaliah, that wicked woman, had broken up God’s house; and they also gave all the dedicated things of the LORD’s house to the Baals. ^7

**8** So the king commanded, and they made a chest, and set it outside at the gate of the LORD’s house. ^8

**9** They made a proclamation through Judah and Jerusalem, to bring in for the LORD the tax that Moses the servant of God laid on Israel in the wilderness. ^9

**10** All the princes and all the people rejoiced, and brought in, and cast into the chest, until they had filled it. ^10

**11** Whenever the chest was brought to the king’s officers by the hand of the Levites, and when they saw that there was much money, the king’s scribe and the chief priest’s officer came and emptied the chest, and took it, and carried it to its place again. Thus they did day by day, and gathered money in abundance. ^11

**12** The king and Jehoiada gave it to those who did the work of the service of the LORD’s house. They hired masons and carpenters to restore the LORD’s house, and also those who worked iron and bronze to repair the LORD’s house. ^12

**13** So the workmen worked, and the work of repairing went forward in their hands. They set up God’s house as it was designed, and strengthened it. ^13

**14** When they had finished, they brought the rest of the money before the king and Jehoiada, from which were made vessels for the LORD’s house, even vessels with which to minister and to offer, including spoons and vessels of gold and silver. They offered burnt offerings in the LORD’s house continually all the days of Jehoiada. ^14

**15** But Jehoiada grew old and was full of days, and he died. He was one hundred thirty years old when he died. ^15

**16** They buried him in David’s city among the kings, because he had done good in Israel, and toward God and his house. ^16

**17** Now after the death of Jehoiada, the princes of Judah came and bowed down to the king. Then the king listened to them. ^17

**18** They abandoned the house of the LORD, the God of their fathers, and served the Asherah poles and the idols, so wrath came on Judah and Jerusalem for this their guiltiness. ^18

**19** Yet he sent prophets to them to bring them again to the LORD, and they testified against them; but they would not listen. ^19

**20** The Spirit of God came on Zechariah the son of Jehoiada the priest; and he stood above the people, and said to them, “God says, ‘Why do you disobey the LORD’s commandments, so that you can’t prosper? Because you have forsaken the LORD, he has also forsaken you.’” ^20

**21** They conspired against him, and stoned him with stones at the commandment of the king in the court of the LORD’s house. ^21

**22** Thus Joash the king didn’t remember the kindness which Jehoiada his father had done to him, but killed his son. When he died, he said, “May the LORD look at it, and repay it.” ^22

**23** At the end of the year, the army of the Syrians came up against him. They came to Judah and Jerusalem, and destroyed all the princes of the people from among the people, and sent all their plunder to the king of Damascus. ^23

**24** For the army of the Syrians came with a small company of men; and the LORD delivered a very great army into their hand, because they had forsaken the LORD, the God of their fathers. So they executed judgment on Joash. ^24

**25** When they had departed from him (for they left him seriously wounded), his own servants conspired against him for the blood of the sons of Jehoiada the priest, and killed him on his bed, and he died. They buried him in David’s city, but they didn’t bury him in the tombs of the kings. ^25

**26** These are those who conspired against him: Zabad the son of Shimeath the Ammonitess and Jehozabad the son of Shimrith the Moabitess. ^26

**27** Now concerning his sons, the greatness of the burdens laid on him, and the rebuilding of God’s house, behold, they are written in the commentary of the book of the kings. Amaziah his son reigned in his place. ^27

← [[2 Chronicles 23 - WEBU]] | [[2 Chronicles 25 - WEBU]] →
