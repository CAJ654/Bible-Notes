---
book: 2 Chronicles
chapter: 29
version: WEBU
---
# 2 Chronicles 29 (WEBU)

← [[2 Chronicles 28 - WEBU]] | [[2 Chronicles 30 - WEBU]] →

**1** Hezekiah began to reign when he was twenty-five years old, and he reigned twenty-nine years in Jerusalem. His mother’s name was Abijah, the daughter of Zechariah. ^1

**2** He did that which was right in the LORD’s eyes, according to all that David his father had done. ^2

**3** In the first year of his reign, in the first month, he opened the doors of the LORD’s house and repaired them. ^3

**4** He brought in the priests and the Levites and gathered them together into the wide place on the east, ^4

**5** and said to them, “Listen to me, you Levites! Now sanctify yourselves, and sanctify the house of the LORD, the God of your fathers, and carry the filthiness out of the holy place. ^5

**6** For our fathers were unfaithful, and have done that which was evil in the LORD our God’s sight, and have forsaken him, and have turned away their faces from the habitation of the LORD, and turned their backs. ^6

**7** Also they have shut up the doors of the porch, and put out the lamps, and have not burned incense nor offered burnt offerings in the holy place to the God of Israel. ^7

**8** Therefore the LORD’s wrath was on Judah and Jerusalem, and he has delivered them to be tossed back and forth, to be an astonishment and a hissing, as you see with your eyes. ^8

**9** For behold, our fathers have fallen by the sword, and our sons and our daughters and our wives are in captivity for this. ^9

**10** Now it is in my heart to make a covenant with the LORD, the God of Israel, that his fierce anger may turn away from us. ^10

**11** My sons, don’t be negligent now; for the LORD has chosen you to stand before him, to minister to him, and that you should be his ministers and burn incense.” ^11

**12** Then the Levites arose: Mahath, the son of Amasai, and Joel the son of Azariah, of the sons of the Kohathites; and of the sons of Merari, Kish the son of Abdi, and Azariah the son of Jehallelel; and of the Gershonites, Joah the son of Zimmah, and Eden the son of Joah; ^12

**13** and of the sons of Elizaphan, Shimri and Jeuel; and of the sons of Asaph, Zechariah and Mattaniah; ^13

**14** and of the sons of Heman, Jehuel and Shimei; and of the sons of Jeduthun, Shemaiah and Uzziel. ^14

**15** They gathered their brothers, sanctified themselves, and went in, according to the commandment of the king by the LORD’s words, to cleanse the LORD’s house. ^15

**16** The priests went into the inner part of the LORD’s house to cleanse it, and brought out all the uncleanness that they found in the LORD’s temple into the court of the LORD’s house. The Levites took it from there to carry it out to the brook Kidron. ^16

**17** Now they began on the first day of the first month to sanctify, and on the eighth day of the month they came to the LORD’s porch. They sanctified the LORD’s house in eight days, and on the sixteenth day of the first month they finished. ^17

**18** Then they went in to Hezekiah the king within the palace and said, “We have cleansed all the LORD’s house, including the altar of burnt offering with all its vessels, and the table of show bread with all its vessels. ^18

**19** Moreover, we have prepared and sanctified all the vessels which King Ahaz threw away in his reign when he was unfaithful. Behold, they are before the LORD’s altar.” ^19

**20** Then Hezekiah the king arose early, gathered the princes of the city, and went up to the LORD’s house. ^20

**21** They brought seven bulls, seven rams, seven lambs, and seven male goats, for a sin offering for the kingdom, for the sanctuary, and for Judah. He commanded the priests the sons of Aaron to offer them on the LORD’s altar. ^21

**22** So they killed the bulls, and the priests received the blood and sprinkled it on the altar. They killed the rams and sprinkled the blood on the altar. They also killed the lambs and sprinkled the blood on the altar. ^22

**23** They brought near the male goats for the sin offering before the king and the assembly; and they laid their hands on them. ^23

**24** Then the priests killed them, and they made a sin offering with their blood on the altar, to make atonement for all Israel; for the king commanded that the burnt offering and the sin offering should be made for all Israel. ^24

**25** He set the Levites in the LORD’s house with cymbals, with stringed instruments, and with harps, according to the commandment of David, of Gad the king’s seer, and Nathan the prophet; for the commandment was from the LORD by his prophets. ^25

**26** The Levites stood with David’s instruments, and the priests with the trumpets. ^26

**27** Hezekiah commanded them to offer the burnt offering on the altar. When the burnt offering began, the LORD’s song also began, along with the trumpets and instruments of David king of Israel. ^27

**28** All the assembly worshiped, the singers sang, and the trumpeters sounded. All this continued until the burnt offering was finished. ^28

**29** When they had finished offering, the king and all who were present with him bowed themselves and worshiped. ^29

**30** Moreover Hezekiah the king and the princes commanded the Levites to sing praises to the LORD with the words of David, and of Asaph the seer. They sang praises with gladness, and they bowed their heads and worshiped. ^30

**31** Then Hezekiah answered, “Now you have consecrated yourselves to the LORD. Come near and bring sacrifices and thank offerings into the LORD’s house.” The assembly brought in sacrifices and thank offerings, and as many as were of a willing heart brought burnt offerings. ^31

**32** The number of the burnt offerings which the assembly brought was seventy bulls, one hundred rams, and two hundred lambs. All these were for a burnt offering to the LORD. ^32

**33** The consecrated things were six hundred head of cattle and three thousand sheep. ^33

**34** But the priests were too few, so that they could not skin all the burnt offerings. Therefore their brothers the Levites helped them until the work was ended, and until the priests had sanctified themselves, for the Levites were more upright in heart to sanctify themselves than the priests. ^34

**35** Also the burnt offerings were in abundance, with the fat of the peace offerings and with the drink offerings for every burnt offering. So the service of the LORD’s house was set in order. ^35

**36** Hezekiah and all the people rejoiced because of that which God had prepared for the people; for the thing was done suddenly. ^36

← [[2 Chronicles 28 - WEBU]] | [[2 Chronicles 30 - WEBU]] →
