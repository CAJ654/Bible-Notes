---
book: 2 Chronicles
chapter: 36
version: WEBU
---
# 2 Chronicles 36 (WEBU)

← [[2 Chronicles 35 - WEBU]]

**1** Then the people of the land took Jehoahaz the son of Josiah, and made him king in his father’s place in Jerusalem. ^1

**2** Joahaz was twenty-three years old when he began to reign; and he reigned three months in Jerusalem. ^2

**3** The king of Egypt removed him from office at Jerusalem, and fined the land one hundred talents of silver and a talent of gold. ^3

**4** The king of Egypt made Eliakim his brother king over Judah and Jerusalem, and changed his name to Jehoiakim. Neco took Joahaz his brother, and carried him to Egypt. ^4

**5** Jehoiakim was twenty-five years old when he began to reign, and he reigned eleven years in Jerusalem. He did that which was evil in the LORD his God’s sight. ^5

**6** Nebuchadnezzar king of Babylon came up against him, and bound him in fetters to carry him to Babylon. ^6

**7** Nebuchadnezzar also carried some of the vessels of the LORD’s house to Babylon, and put them in his temple at Babylon. ^7

**8** Now the rest of the acts of Jehoiakim, and his abominations which he did, and that which was found in him, behold, they are written in the book of the kings of Israel and Judah; and Jehoiachin his son reigned in his place. ^8

**9** Jehoiachin was eight years old when he began to reign, and he reigned three months and ten days in Jerusalem. He did that which was evil in the LORD’s sight. ^9

**10** At the return of the year, King Nebuchadnezzar sent and brought him to Babylon, with the valuable vessels of the LORD’s house, and made Zedekiah his brother king over Judah and Jerusalem. ^10

**11** Zedekiah was twenty-one years old when he began to reign, and he reigned eleven years in Jerusalem. ^11

**12** He did that which was evil in the LORD his God’s sight. He didn’t humble himself before Jeremiah the prophet speaking from the LORD’s mouth. ^12

**13** He also rebelled against King Nebuchadnezzar, who had made him swear by God; but he stiffened his neck, and hardened his heart against turning to the LORD, the God of Israel. ^13

**14** Moreover all the chiefs of the priests and the people trespassed very greatly after all the abominations of the nations; and they polluted the LORD’s house which he had made holy in Jerusalem. ^14

**15** The LORD, the God of their fathers, sent to them by his messengers, rising up early and sending, because he had compassion on his people and on his dwelling place; ^15

**16** but they mocked the messengers of God, despised his words, and scoffed at his prophets, until the LORD’s wrath arose against his people, until there was no remedy. ^16

**17** Therefore he brought on them the king of the Chaldeans, who killed their young men with the sword in the house of their sanctuary, and had no compassion on young man or virgin, old man or infirm. He gave them all into his hand. ^17

**18** All the vessels of God’s house, great and small, and the treasures of the LORD’s house, and the treasures of the king and of his princes, all these he brought to Babylon. ^18

**19** They burned God’s house, broke down the wall of Jerusalem, burned all its palaces with fire, and destroyed all of its valuable vessels. ^19

**20** He carried those who had escaped from the sword away to Babylon, and they were servants to him and his sons until the reign of the kingdom of Persia, ^20

**21** to fulfill the LORD’s word by Jeremiah’s mouth, until the land had enjoyed its Sabbaths. As long as it lay desolate, it kept Sabbath, to fulfill seventy years. ^21

**22** Now in the first year of Cyrus king of Persia, that the LORD’s word by the mouth of Jeremiah might be accomplished, the LORD stirred up the spirit of Cyrus king of Persia, so that he made a proclamation throughout all his kingdom, and put it also in writing, saying, ^22

**23** “Cyrus king of Persia says, ‘The LORD, the God of heaven, has given all the kingdoms of the earth to me; and he has commanded me to build him a house in Jerusalem, which is in Judah. Whoever there is among you of all his people, the LORD his God be with him, and let him go up.’” ^23

← [[2 Chronicles 35 - WEBU]]
