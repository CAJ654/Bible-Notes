---
book: 2 Chronicles
chapter: 6
version: WEBU
---
# 2 Chronicles 6 (WEBU)

← [[2 Chronicles 5 - WEBU]] | [[2 Chronicles 7 - WEBU]] →

**1** Then Solomon said, “The LORD has said that he would dwell in the thick darkness. ^1

**2** But I have built you a house and home, a place for you to dwell in forever.” ^2

**3** The king turned his face, and blessed all the assembly of Israel; and all the assembly of Israel stood. ^3

**4** He said, “Blessed be the LORD, the God of Israel, who spoke with his mouth to David my father, and has with his hands fulfilled it, saying, ^4

**5** ‘Since the day that I brought my people out of the land of Egypt, I chose no city out of all the tribes of Israel to build a house in, that my name might be there, and I chose no man to be prince over my people Israel; ^5

**6** but now I have chosen Jerusalem, that my name might be there; and I have chosen David to be over my people Israel.’ ^6

**7** Now it was in the heart of David my father to build a house for the name of the LORD, the God of Israel. ^7

**8** But the LORD said to David my father, ‘Whereas it was in your heart to build a house for my name, you did well that it was in your heart; ^8

**9** nevertheless you shall not build the house, but your son who will come out of your body, he shall build the house for my name.’ ^9

**10** “The LORD has performed his word that he spoke; for I have risen up in the place of David my father, and sit on the throne of Israel, as the LORD promised, and have built the house for the name of the LORD, the God of Israel. ^10

**11** There I have set the ark, in which is the LORD’s covenant, which he made with the children of Israel.” ^11

**12** He stood before the LORD’s altar in the presence of all the assembly of Israel, and spread out his hands ^12

**13** (for Solomon had made a bronze platform, five cubits long, five cubits wide, and three cubits high, and had set it in the middle of the court; and he stood on it, and knelt down on his knees before all the assembly of Israel, and spread out his hands toward heaven). ^13

**14** Then he said, “LORD, the God of Israel, there is no God like you in heaven or on earth—you who keep covenant and loving kindness with your servants who walk before you with all their heart; ^14

**15** who have kept with your servant David my father that which you promised him. Yes, you spoke with your mouth, and have fulfilled it with your hand, as it is today. ^15

**16** “Now therefore, LORD, the God of Israel, keep with your servant David my father that which you have promised him, saying, ‘There shall not fail you a man in my sight to sit on the throne of Israel, if only your children take heed to their way, to walk in my law as you have walked before me.’ ^16

**17** Now therefore, LORD, the God of Israel, let your word be verified, which you spoke to your servant David. ^17

**18** “But will God indeed dwell with men on the earth? Behold, heaven and the heaven of heavens can’t contain you; how much less this house which I have built! ^18

**19** Yet have respect for the prayer of your servant and to his supplication, LORD my God, to listen to the cry and to the prayer which your servant prays before you; ^19

**20** that your eyes may be open toward this house day and night, even toward the place where you have said that you would put your name, to listen to the prayer which your servant will pray toward this place. ^20

**21** Listen to the petitions of your servant and of your people Israel, when they pray toward this place. Yes, hear from your dwelling place, even from heaven; and when you hear, forgive. ^21

**22** “If a man sins against his neighbor, and an oath is laid on him to cause him to swear, and he comes and swears before your altar in this house, ^22

**23** then hear from heaven, act, and judge your servants, bringing retribution to the wicked, to bring his way on his own head; and justifying the righteous, to give him according to his righteousness. ^23

**24** “If your people Israel are struck down before the enemy because they have sinned against you, and they turn again and confess your name, and pray and make supplication before you in this house, ^24

**25** then hear from heaven, and forgive the sin of your people Israel, and bring them again to the land which you gave to them and to their fathers. ^25

**26** “When the sky is shut up and there is no rain because they have sinned against you, if they pray toward this place and confess your name, and turn from their sin when you afflict them, ^26

**27** then hear in heaven, and forgive the sin of your servants, your people Israel, when you teach them the good way in which they should walk, and send rain on your land, which you have given to your people for an inheritance. ^27

**28** “If there is famine in the land, if there is pestilence, if there is blight or mildew, locust or caterpillar; if their enemies besiege them in the land of their cities; whatever plague or whatever sickness there is— ^28

**29** whatever prayer and supplication is made by any man, or by all your people Israel, who will each know his own plague and his own sorrow, and shall spread out his hands toward this house, ^29

**30** then hear from heaven your dwelling place and forgive, and give to every man according to all his ways, whose heart you know (for you, even you only, know the hearts of the children of men), ^30

**31** that they may fear you, to walk in your ways as long as they live in the land which you gave to our fathers. ^31

**32** “Moreover, concerning the foreigner, who is not of your people Israel, when he comes from a far country for your great name’s sake and your mighty hand and your outstretched arm, when they come and pray toward this house, ^32

**33** then hear from heaven, even from your dwelling place, and do according to all that the foreigner calls to you for; that all the peoples of the earth may know your name and fear you, as do your people Israel, and that they may know that this house which I have built is called by your name. ^33

**34** “If your people go out to battle against their enemies, by whatever way you send them, and they pray to you toward this city which you have chosen, and the house which I have built for your name; ^34

**35** then hear from heaven their prayer and their supplication, and maintain their cause. ^35

**36** “If they sin against you (for there is no man who doesn’t sin), and you are angry with them and deliver them to the enemy, so that they carry them away captive to a land far off or near; ^36

**37** yet if they come to their senses in the land where they are carried captive, and turn again, and make supplication to you in the land of their captivity, saying, ‘We have sinned, we have done perversely, and have dealt wickedly;’ ^37

**38** if they return to you with all their heart and with all their soul in the land of their captivity, where they have been taken captive, and pray toward their land which you gave to their fathers, and the city which you have chosen, and toward the house which I have built for your name; ^38

**39** then hear from heaven, even from your dwelling place, their prayer and their petitions, and maintain their cause, and forgive your people who have sinned against you. ^39

**40** “Now, my God, let, I beg you, your eyes be open, and let your ears be attentive to the prayer that is made in this place. ^40

**41** “Now therefore arise, LORD God, into your resting place, you, and the ark of your strength. Let your priests, LORD God, be clothed with salvation, and let your saints rejoice in goodness. ^41

**42** “LORD God, don’t turn away the face of your anointed. Remember your loving kindnesses to David your servant.” ^42

← [[2 Chronicles 5 - WEBU]] | [[2 Chronicles 7 - WEBU]] →
