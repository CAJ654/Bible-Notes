---
book: 2 Chronicles
chapter: 9
version: WEBU
---
# 2 Chronicles 9 (WEBU)

← [[2 Chronicles 8 - WEBU]] | [[2 Chronicles 10 - WEBU]] →

**1** When the queen of Sheba heard of the fame of Solomon, she came to test Solomon with hard questions at Jerusalem, with a very great caravan, including camels that bore spices, gold in abundance, and precious stones. When she had come to Solomon, she talked with him about all that was in her heart. ^1

**2** Solomon answered all her questions. There wasn’t anything hidden from Solomon which he didn’t tell her. ^2

**3** When the queen of Sheba had seen the wisdom of Solomon, the house that he had built, ^3

**4** the food of his table, the seating of his servants, the attendance of his ministers, their clothing, his cup bearers and their clothing, and his ascent by which he went up to the LORD’s house, there was no more spirit in her. ^4

**5** She said to the king, “It was a true report that I heard in my own land of your acts and of your wisdom. ^5

**6** However I didn’t believe their words until I came, and my eyes had seen it; and behold half of the greatness of your wisdom wasn’t told me. You exceed the fame that I heard! ^6

**7** Happy are your men, and happy are these your servants, who stand continually before you and hear your wisdom. ^7

**8** Blessed be the LORD your God, who delighted in you and set you on his throne to be king for the LORD your God, because your God loved Israel, to establish them forever. Therefore he made you king over them, to do justice and righteousness.” ^8

**9** She gave the king one hundred and twenty talents of gold, spices in great abundance, and precious stones. There was never before such spice as the queen of Sheba gave to King Solomon. ^9

**10** The servants of Huram and the servants of Solomon, who brought gold from Ophir, also brought algum trees and precious stones. ^10

**11** The king used algum tree wood to make terraces for the LORD’s house and for the king’s house, and harps and stringed instruments for the singers. There were none like these seen before in the land of Judah. ^11

**12** King Solomon gave to the queen of Sheba all her desire, whatever she asked, more than that which she had brought to the king. So she turned and went to her own land, she and her servants. ^12

**13** Now the weight of gold that came to Solomon in one year was six hundred sixty-six talents of gold, ^13

**14** in addition to that which the traders and merchants brought. All the kings of Arabia and the governors of the country brought gold and silver to Solomon. ^14

**15** King Solomon made two hundred large shields of beaten gold. Six hundred shekels of beaten gold went to one large shield. ^15

**16** He made three hundred shields of beaten gold. Three hundred shekels of gold went to one shield. The king put them in the House of the Forest of Lebanon. ^16

**17** Moreover the king made a great throne of ivory, and overlaid it with pure gold. ^17

**18** There were six steps to the throne, with a footstool of gold, which were fastened to the throne, and armrests on either side by the place of the seat, and two lions standing beside the armrests. ^18

**19** Twelve lions stood there on the one side and on the other on the six steps. There was nothing like it made in any other kingdom. ^19

**20** All King Solomon’s drinking vessels were of gold, and all the vessels of the House of the Forest of Lebanon were of pure gold. Silver was not considered valuable in the days of Solomon. ^20

**21** For the king had ships that went to Tarshish with Huram’s servants. Once every three years, the ships of Tarshish came bringing gold, silver, ivory, apes, and peacocks. ^21

**22** So King Solomon exceeded all the kings of the earth in riches and wisdom. ^22

**23** All the kings of the earth sought the presence of Solomon to hear his wisdom, which God had put in his heart. ^23

**24** They each brought tribute: vessels of silver, vessels of gold, clothing, armor, spices, horses, and mules every year. ^24

**25** Solomon had four thousand stalls for horses and chariots, and twelve thousand horsemen that he stationed in the chariot cities and with the king at Jerusalem. ^25

**26** He ruled over all the kings from the River even to the land of the Philistines, and to the border of Egypt. ^26

**27** The king made silver as common in Jerusalem as stones, and he made cedars to be as abundant as the sycamore trees that are in the lowland. ^27

**28** They brought horses for Solomon out of Egypt and out of all lands. ^28

**29** Now the rest of the acts of Solomon, first and last, aren’t they written in the history of Nathan the prophet, and in the prophecy of Ahijah the Shilonite, and in the visions of Iddo the seer concerning Jeroboam the son of Nebat? ^29

**30** Solomon reigned in Jerusalem over all Israel forty years. ^30

**31** Solomon slept with his fathers, and he was buried in his father David’s city; and Rehoboam his son reigned in his place. ^31

← [[2 Chronicles 8 - WEBU]] | [[2 Chronicles 10 - WEBU]] →
