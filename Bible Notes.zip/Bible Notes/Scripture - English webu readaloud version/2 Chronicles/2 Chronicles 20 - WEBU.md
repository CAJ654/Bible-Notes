---
book: 2 Chronicles
chapter: 20
version: WEBU
---
# 2 Chronicles 20 (WEBU)

← [[2 Chronicles 19 - WEBU]] | [[2 Chronicles 21 - WEBU]] →

**1** After this, the children of Moab, the children of Ammon, and with them some of the Meunites, came against Jehoshaphat to battle. ^1

**2** Then some came who told Jehoshaphat, saying, “A great multitude is coming against you from beyond the sea from Syria. Behold, they are in Hazazon Tamar” (that is, En Gedi). ^2

**3** Jehoshaphat was alarmed, and set himself to seek the LORD. He proclaimed a fast throughout all Judah. ^3

**4** Judah gathered themselves together to seek help from the LORD. They came out of all the cities of Judah to seek the LORD. ^4

**5** Jehoshaphat stood in the assembly of Judah and Jerusalem, in the LORD’s house, before the new court; ^5

**6** and he said, “LORD, the God of our fathers, aren’t you God in heaven? Aren’t you ruler over all the kingdoms of the nations? Power and might are in your hand, so that no one is able to withstand you. ^6

**7** Didn’t you, our God, drive out the inhabitants of this land before your people Israel, and give it to the offspring of Abraham your friend forever? ^7

**8** They lived in it, and have built you a sanctuary in it for your name, saying, ^8

**9** ‘If evil comes on us—the sword, judgment, pestilence, or famine—we will stand before this house, and before you (for your name is in this house), and cry to you in our affliction, and you will hear and save.’ ^9

**10** Now, behold, the children of Ammon and Moab and Mount Seir, whom you would not let Israel invade when they came out of the land of Egypt, but they turned away from them, and didn’t destroy them; ^10

**11** behold, how they reward us, to come to cast us out of your possession, which you have given us to inherit. ^11

**12** Our God, will you not judge them? For we have no might against this great company that comes against us. We don’t know what to do, but our eyes are on you.” ^12

**13** All Judah stood before the LORD, with their little ones, their wives, and their children. ^13

**14** Then the LORD’s Spirit came on Jahaziel the son of Zechariah, the son of Benaiah, the son of Jeiel, the son of Mattaniah, the Levite, of the sons of Asaph, in the middle of the assembly; ^14

**15** and he said, “Listen, all Judah, and you inhabitants of Jerusalem, and you, King Jehoshaphat. The LORD says to you, ‘Don’t be afraid, and don’t be dismayed because of this great multitude; for the battle is not yours, but God’s. ^15

**16** Tomorrow, go down against them. Behold, they are coming up by the ascent of Ziz. You will find them at the end of the valley, before the wilderness of Jeruel. ^16

**17** You will not need to fight this battle. Set yourselves, stand still, and see the salvation of the LORD with you, O Judah and Jerusalem. Don’t be afraid, nor be dismayed. Go out against them tomorrow, for the LORD is with you.’” ^17

**18** Jehoshaphat bowed his head with his face to the ground; and all Judah and the inhabitants of Jerusalem fell down before the LORD, worshiping the LORD. ^18

**19** The Levites, of the children of the Kohathites and of the children of the Korahites, stood up to praise the LORD, the God of Israel, with an exceedingly loud voice. ^19

**20** They rose early in the morning and went out into the wilderness of Tekoa. As they went out, Jehoshaphat stood and said, “Listen to me, Judah and you inhabitants of Jerusalem! Believe in the LORD your God, so you will be established! Believe his prophets, so you will prosper.” ^20

**21** When he had taken counsel with the people, he appointed those who were to sing to the LORD and give praise in holy array as they go out before the army, and say, “Give thanks to the LORD, for his loving kindness endures forever.” ^21

**22** When they began to sing and to praise, the LORD set ambushers against the children of Ammon, Moab, and Mount Seir, who had come against Judah; and they were struck. ^22

**23** For the children of Ammon and Moab stood up against the inhabitants of Mount Seir to utterly kill and destroy them. When they had finished the inhabitants of Seir, everyone helped to destroy each other. ^23

**24** When Judah came to the place overlooking the wilderness, they looked at the multitude; and behold, they were dead bodies fallen to the earth, and there were none who escaped. ^24

**25** When Jehoshaphat and his people came to take their plunder, they found among them in abundance both riches and dead bodies with precious jewels, which they stripped off for themselves, more than they could carry away. They took plunder for three days, it was so much. ^25

**26** On the fourth day, they assembled themselves in Beracah Valley, for there they blessed the LORD. Therefore the name of that place was called “Beracah Valley” to this day. ^26

**27** Then they returned, every man of Judah and Jerusalem, with Jehoshaphat in front of them, to go again to Jerusalem with joy; for the LORD had made them to rejoice over their enemies. ^27

**28** They came to Jerusalem with stringed instruments, harps, and trumpets to the LORD’s house. ^28

**29** The fear of God was on all the kingdoms of the countries when they heard that the LORD fought against the enemies of Israel. ^29

**30** So the realm of Jehoshaphat was quiet, for his God gave him rest all around. ^30

**31** So Jehoshaphat reigned over Judah. He was thirty-five years old when he began to reign. He reigned twenty-five years in Jerusalem. His mother’s name was Azubah the daughter of Shilhi. ^31

**32** He walked in the way of Asa his father, and didn’t turn away from it, doing that which was right in the LORD’s eyes. ^32

**33** However the high places were not taken away, and the people had still not set their hearts on the God of their fathers. ^33

**34** Now the rest of the acts of Jehoshaphat, first and last, behold, they are written in the history of Jehu the son of Hanani, which is included in the book of the kings of Israel. ^34

**35** After this, Jehoshaphat king of Judah joined himself with Ahaziah king of Israel. The same did very wickedly. ^35

**36** He joined himself with him to make ships to go to Tarshish. They made the ships in Ezion Geber. ^36

**37** Then Eliezer the son of Dodavahu of Mareshah prophesied against Jehoshaphat, saying, “Because you have joined yourself with Ahaziah, the LORD has destroyed your works.” The ships were wrecked, so that they were not able to go to Tarshish. ^37

← [[2 Chronicles 19 - WEBU]] | [[2 Chronicles 21 - WEBU]] →
