---
book: 2 Chronicles
chapter: 14
version: WEBU
---
# 2 Chronicles 14 (WEBU)

← [[2 Chronicles 13 - WEBU]] | [[2 Chronicles 15 - WEBU]] →

**1** So Abijah slept with his fathers, and they buried him in David’s city; and Asa his son reigned in his place. In his days, the land was quiet ten years. ^1

**2** Asa did that which was good and right in the LORD his God’s eyes, ^2

**3** for he took away the foreign altars and the high places, broke down the pillars, cut down the Asherah poles, ^3

**4** and commanded Judah to seek the LORD, the God of their fathers, and to obey his law and command. ^4

**5** Also he took away out of all the cities of Judah the high places and the sun images; and the kingdom was quiet before him. ^5

**6** He built fortified cities in Judah; for the land was quiet, and he had no war in those years, because the LORD had given him rest. ^6

**7** For he said to Judah, “Let’s build these cities and make walls around them, with towers, gates, and bars. The land is yet before us, because we have sought the LORD our God. We have sought him, and he has given us rest on every side.” So they built and prospered. ^7

**8** Asa had an army of three hundred thousand out of Judah who bore bucklers and spears, and two hundred eighty thousand out of Benjamin who bore shields and drew bows. All these were mighty men of valor. ^8

**9** Zerah the Ethiopian came out against them with an army of a million troops and three hundred chariots, and he came to Mareshah. ^9

**10** Then Asa went out to meet him, and they set the battle in array in the valley of Zephathah at Mareshah. ^10

**11** Asa cried to the LORD his God, and said, “LORD, there is no one besides you to help, between the mighty and him who has no strength. Help us, LORD our God; for we rely on you, and in your name we have come against this multitude. LORD, you are our God. Don’t let man prevail against you.” ^11

**12** So the LORD struck the Ethiopians before Asa and before Judah; and the Ethiopians fled. ^12

**13** Asa and the people who were with him pursued them to Gerar. So many of the Ethiopians fell that they could not recover themselves, for they were destroyed before the LORD and before his army. Judah’s army carried away very much booty. ^13

**14** They struck all the cities around Gerar, for the fear of the LORD came on them. They plundered all the cities, for there was much plunder in them. ^14

**15** They also struck the tents of those who had livestock, and carried away sheep and camels in abundance, then returned to Jerusalem. ^15

← [[2 Chronicles 13 - WEBU]] | [[2 Chronicles 15 - WEBU]] →
