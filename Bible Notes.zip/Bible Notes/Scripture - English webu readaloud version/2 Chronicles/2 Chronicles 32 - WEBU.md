---
book: 2 Chronicles
chapter: 32
version: WEBU
---
# 2 Chronicles 32 (WEBU)

← [[2 Chronicles 31 - WEBU]] | [[2 Chronicles 33 - WEBU]] →

**1** After these things and this faithfulness, Sennacherib king of Assyria came, entered into Judah, encamped against the fortified cities, and intended to win them for himself. ^1

**2** When Hezekiah saw that Sennacherib had come, and that he was planning to fight against Jerusalem, ^2

**3** he took counsel with his princes and his mighty men to stop the waters of the springs which were outside of the city, and they helped him. ^3

**4** Then many people gathered together and they stopped all the springs and the brook that flowed through the middle of the land, saying, “Why should the kings of Assyria come, and find abundant water?” ^4

**5** He took courage, built up all the wall that was broken down, and raised it up to the towers, with the other wall outside, and strengthened Millo in David’s city, and made weapons and shields in abundance. ^5

**6** He set captains of war over the people, gathered them together to him in the wide place at the gate of the city, and spoke encouragingly to them, saying, ^6

**7** “Be strong and courageous. Don’t be afraid or dismayed because of the king of Assyria, nor for all the multitude who is with him; for there is a greater one with us than with him. ^7

**8** An arm of flesh is with him, but the LORD our God is with us to help us and to fight our battles.” The people rested themselves on the words of Hezekiah king of Judah. ^8

**9** After this, Sennacherib king of Assyria sent his servants to Jerusalem, (now he was attacking Lachish, and all his forces were with him), to Hezekiah king of Judah, and to all Judah who were at Jerusalem, saying, ^9

**10** Sennacherib king of Assyria says, “In whom do you trust, that you remain under siege in Jerusalem? ^10

**11** Doesn’t Hezekiah persuade you to give you over to die by famine and by thirst, saying, ‘The LORD our God will deliver us out of the hand of the king of Assyria’? ^11

**12** Hasn’t the same Hezekiah taken away his high places and his altars, and commanded Judah and Jerusalem, saying, ‘You shall worship before one altar, and you shall burn incense on it’? ^12

**13** Don’t you know what I and my fathers have done to all the peoples of the lands? Were the gods of the nations of those lands in any way able to deliver their land out of my hand? ^13

**14** Who was there among all the gods of those nations which my fathers utterly destroyed that could deliver his people out of my hand, that your God should be able to deliver you out of my hand? ^14

**15** Now therefore don’t let Hezekiah deceive you nor persuade you in this way. Don’t believe him, for no god of any nation or kingdom was able to deliver his people out of my hand, and out of the hand of my fathers. How much less will your God deliver you out of my hand?” ^15

**16** His servants spoke yet more against the LORD God and against his servant Hezekiah. ^16

**17** He also wrote letters insulting the LORD, the God of Israel, and speaking against him, saying, “As the gods of the nations of the lands, which have not delivered their people out of my hand, so shall the God of Hezekiah not deliver his people out of my hand.” ^17

**18** They called out with a loud voice in the Jews’ language to the people of Jerusalem who were on the wall, to frighten them and to trouble them, that they might take the city. ^18

**19** They spoke of the God of Jerusalem as of the gods of the peoples of the earth, which are the work of men’s hands. ^19

**20** Hezekiah the king and Isaiah the prophet, the son of Amoz, prayed because of this, and cried to heaven. ^20

**21** The LORD sent an angel, who cut off all the mighty men of valor, the leaders, and captains in the camp of the king of Assyria. So he returned with shame of face to his own land. When he had come into the house of his god, those who came out of his own body killed him there with the sword. ^21

**22** Thus the LORD saved Hezekiah and the inhabitants of Jerusalem from the hand of Sennacherib the king of Assyria and from the hand of all others, and guided them on every side. ^22

**23** Many brought gifts to the LORD to Jerusalem, and precious things to Hezekiah king of Judah, so that he was exalted in the sight of all nations from then on. ^23

**24** In those days Hezekiah was terminally ill, and he prayed to the LORD; and he spoke to him, and gave him a sign. ^24

**25** But Hezekiah didn’t reciprocate appropriate to the benefit done for him, because his heart was lifted up. Therefore there was wrath on him, Judah, and Jerusalem. ^25

**26** However, Hezekiah humbled himself for the pride of his heart, both he and the inhabitants of Jerusalem, so that the LORD’s wrath didn’t come on them in the days of Hezekiah. ^26

**27** Hezekiah had exceedingly great riches and honor. He provided himself with treasuries for silver, for gold, for precious stones, for spices, for shields, and for all kinds of valuable vessels; ^27

**28** also storehouses for the increase of grain, new wine, and oil; and stalls for all kinds of animals, and flocks in folds. ^28

**29** Moreover he provided for himself cities, and possessions of flocks and herds in abundance; for God had given him abundant possessions. ^29

**30** This same Hezekiah also stopped the upper spring of the waters of Gihon, and brought them straight down on the west side of David’s city. Hezekiah prospered in all his works. ^30

**31** However, concerning the ambassadors of the princes of Babylon, who sent to him to inquire of the wonder that was done in the land, God left him to test him, that he might know all that was in his heart. ^31

**32** Now the rest of the acts of Hezekiah and his good deeds, behold, they are written in the vision of Isaiah the prophet, the son of Amoz, in the book of the kings of Judah and Israel. ^32

**33** Hezekiah slept with his fathers, and they buried him in the ascent to the tombs of the sons of David. All Judah and the inhabitants of Jerusalem honored him at his death. Manasseh his son reigned in his place. ^33

← [[2 Chronicles 31 - WEBU]] | [[2 Chronicles 33 - WEBU]] →
