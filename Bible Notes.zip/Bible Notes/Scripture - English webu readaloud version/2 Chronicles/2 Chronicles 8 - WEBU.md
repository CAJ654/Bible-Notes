---
book: 2 Chronicles
chapter: 8
version: WEBU
---
# 2 Chronicles 8 (WEBU)

← [[2 Chronicles 7 - WEBU]] | [[2 Chronicles 9 - WEBU]] →

**1** At the end of twenty years, in which Solomon had built the LORD’s house and his own house, ^1

**2** Solomon built the cities which Huram had given to Solomon, and caused the children of Israel to dwell there. ^2

**3** Solomon went to Hamath Zobah, and prevailed against it. ^3

**4** He built Tadmor in the wilderness, and all the storage cities, which he built in Hamath. ^4

**5** Also he built Beth Horon the upper and Beth Horon the lower, fortified cities with walls, gates, and bars; ^5

**6** and Baalath, and all the storage cities that Solomon had, and all the cities for his chariots, the cities for his horsemen, and all that Solomon desired to build for his pleasure in Jerusalem, in Lebanon, and in all the land of his dominion. ^6

**7** As for all the people who were left of the Hittites, the Amorites, the Perizzites, the Hivites, and the Jebusites, who were not of Israel— ^7

**8** of their children who were left after them in the land, whom the children of Israel didn’t consume—of them Solomon conscripted forced labor to this day. ^8

**9** But of the children of Israel, Solomon made no servants for his work, but they were men of war, chief of his captains, and rulers of his chariots and of his horsemen. ^9

**10** These were the chief officers of King Solomon, even two-hundred fifty, who ruled over the people. ^10

**11** Solomon brought up Pharaoh’s daughter out of David’s city to the house that he had built for her; for he said, “My wife shall not dwell in the house of David king of Israel, because the places where the LORD’s ark has come are holy.” ^11

**12** Then Solomon offered burnt offerings to the LORD on the LORD’s altar which he had built before the porch, ^12

**13** even as the duty of every day required, offering according to the commandment of Moses on the Sabbaths, on the new moons, and on the set feasts, three times per year, during the feast of unleavened bread, during the feast of weeks, and during the feast of booths. ^13

**14** He appointed, according to the ordinance of David his father, the divisions of the priests to their service, and the Levites to their offices, to praise and to minister before the priests, as the duty of every day required, the doorkeepers also by their divisions at every gate, for David the man of God had so commanded. ^14

**15** They didn’t depart from the commandment of the king to the priests and Levites concerning any matter or concerning the treasures. ^15

**16** Now all the work of Solomon was accomplished from the day of the foundation of the LORD’s house until it was finished. So the LORD’s house was completed. ^16

**17** Then Solomon went to Ezion Geber and to Eloth, on the seashore in the land of Edom. ^17

**18** Huram sent him ships and servants who had knowledge of the sea by the hands of his servants; and they came with the servants of Solomon to Ophir, and brought from there four hundred fifty talents of gold, and brought them to King Solomon. ^18

← [[2 Chronicles 7 - WEBU]] | [[2 Chronicles 9 - WEBU]] →
