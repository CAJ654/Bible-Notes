---
book: 2 Chronicles
chapter: 23
version: WEBU
---
# 2 Chronicles 23 (WEBU)

← [[2 Chronicles 22 - WEBU]] | [[2 Chronicles 24 - WEBU]] →

**1** In the seventh year, Jehoiada strengthened himself, and took the captains of hundreds—Azariah the son of Jeroham, Ishmael the son of Jehohanan, Azariah the son of Obed, Maaseiah the son of Adaiah, and Elishaphat the son of Zichri—into a covenant with him. ^1

**2** They went around in Judah and gathered the Levites out of all the cities of Judah, and the heads of fathers’ households of Israel, and they came to Jerusalem. ^2

**3** All the assembly made a covenant with the king in God’s house. Jehoiada said to them, “Behold, the king’s son must reign, as the LORD has spoken concerning the sons of David. ^3

**4** This is the thing that you must do: a third part of you, who come in on the Sabbath, of the priests and of the Levites, shall be gatekeepers of the thresholds. ^4

**5** A third part shall be at the king’s house; and a third part at the gate of the foundation. All the people will be in the courts of the LORD’s house. ^5

**6** But let no one come into the LORD’s house except the priests and those who minister of the Levites. They shall come in, for they are holy, but all the people shall follow the LORD’s instructions. ^6

**7** The Levites shall surround the king, every man with his weapons in his hand. Whoever comes into the house, let him be slain. Be with the king when he comes in and when he goes out.” ^7

**8** So the Levites and all Judah did according to all that Jehoiada the priest commanded. They each took his men, those who were to come in on the Sabbath, with those who were to go out on the Sabbath, for Jehoiada the priest didn’t dismiss the shift. ^8

**9** Jehoiada the priest delivered to the captains of hundreds the spears, bucklers, and shields that had been king David’s, which were in God’s house. ^9

**10** He set all the people, every man with his weapon in his hand, from the right side of the house to the left side of the house, near the altar and the house, around the king. ^10

**11** Then they brought out the king’s son, put the crown on him, gave him the covenant, and made him king. Jehoiada and his sons anointed him, and they said, “Long live the king!” ^11

**12** When Athaliah heard the noise of the people running and praising the king, she came to the people into the LORD’s house. ^12

**13** Then she looked, and behold, the king stood by his pillar at the entrance, with the captains and the trumpeters by the king. All the people of the land rejoiced and blew trumpets. The singers also played musical instruments, and led the singing of praise. Then Athaliah tore her clothes, and said, “Treason! treason!” ^13

**14** Jehoiada the priest brought out the captains of hundreds who were set over the army, and said to them, “Bring her out between the ranks; and whoever follows her, let him be slain with the sword.” For the priest said, “Don’t kill her in the LORD’s house.” ^14

**15** So they made way for her. She went to the entrance of the horse gate to the king’s house; and they killed her there. ^15

**16** Jehoiada made a covenant between himself, all the people, and the king, that they should be the LORD’s people. ^16

**17** All the people went to the house of Baal, broke it down, broke his altars and his images in pieces, and killed Mattan the priest of Baal before the altars. ^17

**18** Jehoiada appointed the officers of the LORD’s house under the hand of the Levitical priests, whom David had distributed in the LORD’s house, to offer the burnt offerings of the LORD, as it is written in the law of Moses, with rejoicing and with singing, as David had ordered. ^18

**19** He set the gatekeepers at the gates of the LORD’s house, that no one who was unclean in anything should enter in. ^19

**20** He took the captains of hundreds, the nobles, the governors of the people, and all the people of the land, and brought the king down from the LORD’s house. They came through the upper gate to the king’s house, and set the king on the throne of the kingdom. ^20

**21** So all the people of the land rejoiced, and the city was quiet. They had slain Athaliah with the sword. ^21

← [[2 Chronicles 22 - WEBU]] | [[2 Chronicles 24 - WEBU]] →
