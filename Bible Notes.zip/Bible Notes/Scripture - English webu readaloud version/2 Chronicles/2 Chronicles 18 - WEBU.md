---
book: 2 Chronicles
chapter: 18
version: WEBU
---
# 2 Chronicles 18 (WEBU)

← [[2 Chronicles 17 - WEBU]] | [[2 Chronicles 19 - WEBU]] →

**1** Now Jehoshaphat had riches and honor in abundance; and he allied himself with Ahab. ^1

**2** After some years, he went down to Ahab to Samaria. Ahab killed sheep and cattle for him in abundance, and for the people who were with him, and moved him to go up with him to Ramoth Gilead. ^2

**3** Ahab king of Israel said to Jehoshaphat king of Judah, “Will you go with me to Ramoth Gilead?” He answered him, “I am as you are, and my people as your people. We will be with you in the war.” ^3

**4** Jehoshaphat said to the king of Israel, “Please inquire first for the LORD’s word.” ^4

**5** Then the king of Israel gathered the prophets together, four hundred men, and said to them, “Shall we go to Ramoth Gilead to battle, or shall I forbear?” They said, “Go up, for God will deliver it into the hand of the king.” ^5

**6** But Jehoshaphat said, “Isn’t there here a prophet of the LORD besides, that we may inquire of him?” ^6

**7** The king of Israel said to Jehoshaphat, “There is yet one man by whom we may inquire of the LORD; but I hate him, for he never prophesies good concerning me, but always evil. He is Micaiah the son of Imla.” Jehoshaphat said, “Don’t let the king say so.” ^7

**8** Then the king of Israel called an officer, and said, “Get Micaiah the son of Imla quickly.” ^8

**9** Now the king of Israel and Jehoshaphat the king of Judah each sat on his throne, arrayed in their robes, and they were sitting in an open place at the entrance of the gate of Samaria; and all the prophets were prophesying before them. ^9

**10** Zedekiah the son of Chenaanah made himself horns of iron and said, “The LORD says, ‘With these you shall push the Syrians, until they are consumed.’” ^10

**11** All the prophets prophesied so, saying, “Go up to Ramoth Gilead, and prosper; for the LORD will deliver it into the hand of the king.” ^11

**12** The messenger who went to call Micaiah spoke to him, saying, “Behold, the words of the prophets declare good to the king with one mouth. Let your word therefore, please be like one of theirs, and speak good.” ^12

**13** Micaiah said, “As the LORD lives, I will say what my God says.” ^13

**14** When he had come to the king, the king said to him, “Micaiah, shall we go to Ramoth Gilead to battle, or shall I forbear?” He said, “Go up, and prosper. They shall be delivered into your hand.” ^14

**15** The king said to him, “How many times shall I adjure you that you speak to me nothing but the truth in the LORD’s name?” ^15

**16** He said, “I saw all Israel scattered on the mountains, as sheep that have no shepherd. The LORD said, ‘These have no master. Let them each return to his house in peace.’” ^16

**17** The king of Israel said to Jehoshaphat, “Didn’t I tell you that he would not prophesy good concerning me, but evil?” ^17

**18** Micaiah said, “Therefore hear the LORD’s word: I saw the LORD sitting on his throne, and all the army of heaven standing on his right hand and on his left. ^18

**19** The LORD said, ‘Who will entice Ahab king of Israel, that he may go up and fall at Ramoth Gilead?’ One spoke saying in this way, and another saying in that way. ^19

**20** A spirit came out, stood before the LORD, and said, ‘I will entice him.’ “The LORD said to him, ‘How?’ ^20

**21** “He said, ‘I will go, and will be a lying spirit in the mouth of all his prophets.’ “He said, ‘You will entice him, and will prevail also. Go and do so.’ ^21

**22** “Now therefore, behold, the LORD has put a lying spirit in the mouth of these your prophets; and the LORD has spoken evil concerning you.” ^22

**23** Then Zedekiah the son of Chenaanah came near, and struck Micaiah on the cheek, and said, “Which way did the LORD’s Spirit go from me to speak to you?” ^23

**24** Micaiah said, “Behold, you shall see on that day, when you go into an inner room to hide yourself.” ^24

**25** The king of Israel said, “Take Micaiah, and carry him back to Amon the governor of the city, and to Joash the king’s son; ^25

**26** and say, ‘The king says, “Put this fellow in the prison, and feed him with bread of affliction and with water of affliction, until I return in peace.”’” ^26

**27** Micaiah said, “If you return at all in peace, the LORD has not spoken by me.” He said, “Listen, you people, all of you!” ^27

**28** So the king of Israel and Jehoshaphat the king of Judah went up to Ramoth Gilead. ^28

**29** The king of Israel said to Jehoshaphat, “I will disguise myself, and go into the battle; but you put on your robes.” So the king of Israel disguised himself; and they went into the battle. ^29

**30** Now the king of Syria had commanded the captains of his chariots, saying, “Don’t fight with small nor great, except only with the king of Israel.” ^30

**31** When the captains of the chariots saw Jehoshaphat, they said, “It is the king of Israel!” Therefore they turned around to fight against him. But Jehoshaphat cried out, and the LORD helped him; and God moved them to depart from him. ^31

**32** When the captains of the chariots saw that it was not the king of Israel, they turned back from pursuing him. ^32

**33** A certain man drew his bow at random, and struck the king of Israel between the joints of the armor. Therefore he said to the driver of the chariot, “Turn around and carry me out of the battle, for I am severely wounded.” ^33

**34** The battle increased that day. However, the king of Israel propped himself up in his chariot against the Syrians until the evening; and at about sunset, he died. ^34

← [[2 Chronicles 17 - WEBU]] | [[2 Chronicles 19 - WEBU]] →
