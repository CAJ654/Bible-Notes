---
book: 2 Chronicles
chapter: 21
version: WEBU
---
# 2 Chronicles 21 (WEBU)

← [[2 Chronicles 20 - WEBU]] | [[2 Chronicles 22 - WEBU]] →

**1** Jehoshaphat slept with his fathers, and was buried with his fathers in David’s city; and Jehoram his son reigned in his place. ^1

**2** He had brothers, the sons of Jehoshaphat: Azariah, Jehiel, Zechariah, Azariah, Michael, and Shephatiah. All these were the sons of Jehoshaphat king of Israel. ^2

**3** Their father gave them great gifts of silver, of gold, and of precious things, with fortified cities in Judah; but he gave the kingdom to Jehoram, because he was the firstborn. ^3

**4** Now when Jehoram had risen up over the kingdom of his father, and had strengthened himself, he killed all his brothers with the sword, and also some of the princes of Israel. ^4

**5** Jehoram was thirty-two years old when he began to reign, and he reigned eight years in Jerusalem. ^5

**6** He walked in the way of the kings of Israel, as did Ahab’s house, for he had Ahab’s daughter as his wife. He did that which was evil in the LORD’s sight. ^6

**7** However the LORD would not destroy David’s house, because of the covenant that he had made with David, and as he promised to give a lamp to him and to his children always. ^7

**8** In his days Edom revolted from under the hand of Judah, and made a king over themselves. ^8

**9** Then Jehoram went there with his captains and all his chariots with him. He rose up by night and struck the Edomites who surrounded him, along with the captains of the chariots. ^9

**10** So Edom has been in revolt from under the hand of Judah to this day. Then Libnah revolted at the same time from under his hand, because he had forsaken the LORD, the God of his fathers. ^10

**11** Moreover he made high places in the mountains of Judah, and made the inhabitants of Jerusalem play the prostitute, and led Judah astray. ^11

**12** A letter came to him from Elijah the prophet, saying, “the LORD, the God of David your father, says, ‘Because you have not walked in the ways of Jehoshaphat your father, nor in the ways of Asa king of Judah, ^12

**13** but have walked in the way of the kings of Israel, and have made Judah and the inhabitants of Jerusalem to play the prostitute like Ahab’s house did, and also have slain your brothers of your father’s house, who were better than yourself, ^13

**14** behold, the LORD will strike your people with a great plague, including your children, your wives, and all your possessions; ^14

**15** and you will have great sickness with a disease of your bowels, until your bowels fall out by reason of the sickness, day by day.’” ^15

**16** The LORD stirred up against Jehoram the spirit of the Philistines and of the Arabians who are beside the Ethiopians; ^16

**17** and they came up against Judah, broke into it, and carried away all the possessions that were found in the king’s house, including his sons and his wives, so that there was no son left to him except Jehoahaz, the youngest of his sons. ^17

**18** After all this the LORD struck him in his bowels with an incurable disease. ^18

**19** In process of time, at the end of two years, his bowels fell out by reason of his sickness, and he died of severe diseases. His people made no burning for him, like the burning of his fathers. ^19

**20** He was thirty-two years old when he began to reign, and he reigned in Jerusalem eight years. He departed with no one’s regret. They buried him in David’s city, but not in the tombs of the kings. ^20

← [[2 Chronicles 20 - WEBU]] | [[2 Chronicles 22 - WEBU]] →
