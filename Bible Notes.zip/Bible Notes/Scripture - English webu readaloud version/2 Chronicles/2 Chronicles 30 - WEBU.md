---
book: 2 Chronicles
chapter: 30
version: WEBU
---
# 2 Chronicles 30 (WEBU)

← [[2 Chronicles 29 - WEBU]] | [[2 Chronicles 31 - WEBU]] →

**1** Hezekiah sent to all Israel and Judah, and wrote letters also to Ephraim and Manasseh, that they should come to the LORD’s house at Jerusalem, to keep the Passover to the LORD, the God of Israel. ^1

**2** For the king had taken counsel with his princes and all the assembly in Jerusalem to keep the Passover in the second month. ^2

**3** For they could not keep it at that time, because the priests had not sanctified themselves in sufficient number, and the people had not gathered themselves together to Jerusalem. ^3

**4** The thing was right in the eyes of the king and of all the assembly. ^4

**5** So they established a decree to make proclamation throughout all Israel, from Beersheba even to Dan, that they should come to keep the Passover to the LORD, the God of Israel, at Jerusalem, for they had not kept it in great numbers in the way it is written. ^5

**6** So the couriers went with the letters from the king and his princes throughout all Israel and Judah, according to the commandment of the king, saying, “You children of Israel, turn again to the LORD, the God of Abraham, Isaac, and Israel, that he may return to the remnant of you that have escaped out of the hand of the kings of Assyria. ^6

**7** Don’t be like your fathers and like your brothers, who trespassed against the LORD, the God of their fathers, so that he gave them up to desolation, as you see. ^7

**8** Now don’t be stiff-necked, as your fathers were, but yield yourselves to the LORD, and enter into his sanctuary, which he has sanctified forever, and serve the LORD your God, that his fierce anger may turn away from you. ^8

**9** For if you turn again to the LORD, your brothers and your children will find compassion with those who led them captive, and will come again into this land, because the LORD your God is gracious and merciful, and will not turn away his face from you if you return to him.” ^9

**10** So the couriers passed from city to city through the country of Ephraim and Manasseh, even to Zebulun, but people ridiculed them and mocked them. ^10

**11** Nevertheless some men of Asher, Manasseh, and Zebulun humbled themselves and came to Jerusalem. ^11

**12** Also the hand of God came on Judah to give them one heart, to do the commandment of the king and of the princes by the LORD’s word. ^12

**13** Many people assembled at Jerusalem to keep the feast of unleavened bread in the second month, a very great assembly. ^13

**14** They arose and took away the altars that were in Jerusalem, and they took away all the altars for incense and threw them into the brook Kidron. ^14

**15** Then they killed the Passover on the fourteenth day of the second month. The priests and the Levites were ashamed, and sanctified themselves, and brought burnt offerings into the LORD’s house. ^15

**16** They stood in their place after their order, according to the law of Moses the man of God. The priests sprinkled the blood which they received of the hand of the Levites. ^16

**17** For there were many in the assembly who had not sanctified themselves; therefore the Levites were in charge of killing the Passovers for everyone who was not clean, to sanctify them to the LORD. ^17

**18** For a multitude of the people, even many of Ephraim, Manasseh, Issachar, and Zebulun, had not cleansed themselves, yet they ate the Passover other than the way it is written. For Hezekiah had prayed for them, saying, “May the good LORD pardon everyone ^18

**19** who sets his heart to seek God, the LORD, the God of his fathers, even if they aren’t clean according to the purification of the sanctuary.” ^19

**20** The LORD listened to Hezekiah, and healed the people. ^20

**21** The children of Israel who were present at Jerusalem kept the feast of unleavened bread seven days with great gladness. The Levites and the priests praised the LORD day by day, singing with loud instruments to the LORD. ^21

**22** Hezekiah spoke encouragingly to all the Levites who had good understanding in the service of the LORD. So they ate throughout the feast for the seven days, offering sacrifices of peace offerings and making confession to the LORD, the God of their fathers. ^22

**23** The whole assembly took counsel to keep another seven days, and they kept another seven days with gladness. ^23

**24** For Hezekiah king of Judah gave to the assembly for offerings one thousand bulls and seven thousand sheep; and the princes gave to the assembly a thousand bulls and ten thousand sheep; and a great number of priests sanctified themselves. ^24

**25** All the assembly of Judah, with the priests and the Levites, and all the assembly who came out of Israel, and the foreigners who came out of the land of Israel and who lived in Judah, rejoiced. ^25

**26** So there was great joy in Jerusalem; for since the time of Solomon the son of David king of Israel there was nothing like this in Jerusalem. ^26

**27** Then the Levitical priests arose and blessed the people. Their voice was heard, and their prayer came up to his holy habitation, even to heaven. ^27

← [[2 Chronicles 29 - WEBU]] | [[2 Chronicles 31 - WEBU]] →
