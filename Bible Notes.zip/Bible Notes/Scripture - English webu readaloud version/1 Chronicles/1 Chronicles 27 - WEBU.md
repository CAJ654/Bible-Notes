---
book: 1 Chronicles
chapter: 27
version: WEBU
---
# 1 Chronicles 27 (WEBU)

← [[1 Chronicles 26 - WEBU]] | [[1 Chronicles 28 - WEBU]] →

**1** Now the children of Israel after their number, the heads of fathers’ households and the captains of thousands and of hundreds, and their officers who served the king in any matter of the divisions which came in and went out month by month throughout all the months of the year—of every division were twenty-four thousand. ^1

**2** Over the first division for the first month was Jashobeam the son of Zabdiel. In his division were twenty-four thousand. ^2

**3** He was of the children of Perez, the chief of all the captains of the army for the first month. ^3

**4** Over the division of the second month was Dodai the Ahohite and his division, and Mikloth the ruler; and in his division were twenty-four thousand. ^4

**5** The third captain of the army for the third month was Benaiah, the son of Jehoiada the chief priest. In his division were twenty-four thousand. ^5

**6** This is that Benaiah who was the mighty man of the thirty and over the thirty. Of his division was Ammizabad his son. ^6

**7** The fourth captain for the fourth month was Asahel the brother of Joab, and Zebadiah his son after him. In his division were twenty-four thousand. ^7

**8** The fifth captain for the fifth month was Shamhuth the Izrahite. In his division were twenty-four thousand. ^8

**9** The sixth captain for the sixth month was Ira the son of Ikkesh the Tekoite. In his division were twenty-four thousand. ^9

**10** The seventh captain for the seventh month was Helez the Pelonite, of the children of Ephraim. In his division were twenty-four thousand. ^10

**11** The eighth captain for the eighth month was Sibbecai the Hushathite, of the Zerahites. In his division were twenty-four thousand. ^11

**12** The ninth captain for the ninth month was Abiezer the Anathothite, of the Benjamites. In his division were twenty-four thousand. ^12

**13** The tenth captain for the tenth month was Maharai the Netophathite, of the Zerahites. In his division were twenty-four thousand. ^13

**14** The eleventh captain for the eleventh month was Benaiah the Pirathonite, of the children of Ephraim. In his division were twenty-four thousand. ^14

**15** The twelfth captain for the twelfth month was Heldai the Netophathite, of Othniel. In his division were twenty-four thousand. ^15

**16** Furthermore over the tribes of Israel: of the Reubenites, Eliezer the son of Zichri was the ruler; of the Simeonites, Shephatiah the son of Maacah; ^16

**17** of Levi, Hashabiah the son of Kemuel; of Aaron, Zadok; ^17

**18** of Judah, Elihu, one of the brothers of David; of Issachar, Omri the son of Michael; ^18

**19** of Zebulun, Ishmaiah the son of Obadiah; of Naphtali, Jeremoth the son of Azriel; ^19

**20** of the children of Ephraim, Hoshea the son of Azaziah; of the half-tribe of Manasseh, Joel the son of Pedaiah; ^20

**21** of the half-tribe of Manasseh in Gilead, Iddo the son of Zechariah; of Benjamin, Jaasiel the son of Abner; ^21

**22** of Dan, Azarel the son of Jeroham. These were the captains of the tribes of Israel. ^22

**23** But David didn’t take the number of them from twenty years old and under, because the LORD had said he would increase Israel like the stars of the sky. ^23

**24** Joab the son of Zeruiah began to take a census, but didn’t finish; and wrath came on Israel for this. The number wasn’t put into the account in the chronicles of King David. ^24

**25** Over the king’s treasures was Azmaveth the son of Adiel. Over the treasures in the fields, in the cities, in the villages, and in the towers was Jonathan the son of Uzziah; ^25

**26** Over those who did the work of the field for tillage of the ground was Ezri the son of Chelub. ^26

**27** Over the vineyards was Shimei the Ramathite. Over the increase of the vineyards for the wine cellars was Zabdi the Shiphmite. ^27

**28** Over the olive trees and the sycamore trees that were in the lowland was Baal Hanan the Gederite. Over the cellars of oil was Joash. ^28

**29** Over the herds that fed in Sharon was Shitrai the Sharonite. Over the herds that were in the valleys was Shaphat the son of Adlai. ^29

**30** Over the camels was Obil the Ishmaelite. Over the donkeys was Jehdeiah the Meronothite. Over the flocks was Jaziz the Hagrite. ^30

**31** All these were the rulers of the property which was King David’s. ^31

**32** Also Jonathan, David’s uncle, was a counselor, a man of understanding, and a scribe. Jehiel the son of Hachmoni was with the king’s sons. ^32

**33** Ahithophel was the king’s counselor. Hushai the Archite was the king’s friend. ^33

**34** After Ahithophel was Jehoiada the son of Benaiah, and Abiathar. Joab was the captain of the king’s army. ^34

← [[1 Chronicles 26 - WEBU]] | [[1 Chronicles 28 - WEBU]] →
