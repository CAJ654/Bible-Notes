---
book: 1 Chronicles
chapter: 28
version: WEBU
---
# 1 Chronicles 28 (WEBU)

← [[1 Chronicles 27 - WEBU]] | [[1 Chronicles 29 - WEBU]] →

**1** David assembled all the princes of Israel, the princes of the tribes, the captains of the companies who served the king by division, the captains of thousands, the captains of hundreds, and the rulers over all the substance and possessions of the king and of his sons, with the officers and the mighty men, even all the mighty men of valor, to Jerusalem. ^1

**2** Then David the king stood up on his feet and said, “Hear me, my brothers and my people! As for me, it was in my heart to build a house of rest for the ark of the LORD’s covenant, and for the footstool of our God; and I had prepared for the building. ^2

**3** But God said to me, ‘You shall not build a house for my name, because you are a man of war and have shed blood.’ ^3

**4** However the LORD, the God of Israel, chose me out of all the house of my father to be king over Israel forever. For he has chosen Judah to be prince; and in the house of Judah, the house of my father; and among the sons of my father he took pleasure in me to make me king over all Israel. ^4

**5** Of all my sons (for the LORD has given me many sons), he has chosen Solomon my son to sit on the throne of the LORD’s kingdom over Israel. ^5

**6** He said to me, ‘Solomon, your son, shall build my house and my courts; for I have chosen him to be my son, and I will be his father. ^6

**7** I will establish his kingdom forever if he continues to do my commandments and my ordinances, as it is today.’ ^7

**8** Now therefore, in the sight of all Israel, the LORD’s assembly, and in the audience of our God, observe and seek out all the commandments of the LORD your God, that you may possess this good land, and leave it for an inheritance to your children after you forever. ^8

**9** You, Solomon my son, know the God of your father, and serve him with a perfect heart and with a willing mind; for the LORD searches all hearts, and understands all the imaginations of the thoughts. If you seek him, he will be found by you; but if you forsake him, he will cast you off forever. ^9

**10** Take heed now, for the LORD has chosen you to build a house for the sanctuary. Be strong, and do it.” ^10

**11** Then David gave to Solomon his son the plans for the porch of the temple, for its houses, for its treasuries, for its upper rooms, for its inner rooms, for the place of the mercy seat; ^11

**12** and the plans of all that he had by the Spirit, for the courts of the LORD’s house, for all the surrounding rooms, for the treasuries of God’s house, and for the treasuries of the dedicated things; ^12

**13** also for the divisions of the priests and the Levites, for all the work of the service of the LORD’s house, and for all the vessels of service in the LORD’s house— ^13

**14** of gold by weight for the gold for all vessels of every kind of service, for all the vessels of silver by weight, for all vessels of every kind of service; ^14

**15** by weight also for the lamp stands of gold, and for its lamps, of gold, by weight for every lamp stand and for its lamps; and for the lamp stands of silver, by weight for every lamp stand and for its lamps, according to the use of every lamp stand; ^15

**16** and the gold by weight for the tables of show bread, for every table; and silver for the tables of silver; ^16

**17** and the forks, the basins, and the cups, of pure gold; and for the golden bowls by weight for every bowl; and for the silver bowls by weight for every bowl; ^17

**18** and for the altar of incense, refined gold by weight; and gold for the plans for the chariot, and the cherubim that spread out and cover the ark of the LORD’s covenant. ^18

**19** “All this”, David said, “I have been made to understand in writing from the LORD’s hand, even all the works of this pattern.” ^19

**20** David said to Solomon his son, “Be strong and courageous, and do it. Don’t be afraid, nor be dismayed, for the LORD God, even my God, is with you. He will not fail you nor forsake you, until all the work for the service of the LORD’s house is finished. ^20

**21** Behold, there are the divisions of the priests and the Levites for all the service of God’s house. Every willing man who has skill for any kind of service shall be with you in all kinds of work. Also the captains and all the people will be entirely at your command.” ^21

← [[1 Chronicles 27 - WEBU]] | [[1 Chronicles 29 - WEBU]] →
