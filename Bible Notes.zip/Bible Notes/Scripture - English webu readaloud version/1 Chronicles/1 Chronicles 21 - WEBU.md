---
book: 1 Chronicles
chapter: 21
version: WEBU
---
# 1 Chronicles 21 (WEBU)

← [[1 Chronicles 20 - WEBU]] | [[1 Chronicles 22 - WEBU]] →

**1** Satan stood up against Israel, and moved David to take a census of Israel. ^1

**2** David said to Joab and to the princes of the people, “Go, count Israel from Beersheba even to Dan; and bring me word, that I may know how many there are.” ^2

**3** Joab said, “May the LORD make his people a hundred times as many as they are. But, my lord the king, aren’t they all my lord’s servants? Why does my lord require this thing? Why will he be a cause of guilt to Israel?” ^3

**4** Nevertheless the king’s word prevailed against Joab. Therefore Joab departed and went throughout all Israel, then came to Jerusalem. ^4

**5** Joab gave the sum of the census of the people to David. All those of Israel were one million one hundred thousand men who drew a sword; and in Judah were four hundred seventy thousand men who drew a sword. ^5

**6** But he didn’t count Levi and Benjamin among them, for the king’s word was abominable to Joab. ^6

**7** God was displeased with this thing; therefore he struck Israel. ^7

**8** David said to God, “I have sinned greatly, in that I have done this thing. But now put away, I beg you, the iniquity of your servant, for I have done very foolishly.” ^8

**9** The LORD spoke to Gad, David’s seer, saying, ^9

**10** “Go and speak to David, saying, ‘The LORD says, “I offer you three things. Choose one of them, that I may do it to you.”’” ^10

**11** So Gad came to David and said to him, “The LORD says, ‘Take your choice: ^11

**12** either three years of famine; or three months to be consumed before your foes, while the sword of your enemies overtakes you; or else three days of the sword of the LORD, even pestilence in the land, and the LORD’s angel destroying throughout all the borders of Israel. Now therefore consider what answer I shall return to him who sent me.’” ^12

**13** David said to Gad, “I am in distress. Let me fall, I pray, into the LORD’s hand, for his mercies are very great. Don’t let me fall into man’s hand.” ^13

**14** So the LORD sent a pestilence on Israel, and seventy thousand men of Israel fell. ^14

**15** God sent an angel to Jerusalem to destroy it. As he was about to destroy, the LORD saw, and he relented of the disaster, and said to the destroying angel, “It is enough. Now withdraw your hand.” the LORD’s angel was standing by the threshing floor of Ornan the Jebusite. ^15

**16** David lifted up his eyes, and saw the LORD’s angel standing between earth and the sky, having a drawn sword in his hand stretched out over Jerusalem. Then David and the elders, clothed in sackcloth, fell on their faces. ^16

**17** David said to God, “Isn’t it I who commanded the people to be counted? It is even I who have sinned and done very wickedly; but these sheep, what have they done? Please let your hand, O LORD my God, be against me and against my father’s house; but not against your people, that they should be plagued.” ^17

**18** Then the LORD’s angel commanded Gad to tell David that David should go up and raise an altar to the LORD on the threshing floor of Ornan the Jebusite. ^18

**19** David went up at the saying of Gad, which he spoke in the LORD’s name. ^19

**20** Ornan turned back and saw the angel; and his four sons who were with him hid themselves. Now Ornan was threshing wheat. ^20

**21** As David came to Ornan, Ornan looked and saw David, and went out of the threshing floor, and bowed himself to David with his face to the ground. ^21

**22** Then David said to Ornan, “Sell me the place of this threshing floor, that I may build an altar to the LORD on it. You shall sell it to me for the full price, that the plague may be stopped from afflicting the people.” ^22

**23** Ornan said to David, “Take it for yourself, and let my lord the king do that which is good in his eyes. Behold, I give the oxen for burnt offerings, and the threshing instruments for wood, and the wheat for the meal offering. I give it all.” ^23

**24** King David said to Ornan, “No, but I will most certainly buy it for the full price. For I will not take that which is yours for the LORD, nor offer a burnt offering that costs me nothing.” ^24

**25** So David gave to Ornan six hundred shekels of gold by weight for the place. ^25

**26** David built an altar to the LORD there, and offered burnt offerings and peace offerings, and called on the LORD; and he answered him from the sky by fire on the altar of burnt offering. ^26

**27** Then the LORD commanded the angel, and he put his sword back into its sheath. ^27

**28** At that time, when David saw that the LORD had answered him in the threshing floor of Ornan the Jebusite, then he sacrificed there. ^28

**29** For the LORD’s tabernacle, which Moses made in the wilderness, and the altar of burnt offering, were at that time in the high place at Gibeon. ^29

**30** But David couldn’t go before it to inquire of God, for he was afraid because of the sword of the LORD’s angel. ^30

← [[1 Chronicles 20 - WEBU]] | [[1 Chronicles 22 - WEBU]] →
