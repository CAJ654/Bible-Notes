---
book: 1 Chronicles
chapter: 17
version: WEBU
---
# 1 Chronicles 17 (WEBU)

← [[1 Chronicles 16 - WEBU]] | [[1 Chronicles 18 - WEBU]] →

**1** When David was living in his house, David said to Nathan the prophet, “Behold, I live in a cedar house, but the ark of the LORD’s covenant is in a tent.” ^1

**2** Nathan said to David, “Do all that is in your heart; for God is with you.” ^2

**3** That same night, the word of God came to Nathan, saying, ^3

**4** “Go and tell David my servant, ‘The LORD says, “You shall not build me a house to dwell in; ^4

**5** for I have not lived in a house since the day that I brought up Israel to this day, but have gone from tent to tent, and from one tent to another. ^5

**6** In all places in which I have walked with all Israel, did I speak a word with any of the judges of Israel, whom I commanded to be shepherd of my people, saying, ‘Why have you not built me a house of cedar?’”’ ^6

**7** “Now therefore, you shall tell my servant David, ‘The LORD of Armies says, “I took you from the sheep pen, from following the sheep, to be prince over my people Israel. ^7

**8** I have been with you wherever you have gone, and have cut off all your enemies from before you. I will make you a name like the name of the great ones who are on the earth. ^8

**9** I will appoint a place for my people Israel, and will plant them, that they may dwell in their own place, and be moved no more. The children of wickedness will not waste them any more, as at the first, ^9

**10** and from the day that I commanded judges to be over my people Israel. I will subdue all your enemies. Moreover I tell you that the LORD will build you a house. ^10

**11** It will happen, when your days are fulfilled that you must go to be with your fathers, that I will set up your offspring after you, who will be of your sons; and I will establish his kingdom. ^11

**12** He will build me a house, and I will establish his throne forever. ^12

**13** I will be his father, and he will be my son. I will not take my loving kindness away from him, as I took it from him who was before you; ^13

**14** but I will settle him in my house and in my kingdom forever. His throne will be established forever.”’” ^14

**15** According to all these words, and according to all this vision, so Nathan spoke to David. ^15

**16** Then David the king went in and sat before the LORD; and he said, “Who am I, LORD God, and what is my house, that you have brought me this far? ^16

**17** This was a small thing in your eyes, O God, but you have spoken of your servant’s house for a great while to come, and have respected me according to the standard of a man of high degree, LORD God. ^17

**18** What can David say yet more to you concerning the honor which is done to your servant? For you know your servant. ^18

**19** LORD, for your servant’s sake, and according to your own heart, you have done all this greatness, to make known all these great things. ^19

**20** LORD, there is no one like you, neither is there any God besides you, according to all that we have heard with our ears. ^20

**21** What one nation on the earth is like your people Israel, whom God went to redeem to himself for a people, to make you a name by great and awesome things, in driving out nations from before your people whom you redeemed out of Egypt? ^21

**22** For you made your people Israel your own people forever; and you, LORD, became their God. ^22

**23** Now, LORD, let the word that you have spoken concerning your servant, and concerning his house, be established forever, and do as you have spoken. ^23

**24** Let your name be established and magnified forever, saying, ‘The LORD of Armies is the God of Israel, even a God to Israel. The house of David your servant is established before you.’ ^24

**25** For you, my God, have revealed to your servant that you will build him a house. Therefore your servant has found courage to pray before you. ^25

**26** Now, LORD, you are God, and have promised this good thing to your servant. ^26

**27** Now it has pleased you to bless the house of your servant, that it may continue forever before you; for you, LORD, have blessed, and it is blessed forever.” ^27

← [[1 Chronicles 16 - WEBU]] | [[1 Chronicles 18 - WEBU]] →
