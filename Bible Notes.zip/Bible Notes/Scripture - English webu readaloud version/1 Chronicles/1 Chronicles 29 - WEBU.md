---
book: 1 Chronicles
chapter: 29
version: WEBU
---
# 1 Chronicles 29 (WEBU)

← [[1 Chronicles 28 - WEBU]]

**1** David the king said to all the assembly, “Solomon my son, whom alone God has chosen, is yet young and tender, and the work is great; for the palace is not for man, but for the LORD God. ^1

**2** Now I have prepared with all my might for the house of my God the gold for the things of gold, the silver for the things of silver, the bronze for the things of bronze, iron for the things of iron, and wood for the things of wood, also onyx stones, stones to be set, stones for inlaid work of various colors, all kinds of precious stones, and marble stones in abundance. ^2

**3** In addition, because I have set my affection on the house of my God, since I have a treasure of my own of gold and silver, I give it to the house of my God, over and above all that I have prepared for the holy house: ^3

**4** even three thousand talents of gold, of the gold of Ophir, and seven thousand talents of refined silver, with which to overlay the walls of the houses; ^4

**5** of gold for the things of gold, and of silver for the things of silver, and for all kinds of work to be made by the hands of artisans. Who then offers willingly to consecrate himself today to the LORD?” ^5

**6** Then the princes of the fathers’ households, and the princes of the tribes of Israel, and the captains of thousands and of hundreds, with the rulers over the king’s work, offered willingly; ^6

**7** and they gave for the service of God’s house of gold five thousand talents and ten thousand darics, of silver ten thousand talents, of bronze eighteen thousand talents, and of iron one hundred thousand talents. ^7

**8** People with whom precious stones were found gave them to the treasure of the LORD’s house, under the hand of Jehiel the Gershonite. ^8

**9** Then the people rejoiced, because they offered willingly, because with a perfect heart they offered willingly to the LORD; and David the king also rejoiced with great joy. ^9

**10** Therefore David blessed the LORD before all the assembly; and David said, “You are blessed, LORD, the God of Israel our father, forever and ever. ^10

**11** Yours, LORD, is the greatness, the power, the glory, the victory, and the majesty! For all that is in the heavens and on the earth is yours. Yours is the kingdom, LORD, and you are exalted as head above all. ^11

**12** Both riches and honor come from you, and you rule over all! In your hand is power and might! It is in your hand to make great, and to give strength to all! ^12

**13** Now therefore, our God, we thank you and praise your glorious name. ^13

**14** But who am I, and what is my people, that we should be able to offer so willingly as this? For all things come from you, and we have given you of your own. ^14

**15** For we are strangers before you and foreigners, as all our fathers were. Our days on the earth are as a shadow, and there is no remaining. ^15

**16** LORD our God, all this store that we have prepared to build you a house for your holy name comes from your hand, and is all your own. ^16

**17** I know also, my God, that you try the heart and have pleasure in uprightness. As for me, in the uprightness of my heart I have willingly offered all these things. Now I have seen with joy your people, who are present here, offer willingly to you. ^17

**18** LORD, the God of Abraham, of Isaac, and of Israel, our fathers, keep this desire forever in the thoughts of the heart of your people, and prepare their heart for you; ^18

**19** and give to Solomon my son a perfect heart, to keep your commandments, your testimonies, and your statutes, and to do all these things, and to build the palace, for which I have made provision.” ^19

**20** Then David said to all the assembly, “Now bless the LORD your God!” All the assembly blessed the LORD, the God of their fathers, and bowed down their heads and prostrated themselves before the LORD and the king. ^20

**21** They sacrificed sacrifices to the LORD and offered burnt offerings to the LORD on the next day after that day, even one thousand bulls, one thousand rams, and one thousand lambs, with their drink offerings and sacrifices in abundance for all Israel, ^21

**22** and ate and drank before the LORD on that day with great gladness. They made Solomon the son of David king the second time, and anointed him before the LORD to be prince, and Zadok to be priest. ^22

**23** Then Solomon sat on the throne of the LORD as king instead of David his father, and prospered; and all Israel obeyed him. ^23

**24** All the princes, the mighty men, and also all of the sons of King David submitted themselves to Solomon the king. ^24

**25** The LORD magnified Solomon exceedingly in the sight of all Israel, and gave to him such royal majesty as had not been on any king before him in Israel. ^25

**26** Now David the son of Jesse reigned over all Israel. ^26

**27** The time that he reigned over Israel was forty years; he reigned seven years in Hebron, and he reigned thirty-three years in Jerusalem. ^27

**28** He died at a good old age, full of days, riches, and honor; and Solomon his son reigned in his place. ^28

**29** Now the acts of David the king, first and last, behold, they are written in the history of Samuel the seer, and in the history of Nathan the prophet, and in the history of Gad the seer, ^29

**30** with all his reign and his might, and the events that involved him, Israel, and all the kingdoms of the lands. ^30

← [[1 Chronicles 28 - WEBU]]
