---
book: 1 Chronicles
chapter: 26
version: WEBU
---
# 1 Chronicles 26 (WEBU)

← [[1 Chronicles 25 - WEBU]] | [[1 Chronicles 27 - WEBU]] →

**1** For the divisions of the doorkeepers: of the Korahites, Meshelemiah the son of Kore, of the sons of Asaph. ^1

**2** Meshelemiah had sons: Zechariah the firstborn, Jediael the second, Zebadiah the third, Jathniel the fourth, ^2

**3** Elam the fifth, Jehohanan the sixth, and Eliehoenai the seventh. ^3

**4** Obed-Edom had sons: Shemaiah the firstborn, Jehozabad the second, Joah the third, Sacar the fourth, Nethanel the fifth, ^4

**5** Ammiel the sixth, Issachar the seventh, and Peullethai the eighth; for God blessed him. ^5

**6** Sons were also born to Shemaiah his son, who ruled over the house of their father; for they were mighty men of valor. ^6

**7** The sons of Shemaiah: Othni, Rephael, Obed, and Elzabad, whose relatives were valiant men, Elihu, and Semachiah. ^7

**8** All these were of the sons of Obed-Edom with their sons and their brothers, able men in strength for the service: sixty-two of Obed-Edom. ^8

**9** Meshelemiah had sons and brothers, eighteen valiant men. ^9

**10** Also Hosah, of the children of Merari, had sons: Shimri the chief (for though he was not the firstborn, yet his father made him chief), ^10

**11** Hilkiah the second, Tebaliah the third, and Zechariah the fourth. All the sons and brothers of Hosah were thirteen. ^11

**12** Of these were the divisions of the doorkeepers, even of the chief men, having offices like their brothers, to minister in the LORD’s house. ^12

**13** They cast lots, the small as well as the great, according to their fathers’ houses, for every gate. ^13

**14** The lot eastward fell to Shelemiah. Then for Zechariah his son, a wise counselor, they cast lots; and his lot came out northward. ^14

**15** To Obed-Edom southward; and to his sons the storehouse. ^15

**16** To Shuppim and Hosah westward, by the gate of Shallecheth, at the causeway that goes up, watchman opposite watchman. ^16

**17** Eastward were six Levites, northward four a day, southward four a day, and for the storehouse two and two. ^17

**18** For Parbar westward, four at the causeway, and two at Parbar. ^18

**19** These were the divisions of the doorkeepers; of the sons of the Korahites, and of the sons of Merari. ^19

**20** Of the Levites, Ahijah was over the treasures of God’s house and over the treasures of the dedicated things. ^20

**21** The sons of Ladan, the sons of the Gershonites belonging to Ladan, the heads of the fathers’ households belonging to Ladan the Gershonite: Jehieli. ^21

**22** The sons of Jehieli: Zetham, and Joel his brother, over the treasures of the LORD’s house. ^22

**23** Of the Amramites, of the Izharites, of the Hebronites, of the Uzzielites: ^23

**24** Shebuel the son of Gershom, the son of Moses, was ruler over the treasuries. ^24

**25** His brothers: of Eliezer, Rehabiah his son, and Jeshaiah his son, and Joram his son, and Zichri his son, and Shelomoth his son. ^25

**26** This Shelomoth and his brothers were over all the treasuries of the dedicated things, which David the king, and the heads of the fathers’ households, the captains over thousands and hundreds, and the captains of the army, had dedicated. ^26

**27** They dedicated some of the plunder won in battles to repair the LORD’s house. ^27

**28** All that Samuel the seer, Saul the son of Kish, Abner the son of Ner, and Joab the son of Zeruiah had dedicated, whoever had dedicated anything, it was under the hand of Shelomoth and of his brothers. ^28

**29** Of the Izharites, Chenaniah and his sons were appointed to the outward business over Israel, for officers and judges. ^29

**30** Of the Hebronites, Hashabiah and his brothers, one thousand seven hundred men of valor, had the oversight of Israel beyond the Jordan westward, for all the business of the LORD and for the service of the king. ^30

**31** Of the Hebronites, Jerijah was the chief of the Hebronites, according to their generations by fathers’ households. They were sought for in the fortieth year of the reign of David, and mighty men of valor were found among them at Jazer of Gilead. ^31

**32** His relatives, men of valor, were two thousand seven hundred, heads of fathers’ households, whom King David made overseers over the Reubenites, the Gadites, and the half-tribe of the Manassites, for every matter pertaining to God and for the affairs of the king. ^32

← [[1 Chronicles 25 - WEBU]] | [[1 Chronicles 27 - WEBU]] →
