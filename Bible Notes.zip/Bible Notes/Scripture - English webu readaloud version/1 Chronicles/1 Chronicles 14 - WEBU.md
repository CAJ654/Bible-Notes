---
book: 1 Chronicles
chapter: 14
version: WEBU
---
# 1 Chronicles 14 (WEBU)

← [[1 Chronicles 13 - WEBU]] | [[1 Chronicles 15 - WEBU]] →

**1** Hiram king of Tyre sent messengers to David with cedar trees, masons, and carpenters, to build him a house. ^1

**2** David perceived that the LORD had established him king over Israel, for his kingdom was highly exalted, for his people Israel’s sake. ^2

**3** David took more wives in Jerusalem, and David became the father of more sons and daughters. ^3

**4** These are the names of the children whom he had in Jerusalem: Shammua, Shobab, Nathan, Solomon, ^4

**5** Ibhar, Elishua, Elpelet, ^5

**6** Nogah, Nepheg, Japhia, ^6

**7** Elishama, Beeliada, and Eliphelet. ^7

**8** When the Philistines heard that David was anointed king over all Israel, all the Philistines went up to seek David; and David heard of it, and went out against them. ^8

**9** Now the Philistines had come and made a raid in the valley of Rephaim. ^9

**10** David inquired of God, saying, “Shall I go up against the Philistines? Will you deliver them into my hand?” The LORD said to him, “Go up; for I will deliver them into your hand.” ^10

**11** So they came up to Baal Perazim, and David defeated them there. David said, God has broken my enemies by my hand, like waters breaking out. Therefore they called the name of that place Baal Perazim. ^11

**12** They left their gods there; and David gave a command, and they were burned with fire. ^12

**13** The Philistines made another raid in the valley. ^13

**14** David inquired again of God; and God said to him, “You shall not go up after them. Turn away from them, and come on them opposite the mulberry trees. ^14

**15** When you hear the sound of marching in the tops of the mulberry trees, then go out to battle; for God has gone out before you to strike the army of the Philistines.” ^15

**16** David did as God commanded him; and they attacked the army of the Philistines from Gibeon even to Gezer. ^16

**17** The fame of David went out into all lands; and the LORD brought the fear of him on all nations. ^17

← [[1 Chronicles 13 - WEBU]] | [[1 Chronicles 15 - WEBU]] →
