---
book: 1 Chronicles
chapter: 4
version: WEBU
---
# 1 Chronicles 4 (WEBU)

← [[1 Chronicles 3 - WEBU]] | [[1 Chronicles 5 - WEBU]] →

**1** The sons of Judah: Perez, Hezron, Carmi, Hur, and Shobal. ^1

**2** Reaiah the son of Shobal became the father of Jahath; and Jahath became the father of Ahumai and Lahad. These are the families of the Zorathites. ^2

**3** These were the sons of the father of Etam: Jezreel, Ishma, and Idbash. The name of their sister was Hazzelelponi. ^3

**4** Penuel was the father of Gedor and Ezer the father of Hushah. These are the sons of Hur, the firstborn of Ephrathah, the father of Bethlehem. ^4

**5** Ashhur the father of Tekoa had two wives, Helah and Naarah. ^5

**6** Naarah bore him Ahuzzam, Hepher, Temeni, and Haahashtari. These were the sons of Naarah. ^6

**7** The sons of Helah were Zereth, Izhar, and Ethnan. ^7

**8** Hakkoz became the father of Anub, Zobebah, and the families of Aharhel the son of Harum. ^8

**9** Jabez was more honorable than his brothers. His mother named him Jabez, saying, “Because I bore him with sorrow.” ^9

**10** Jabez called on the God of Israel, saying, “Oh that you would bless me indeed, and enlarge my border! May your hand be with me, and may you keep me from evil, that I may not cause pain!” God granted him that which he requested. ^10

**11** Chelub the brother of Shuhah became the father of Mehir, who was the father of Eshton. ^11

**12** Eshton became the father of Beth Rapha, Paseah, and Tehinnah the father of Ir Nahash. These are the men of Recah. ^12

**13** The sons of Kenaz: Othniel and Seraiah. The sons of Othniel: Hathath. ^13

**14** Meonothai became the father of Ophrah: and Seraiah became the father of Joab the father of Ge Harashim, for they were craftsmen. ^14

**15** The sons of Caleb the son of Jephunneh: Iru, Elah, and Naam. The son of Elah: Kenaz. ^15

**16** The sons of Jehallelel: Ziph, Ziphah, Tiria, and Asarel. ^16

**17** The sons of Ezrah: Jether, Mered, Epher, and Jalon; and Mered’s wife bore Miriam, Shammai, and Ishbah the father of Eshtemoa. ^17

**18** His wife the Jewess bore Jered the father of Gedor, Heber the father of Soco, and Jekuthiel the father of Zanoah. These are the sons of Bithiah the daughter of Pharaoh, whom Mered took. ^18

**19** The sons of the wife of Hodiah, the sister of Naham, were the fathers of Keilah the Garmite and Eshtemoa the Maacathite. ^19

**20** The sons of Shimon: Amnon, Rinnah, Ben Hanan, and Tilon. The sons of Ishi: Zoheth, and Ben Zoheth. ^20

**21** The sons of Shelah the son of Judah: Er the father of Lecah, Laadah the father of Mareshah, and the families of the house of those who worked fine linen, of the house of Ashbea; ^21

**22** and Jokim, and the men of Cozeba, and Joash, and Saraph, who had dominion in Moab, and Jashubilehem. These records are ancient. ^22

**23** These were the potters, and the inhabitants of Netaim and Gederah; they lived there with the king for his work. ^23

**24** The sons of Simeon: Nemuel, Jamin, Jarib, Zerah, Shaul; ^24

**25** Shallum his son, Mibsam his son, and Mishma his son. ^25

**26** The sons of Mishma: Hammuel his son, Zaccur his son, Shimei his son. ^26

**27** Shimei had sixteen sons and six daughters; but his brothers didn’t have many children, and all their family didn’t multiply like the children of Judah. ^27

**28** They lived at Beersheba, Moladah, Hazarshual, ^28

**29** at Bilhah, at Ezem, at Tolad, ^29

**30** at Bethuel, at Hormah, at Ziklag, ^30

**31** at Beth Marcaboth, Hazar Susim, at Beth Biri, and at Shaaraim. These were their cities until David’s reign. ^31

**32** Their villages were Etam, Ain, Rimmon, Tochen, and Ashan, five cities; ^32

**33** and all their villages that were around the same cities, as far as Baal. These were their settlements, and they kept their genealogy. ^33

**34** Meshobab, Jamlech, Joshah the son of Amaziah, ^34

**35** Joel, Jehu the son of Joshibiah, the son of Seraiah, the son of Asiel, ^35

**36** Elioenai, Jaakobah, Jeshohaiah, Asaiah, Adiel, Jesimiel, Benaiah, ^36

**37** and Ziza the son of Shiphi, the son of Allon, the son of Jedaiah, the son of Shimri, the son of Shemaiah— ^37

**38** these mentioned by name were princes in their families. Their fathers’ houses increased greatly. ^38

**39** They went to the entrance of Gedor, even to the east side of the valley, to seek pasture for their flocks. ^39

**40** They found rich, good pasture, and the land was wide, and quiet, and peaceful, for those who lived there before were descended from Ham. ^40

**41** These written by name came in the days of Hezekiah king of Judah, and struck their tents and the Meunim who were found there; and they destroyed them utterly to this day, and lived in their place, because there was pasture there for their flocks. ^41

**42** Some of them, even of the sons of Simeon, five hundred men, went to Mount Seir, having for their captains Pelatiah, Neariah, Rephaiah, and Uzziel, the sons of Ishi. ^42

**43** They struck the remnant of the Amalekites who escaped, and have lived there to this day. ^43

← [[1 Chronicles 3 - WEBU]] | [[1 Chronicles 5 - WEBU]] →
