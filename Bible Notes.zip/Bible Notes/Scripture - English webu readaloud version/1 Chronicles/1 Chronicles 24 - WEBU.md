---
book: 1 Chronicles
chapter: 24
version: WEBU
---
# 1 Chronicles 24 (WEBU)

← [[1 Chronicles 23 - WEBU]] | [[1 Chronicles 25 - WEBU]] →

**1** These were the divisions of the sons of Aaron. The sons of Aaron: Nadab, Abihu, Eleazar, and Ithamar. ^1

**2** But Nadab and Abihu died before their father, and had no children; therefore Eleazar and Ithamar served as priests. ^2

**3** David, with Zadok of the sons of Eleazar and Ahimelech of the sons of Ithamar, divided them according to their ordering in their service. ^3

**4** There were more chief men found of the sons of Eleazar than of the sons of Ithamar; and they were divided like this: of the sons of Eleazar there were sixteen, heads of fathers’ houses; and of the sons of Ithamar, according to their fathers’ houses, eight. ^4

**5** Thus they were divided impartially by drawing lots; for there were princes of the sanctuary and princes of God, both of the sons of Eleazar, and of the sons of Ithamar. ^5

**6** Shemaiah the son of Nethanel the scribe, who was of the Levites, wrote them in the presence of the king, the princes, Zadok the priest, Ahimelech the son of Abiathar, and the heads of the fathers’ households of the priests and of the Levites; one fathers’ house being taken for Eleazar, and one taken for Ithamar. ^6

**7** Now the first lot came out to Jehoiarib, the second to Jedaiah, ^7

**8** the third to Harim, the fourth to Seorim, ^8

**9** the fifth to Malchijah, the sixth to Mijamin, ^9

**10** the seventh to Hakkoz, the eighth to Abijah, ^10

**11** the ninth to Jeshua, the tenth to Shecaniah, ^11

**12** the eleventh to Eliashib, the twelfth to Jakim, ^12

**13** the thirteenth to Huppah, the fourteenth to Jeshebeab, ^13

**14** the fifteenth to Bilgah, the sixteenth to Immer, ^14

**15** the seventeenth to Hezir, the eighteenth to Happizzez, ^15

**16** the nineteenth to Pethahiah, the twentieth to Jehezkel, ^16

**17** the twenty-first to Jachin, the twenty-second to Gamul, ^17

**18** the twenty-third to Delaiah, and the twenty-fourth to Maaziah. ^18

**19** This was their ordering in their service, to come into the LORD’s house according to the ordinance given to them by Aaron their father, as the LORD, the God of Israel, had commanded him. ^19

**20** Of the rest of the sons of Levi: of the sons of Amram, Shubael; of the sons of Shubael, Jehdeiah. ^20

**21** Of Rehabiah: of the sons of Rehabiah, Isshiah the chief. ^21

**22** Of the Izharites, Shelomoth; of the sons of Shelomoth, Jahath. ^22

**23** The sons of Hebron: Jeriah, Amariah the second, Jahaziel the third, and Jekameam the fourth. ^23

**24** The sons of Uzziel: Micah; of the sons of Micah, Shamir. ^24

**25** The brother of Micah: Isshiah; of the sons of Isshiah, Zechariah. ^25

**26** The sons of Merari: Mahli and Mushi. The son of Jaaziah: Beno. ^26

**27** The sons of Merari by Jaaziah: Beno, Shoham, Zaccur, and Ibri. ^27

**28** Of Mahli: Eleazar, who had no sons. ^28

**29** Of Kish, the son of Kish: Jerahmeel. ^29

**30** The sons of Mushi: Mahli, Eder, and Jerimoth. These were the sons of the Levites after their fathers’ houses. ^30

**31** These likewise cast lots even as their brothers the sons of Aaron in the presence of David the king, Zadok, Ahimelech, and the heads of the fathers’ households of the priests and of the Levites, the fathers’ households of the chief even as those of his younger brother. ^31

← [[1 Chronicles 23 - WEBU]] | [[1 Chronicles 25 - WEBU]] →
