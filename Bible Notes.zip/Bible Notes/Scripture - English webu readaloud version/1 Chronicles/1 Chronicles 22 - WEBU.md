---
book: 1 Chronicles
chapter: 22
version: WEBU
---
# 1 Chronicles 22 (WEBU)

← [[1 Chronicles 21 - WEBU]] | [[1 Chronicles 23 - WEBU]] →

**1** Then David said, “This is the house of the LORD God, and this is the altar of burnt offering for Israel.” ^1

**2** David gave orders to gather together the foreigners who were in the land of Israel; and he set masons to cut dressed stones to build God’s house. ^2

**3** David prepared iron in abundance for the nails for the doors of the gates and for the couplings, and bronze in abundance without weight, ^3

**4** and cedar trees without number, for the Sidonians and the people of Tyre brought cedar trees in abundance to David. ^4

**5** David said, “Solomon my son is young and tender, and the house that is to be built for the LORD must be exceedingly magnificent, of fame and of glory throughout all countries. I will therefore make preparation for it.” So David prepared abundantly before his death. ^5

**6** Then he called for Solomon his son, and commanded him to build a house for the LORD, the God of Israel. ^6

**7** David said to Solomon his son, “As for me, it was in my heart to build a house to the name of the LORD my God. ^7

**8** But the LORD’s word came to me, saying, ‘You have shed blood abundantly and have made great wars. You shall not build a house to my name, because you have shed much blood on the earth in my sight. ^8

**9** Behold, a son shall be born to you, who shall be a man of peace. I will give him rest from all his enemies all around; for his name shall be Solomon, and I will give peace and quietness to Israel in his days. ^9

**10** He shall build a house for my name; and he will be my son, and I will be his father; and I will establish the throne of his kingdom over Israel forever.’ ^10

**11** Now, my son, may the LORD be with you and prosper you, and build the house of the LORD your God, as he has spoken concerning you. ^11

**12** May the LORD give you discretion and understanding, and put you in charge of Israel, so that you may keep the law of the LORD your God. ^12

**13** Then you will prosper, if you observe to do the statutes and the ordinances which the LORD gave Moses concerning Israel. Be strong and courageous. Don’t be afraid and don’t be dismayed. ^13

**14** Now, behold, in my affliction I have prepared for the LORD’s house one hundred thousand talents of gold, one million talents of silver, and bronze and iron without weight; for it is in abundance. I have also prepared timber and stone; and you may add to them. ^14

**15** There are also workmen with you in abundance—cutters and workers of stone and timber, and all kinds of men who are skillful in every kind of work; ^15

**16** of the gold, the silver, the bronze, and the iron, there is no number. Arise and be doing, and may the LORD be with you.” ^16

**17** David also commanded all the princes of Israel to help Solomon his son, saying, ^17

**18** “Isn’t the LORD your God with you? Hasn’t he given you rest on every side? For he has delivered the inhabitants of the land into my hand; and the land is subdued before the LORD and before his people. ^18

**19** Now set your heart and your soul to follow the LORD your God. Arise therefore, and build the sanctuary of the LORD God, to bring the ark of the LORD’s covenant and the holy vessels of God into the house that is to be built for the LORD’s name.” ^19

← [[1 Chronicles 21 - WEBU]] | [[1 Chronicles 23 - WEBU]] →
