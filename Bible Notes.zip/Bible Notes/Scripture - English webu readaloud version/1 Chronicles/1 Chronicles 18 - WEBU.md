---
book: 1 Chronicles
chapter: 18
version: WEBU
---
# 1 Chronicles 18 (WEBU)

← [[1 Chronicles 17 - WEBU]] | [[1 Chronicles 19 - WEBU]] →

**1** After this, David defeated the Philistines and subdued them, and took Gath and its towns out of the hand of the Philistines. ^1

**2** He defeated Moab; and the Moabites became servants to David and brought tribute. ^2

**3** David defeated Hadadezer king of Zobah, toward Hamath, as he went to establish his dominion by the river Euphrates. ^3

**4** David took from him one thousand chariots, seven thousand horsemen, and twenty thousand footmen; and David hamstrung all the chariot horses, but reserved of them enough for one hundred chariots. ^4

**5** When the Syrians of Damascus came to help Hadadezer king of Zobah, David struck twenty-two thousand men of the Syrians. ^5

**6** Then David put garrisons in Syria of Damascus; and the Syrians became servants to David and brought tribute. The LORD gave victory to David wherever he went. ^6

**7** David took the shields of gold that were on the servants of Hadadezer, and brought them to Jerusalem. ^7

**8** From Tibhath and from Cun, cities of Hadadezer, David took very much bronze, with which Solomon made the bronze sea, the pillars, and the vessels of bronze. ^8

**9** When Tou king of Hamath heard that David had struck all the army of Hadadezer king of Zobah, ^9

**10** he sent Hadoram his son to King David to greet him and to bless him, because he had fought against Hadadezer and struck him (for Hadadezer had wars with Tou); and he had with him all kinds of vessels of gold and silver and bronze. ^10

**11** King David also dedicated these to the LORD, with the silver and the gold that he carried away from all the nations: from Edom, from Moab, from the children of Ammon, from the Philistines, and from Amalek. ^11

**12** Moreover Abishai the son of Zeruiah struck eighteen thousand of the Edomites in the Valley of Salt. ^12

**13** He put garrisons in Edom; and all the Edomites became servants to David. The LORD gave victory to David wherever he went. ^13

**14** David reigned over all Israel; and he executed justice and righteousness for all his people. ^14

**15** Joab the son of Zeruiah was over the army; Jehoshaphat the son of Ahilud was recorder; ^15

**16** Zadok the son of Ahitub and Abimelech the son of Abiathar were priests; Shavsha was scribe; ^16

**17** and Benaiah the son of Jehoiada was over the Cherethites and the Pelethites; and the sons of David were chief officials serving the king. ^17

← [[1 Chronicles 17 - WEBU]] | [[1 Chronicles 19 - WEBU]] →
