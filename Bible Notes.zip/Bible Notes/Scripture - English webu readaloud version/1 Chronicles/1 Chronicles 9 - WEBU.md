---
book: 1 Chronicles
chapter: 9
version: WEBU
---
# 1 Chronicles 9 (WEBU)

← [[1 Chronicles 8 - WEBU]] | [[1 Chronicles 10 - WEBU]] →

**1** So all Israel were listed by genealogies; and behold, they are written in the book of the kings of Israel. Judah was carried away captive to Babylon for their disobedience. ^1

**2** Now the first inhabitants who lived in their possessions in their cities were Israel, the priests, the Levites, and the temple servants. ^2

**3** In Jerusalem, there lived of the children of Judah, of the children of Benjamin, and of the children of Ephraim and Manasseh: ^3

**4** Uthai the son of Ammihud, the son of Omri, the son of Imri, the son of Bani, of the children of Perez the son of Judah. ^4

**5** Of the Shilonites: Asaiah the firstborn and his sons. ^5

**6** Of the sons of Zerah: Jeuel and their brothers, six hundred ninety. ^6

**7** Of the sons of Benjamin: Sallu the son of Meshullam, the son of Hodaviah, the son of Hassenuah; ^7

**8** and Ibneiah the son of Jeroham, and Elah the son of Uzzi, the son of Michri; and Meshullam the son of Shephatiah, the son of Reuel, the son of Ibnijah; ^8

**9** and their brothers, according to their generations, nine hundred fifty-six. All these men were heads of fathers’ households by their fathers’ houses. ^9

**10** Of the priests: Jedaiah, Jehoiarib, Jachin, ^10

**11** and Azariah the son of Hilkiah, the son of Meshullam, the son of Zadok, the son of Meraioth, the son of Ahitub, the ruler of God’s house; ^11

**12** and Adaiah the son of Jeroham, the son of Pashhur, the son of Malchijah; and Maasai the son of Adiel, the son of Jahzerah, the son of Meshullam, the son of Meshillemith, the son of Immer; ^12

**13** and their brothers, heads of their fathers’ houses, one thousand seven hundred sixty; they were very able men for the work of the service of God’s house. ^13

**14** Of the Levites: Shemaiah the son of Hasshub, the son of Azrikam, the son of Hashabiah, of the sons of Merari; ^14

**15** and Bakbakkar, Heresh, Galal, and Mattaniah the son of Mica, the son of Zichri, the son of Asaph, ^15

**16** and Obadiah the son of Shemaiah, the son of Galal, the son of Jeduthun; and Berechiah the son of Asa, the son of Elkanah, who lived in the villages of the Netophathites. ^16

**17** The gatekeepers: Shallum, Akkub, Talmon, Ahiman, and their brothers (Shallum was the chief), ^17

**18** who previously served in the king’s gate eastward. They were the gatekeepers for the camp of the children of Levi. ^18

**19** Shallum was the son of Kore, the son of Ebiasaph, the son of Korah, and his brothers, of his father’s house, the Korahites, were over the work of the service, keepers of the thresholds of the tent. Their fathers had been over the LORD’s camp, keepers of the entry. ^19

**20** Phinehas the son of Eleazar was ruler over them in time past, and the LORD was with him. ^20

**21** Zechariah the son of Meshelemiah was gatekeeper of the door of the Tent of Meeting. ^21

**22** All these who were chosen to be gatekeepers in the thresholds were two hundred twelve. These were listed by genealogy in their villages, whom David and Samuel the seer ordained in their office of trust. ^22

**23** So they and their children had the oversight of the gates of the LORD’s house, even the house of the tent, as guards. ^23

**24** On the four sides were the gatekeepers, toward the east, west, north, and south. ^24

**25** Their brothers, in their villages, were to come in every seven days from time to time to be with them, ^25

**26** for the four chief gatekeepers, who were Levites, were in an office of trust, and were over the rooms and over the treasuries in God’s house. ^26

**27** They stayed around God’s house, because that was their duty; and it was their duty to open it morning by morning. ^27

**28** Certain of them were in charge of the vessels of service, for these were brought in by count, and these were taken out by count. ^28

**29** Some of them also were appointed over the furniture, and over all the vessels of the sanctuary, over the fine flour, the wine, the oil, the frankincense, and the spices. ^29

**30** Some of the sons of the priests prepared the mixing of the spices. ^30

**31** Mattithiah, one of the Levites, who was the firstborn of Shallum the Korahite, had the office of trust over the things that were baked in pans. ^31

**32** Some of their brothers, of the sons of the Kohathites, were over the show bread, to prepare it every Sabbath. ^32

**33** These are the singers, heads of fathers’ households of the Levites, who lived in the rooms and were free from other service, for they were employed in their work day and night. ^33

**34** These were heads of fathers’ households of the Levites, throughout their generations, chief men. They lived at Jerusalem. ^34

**35** Jeiel the father of Gibeon, whose wife’s name was Maacah, lived in Gibeon. ^35

**36** His firstborn son was Abdon, then Zur, Kish, Baal, Ner, Nadab, ^36

**37** Gedor, Ahio, Zechariah, and Mikloth. ^37

**38** Mikloth became the father of Shimeam. They also lived with their relatives in Jerusalem, near their relatives. ^38

**39** Ner became the father of Kish. Kish became the father of Saul. Saul became the father of Jonathan, Malchishua, Abinadab, and Eshbaal. ^39

**40** The son of Jonathan was Merib-baal. Merib-baal became the father of Micah. ^40

**41** The sons of Micah: Pithon, Melech, Tahrea, and Ahaz. ^41

**42** Ahaz became the father of Jarah. Jarah became the father of Alemeth, Azmaveth, and Zimri. Zimri became the father of Moza. ^42

**43** Moza became the father of Binea, Rephaiah his son, Eleasah his son, and Azel his son. ^43

**44** Azel had six sons, whose names are Azrikam, Bocheru, Ishmael, Sheariah, Obadiah, and Hanan. These were the sons of Azel. ^44

← [[1 Chronicles 8 - WEBU]] | [[1 Chronicles 10 - WEBU]] →
