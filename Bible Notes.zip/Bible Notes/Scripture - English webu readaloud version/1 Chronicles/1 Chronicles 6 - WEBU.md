---
book: 1 Chronicles
chapter: 6
version: WEBU
---
# 1 Chronicles 6 (WEBU)

← [[1 Chronicles 5 - WEBU]] | [[1 Chronicles 7 - WEBU]] →

**1** The sons of Levi: Gershon, Kohath, and Merari. ^1

**2** The sons of Kohath: Amram, Izhar, Hebron, and Uzziel. ^2

**3** The children of Amram: Aaron, Moses, and Miriam. The sons of Aaron: Nadab, Abihu, Eleazar, and Ithamar. ^3

**4** Eleazar became the father of Phinehas, Phinehas became the father of Abishua, ^4

**5** Abishua became the father of Bukki. Bukki became the father of Uzzi. ^5

**6** Uzzi became the father of Zerahiah. Zerahiah became the father of Meraioth. ^6

**7** Meraioth became the father of Amariah. Amariah became the father of Ahitub. ^7

**8** Ahitub became the father of Zadok. Zadok became the father of Ahimaaz. ^8

**9** Ahimaaz became the father of Azariah. Azariah became the father of Johanan. ^9

**10** Johanan became the father of Azariah, who executed the priest’s office in the house that Solomon built in Jerusalem. ^10

**11** Azariah became the father of Amariah. Amariah became the father of Ahitub. ^11

**12** Ahitub became the father of Zadok. Zadok became the father of Shallum. ^12

**13** Shallum became the father of Hilkiah. Hilkiah became the father of Azariah. ^13

**14** Azariah became the father of Seraiah. Seraiah became the father of Jehozadak. ^14

**15** Jehozadak went into captivity when the LORD carried Judah and Jerusalem away by the hand of Nebuchadnezzar. ^15

**16** The sons of Levi: Gershom, Kohath, and Merari. ^16

**17** These are the names of the sons of Gershom: Libni and Shimei. ^17

**18** The sons of Kohath were Amram, Izhar, Hebron, and Uzziel. ^18

**19** The sons of Merari: Mahli and Mushi. These are the families of the Levites according to their fathers’ households. ^19

**20** Of Gershom: Libni his son, Jahath his son, Zimmah his son, ^20

**21** Joah his son, Iddo his son, Zerah his son, and Jeatherai his son. ^21

**22** The sons of Kohath: Amminadab his son, Korah his son, Assir his son, ^22

**23** Elkanah his son, Ebiasaph his son, Assir his son, ^23

**24** Tahath his son, Uriel his son, Uzziah his son, and Shaul his son. ^24

**25** The sons of Elkanah: Amasai and Ahimoth. ^25

**26** As for Elkanah, the sons of Elkanah: Zophai his son, Nahath his son, ^26

**27** Eliab his son, Jeroham his son, and Elkanah his son. ^27

**28** The sons of Samuel: the firstborn, Joel, and the second, Abijah. ^28

**29** The sons of Merari: Mahli, Libni his son, Shimei his son, Uzzah his son, ^29

**30** Shimea his son, Haggiah his son, Asaiah his son. ^30

**31** These are they whom David set over the service of song in the LORD’s house after the ark came to rest there. ^31

**32** They ministered with song before the tabernacle of the Tent of Meeting until Solomon had built the LORD’s house in Jerusalem. They performed the duties of their office according to their order. ^32

**33** These are those who served, and their sons. Of the sons of the Kohathites: Heman the singer, the son of Joel, the son of Samuel, ^33

**34** the son of Elkanah, the son of Jeroham, the son of Eliel, the son of Toah, ^34

**35** the son of Zuph, the son of Elkanah, the son of Mahath, the son of Amasai, ^35

**36** the son of Elkanah, the son of Joel, the son of Azariah, the son of Zephaniah, ^36

**37** the son of Tahath, the son of Assir, the son of Ebiasaph, the son of Korah, ^37

**38** the son of Izhar, the son of Kohath, the son of Levi, the son of Israel. ^38

**39** His brother Asaph, who stood on his right hand, even Asaph the son of Berechiah, the son of Shimea, ^39

**40** the son of Michael, the son of Baaseiah, the son of Malchijah, ^40

**41** the son of Ethni, the son of Zerah, the son of Adaiah, ^41

**42** the son of Ethan, the son of Zimmah, the son of Shimei, ^42

**43** the son of Jahath, the son of Gershom, the son of Levi. ^43

**44** On the left hand their brothers the sons of Merari: Ethan the son of Kishi, the son of Abdi, the son of Malluch, ^44

**45** the son of Hashabiah, the son of Amaziah, the son of Hilkiah, ^45

**46** the son of Amzi, the son of Bani, the son of Shemer, ^46

**47** the son of Mahli, the son of Mushi, the son of Merari, the son of Levi. ^47

**48** Their brothers the Levites were appointed for all the service of the tabernacle of God’s house. ^48

**49** But Aaron and his sons offered on the altar of burnt offering, and on the altar of incense, for all the work of the most holy place, and to make atonement for Israel, according to all that Moses the servant of God had commanded. ^49

**50** These are the sons of Aaron: Eleazar his son, Phinehas his son, Abishua his son, ^50

**51** Bukki his son, Uzzi his son, Zerahiah his son, ^51

**52** Meraioth his son, Amariah his son, Ahitub his son, ^52

**53** Zadok his son, and Ahimaaz his son. ^53

**54** Now these are their dwelling places according to their encampments in their borders: to the sons of Aaron, of the families of the Kohathites (for theirs was the first lot), ^54

**55** to them they gave Hebron in the land of Judah, and its pasture lands around it; ^55

**56** but the fields of the city and its villages, they gave to Caleb the son of Jephunneh. ^56

**57** To the sons of Aaron they gave the cities of refuge, Hebron, Libnah also with its pasture lands, Jattir, Eshtemoa with its pasture lands, ^57

**58** Hilen with its pasture lands, Debir with its pasture lands, ^58

**59** Ashan with its pasture lands, and Beth Shemesh with its pasture lands; ^59

**60** and out of the tribe of Benjamin, Geba with its pasture lands, Allemeth with its pasture lands, and Anathoth with its pasture lands. All their cities throughout their families were thirteen cities. ^60

**61** To the rest of the sons of Kohath were given by lot, out of the family of the tribe, out of the half-tribe, the half of Manasseh, ten cities. ^61

**62** To the sons of Gershom, according to their families, out of the tribe of Issachar, and out of the tribe of Asher, and out of the tribe of Naphtali, and out of the tribe of Manasseh in Bashan, thirteen cities. ^62

**63** To the sons of Merari were given by lot, according to their families, out of the tribe of Reuben, and out of the tribe of Gad, and out of the tribe of Zebulun, twelve cities. ^63

**64** The children of Israel gave to the Levites the cities with their pasture lands. ^64

**65** They gave by lot out of the tribe of the children of Judah, and out of the tribe of the children of Simeon, and out of the tribe of the children of Benjamin, these cities which are mentioned by name. ^65

**66** Some of the families of the sons of Kohath had cities of their borders out of the tribe of Ephraim. ^66

**67** They gave to them the cities of refuge, Shechem in the hill country of Ephraim with its pasture lands and Gezer with its pasture lands, ^67

**68** Jokmeam with its pasture lands, Beth Horon with its pasture lands, ^68

**69** Aijalon with its pasture lands, Gath Rimmon with its pasture lands; ^69

**70** and out of the half-tribe of Manasseh, Aner with its pasture lands, and Bileam with its pasture lands, for the rest of the family of the sons of Kohath. ^70

**71** To the sons of Gershom were given, out of the family of the half-tribe of Manasseh, Golan in Bashan with its pasture lands, and Ashtaroth with its pasture lands; ^71

**72** and out of the tribe of Issachar, Kedesh with its pasture lands, Daberath with its pasture lands, ^72

**73** Ramoth with its pasture lands, and Anem with its pasture lands; ^73

**74** and out of the tribe of Asher, Mashal with its pasture lands, Abdon with its pasture lands, ^74

**75** Hukok with its pasture lands, and Rehob with its pasture lands; ^75

**76** and out of the tribe of Naphtali, Kedesh in Galilee with its pasture lands, Hammon with its pasture lands, and Kiriathaim with its pasture lands. ^76

**77** To the rest of the Levites, the sons of Merari, were given, out of the tribe of Zebulun, Rimmono with its pasture lands, and Tabor with its pasture lands; ^77

**78** and beyond the Jordan at Jericho, on the east side of the Jordan, were given them out of the tribe of Reuben: Bezer in the wilderness with its pasture lands, Jahzah with its pasture lands, ^78

**79** Kedemoth with its pasture lands, and Mephaath with its pasture lands; ^79

**80** and out of the tribe of Gad, Ramoth in Gilead with its pasture lands, Mahanaim with its pasture lands, ^80

**81** Heshbon with its pasture lands, and Jazer with its pasture lands. ^81

← [[1 Chronicles 5 - WEBU]] | [[1 Chronicles 7 - WEBU]] →
