---
book: 1 Chronicles
chapter: 2
version: WEBU
---
# 1 Chronicles 2 (WEBU)

← [[1 Chronicles 1 - WEBU]] | [[1 Chronicles 3 - WEBU]] →

**1** These are the sons of Israel: Reuben, Simeon, Levi, Judah, Issachar, Zebulun, ^1

**2** Dan, Joseph, Benjamin, Naphtali, Gad, and Asher. ^2

**3** The sons of Judah: Er, Onan, and Shelah, which three were born to him of Shua’s daughter the Canaanitess. Er, Judah’s firstborn, was wicked in the LORD’s sight; and he killed him. ^3

**4** Tamar his daughter-in-law bore him Perez and Zerah. All the sons of Judah were five. ^4

**5** The sons of Perez: Hezron and Hamul. ^5

**6** The sons of Zerah: Zimri, Ethan, Heman, Calcol, and Dara—five of them in all. ^6

**7** The son of Carmi: Achar, the troubler of Israel, who committed a trespass in the devoted thing. ^7

**8** The son of Ethan: Azariah. ^8

**9** The sons also of Hezron, who were born to him: Jerahmeel, Ram, and Chelubai. ^9

**10** Ram became the father of Amminadab, and Amminadab became the father of Nahshon, prince of the children of Judah; ^10

**11** and Nahshon became the father of Salma, and Salma became the father of Boaz, ^11

**12** and Boaz became the father of Obed, and Obed became the father of Jesse; ^12

**13** and Jesse became the father of his firstborn Eliab, Abinadab the second, Shimea the third, ^13

**14** Nethanel the fourth, Raddai the fifth, ^14

**15** Ozem the sixth, and David the seventh; ^15

**16** and their sisters were Zeruiah and Abigail. The sons of Zeruiah: Abishai, Joab, and Asahel, three. ^16

**17** Abigail bore Amasa; and the father of Amasa was Jether the Ishmaelite. ^17

**18** Caleb the son of Hezron became the father of children by Azubah his wife, and by Jerioth; and these were her sons: Jesher, Shobab, and Ardon. ^18

**19** Azubah died, and Caleb married Ephrath, who bore him Hur. ^19

**20** Hur became the father of Uri, and Uri became the father of Bezalel. ^20

**21** Afterward Hezron went in to the daughter of Machir the father of Gilead, whom he took as wife when he was sixty years old; and she bore him Segub. ^21

**22** Segub became the father of Jair, who had twenty-three cities in the land of Gilead. ^22

**23** Geshur and Aram took the towns of Jair from them, with Kenath, and its villages, even sixty cities. All these were the sons of Machir the father of Gilead. ^23

**24** After Hezron died in Caleb Ephrathah, Abijah, Hezron’s wife, bore him Ashhur the father of Tekoa. ^24

**25** The sons of Jerahmeel the firstborn of Hezron were Ram the firstborn, Bunah, Oren, Ozem, and Ahijah. ^25

**26** Jerahmeel had another wife, whose name was Atarah. She was the mother of Onam. ^26

**27** The sons of Ram the firstborn of Jerahmeel were Maaz, Jamin, and Eker. ^27

**28** The sons of Onam were Shammai and Jada. The sons of Shammai: Nadab and Abishur. ^28

**29** The name of the wife of Abishur was Abihail; and she bore him Ahban and Molid. ^29

**30** The sons of Nadab: Seled and Appaim; but Seled died without children. ^30

**31** The son of Appaim: Ishi. The son of Ishi: Sheshan. The son of Sheshan: Ahlai. ^31

**32** The sons of Jada the brother of Shammai: Jether and Jonathan; and Jether died without children. ^32

**33** The sons of Jonathan: Peleth and Zaza. These were the sons of Jerahmeel. ^33

**34** Now Sheshan had no sons, but only daughters. Sheshan had a servant, an Egyptian, whose name was Jarha. ^34

**35** Sheshan gave his daughter to Jarha his servant as wife; and she bore him Attai. ^35

**36** Attai became the father of Nathan, and Nathan became the father of Zabad, ^36

**37** and Zabad became the father of Ephlal, and Ephlal became the father of Obed, ^37

**38** and Obed became the father of Jehu, and Jehu became the father of Azariah, ^38

**39** and Azariah became the father of Helez, and Helez became the father of Eleasah, ^39

**40** and Eleasah became the father of Sismai, and Sismai became the father of Shallum, ^40

**41** and Shallum became the father of Jekamiah, and Jekamiah became the father of Elishama. ^41

**42** The sons of Caleb the brother of Jerahmeel were Mesha his firstborn, who was the father of Ziph, and the sons of Mareshah the father of Hebron. ^42

**43** The sons of Hebron: Korah, Tappuah, Rekem, and Shema. ^43

**44** Shema became the father of Raham, the father of Jorkeam; and Rekem became the father of Shammai. ^44

**45** The son of Shammai was Maon; and Maon was the father of Beth Zur. ^45

**46** Ephah, Caleb’s concubine, bore Haran, Moza, and Gazez; and Haran became the father of Gazez. ^46

**47** The sons of Jahdai: Regem, Jothan, Geshan, Pelet, Ephah, and Shaaph. ^47

**48** Maacah, Caleb’s concubine, bore Sheber and Tirhanah. ^48

**49** She bore also Shaaph the father of Madmannah, Sheva the father of Machbena and the father of Gibea; and the daughter of Caleb was Achsah. ^49

**50** These were the sons of Caleb, the son of Hur, the firstborn of Ephrathah: Shobal the father of Kiriath Jearim, ^50

**51** Salma the father of Bethlehem, and Hareph the father of Beth Gader. ^51

**52** Shobal the father of Kiriath Jearim had sons: Haroeh, half of the Menuhoth. ^52

**53** The families of Kiriath Jearim: the Ithrites, the Puthites, the Shumathites, and the Mishraites; from them came the Zorathites and the Eshtaolites. ^53

**54** The sons of Salma: Bethlehem, the Netophathites, Atroth Beth Joab, and half of the Manahathites, the Zorites. ^54

**55** The families of scribes who lived at Jabez: the Tirathites, the Shimeathites, and the Sucathites. These are the Kenites who came from Hammath, the father of the house of Rechab. ^55

← [[1 Chronicles 1 - WEBU]] | [[1 Chronicles 3 - WEBU]] →
