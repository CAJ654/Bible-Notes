---
book: 1 Chronicles
chapter: 15
version: WEBU
---
# 1 Chronicles 15 (WEBU)

← [[1 Chronicles 14 - WEBU]] | [[1 Chronicles 16 - WEBU]] →

**1** David made himself houses in David’s city; and he prepared a place for God’s ark, and pitched a tent for it. ^1

**2** Then David said, “No one ought to carry God’s ark but the Levites. For the LORD has chosen them to carry God’s ark, and to minister to him forever.” ^2

**3** David assembled all Israel at Jerusalem, to bring up the LORD’s ark to its place, which he had prepared for it. ^3

**4** David gathered together the sons of Aaron and the Levites: ^4

**5** of the sons of Kohath, Uriel the chief, and his brothers one hundred twenty; ^5

**6** of the sons of Merari, Asaiah the chief, and his brothers two hundred twenty; ^6

**7** of the sons of Gershom, Joel the chief, and his brothers one hundred thirty; ^7

**8** of the sons of Elizaphan, Shemaiah the chief, and his brothers two hundred; ^8

**9** of the sons of Hebron, Eliel the chief, and his brothers eighty; ^9

**10** of the sons of Uzziel, Amminadab the chief, and his brothers one hundred twelve. ^10

**11** David called for Zadok and Abiathar the priests, and for the Levites: for Uriel, Asaiah, Joel, Shemaiah, Eliel, and Amminadab, ^11

**12** and said to them, “You are the heads of the fathers’ households of the Levites. Sanctify yourselves, both you and your brothers, that you may bring the ark of the LORD, the God of Israel, up to the place that I have prepared for it. ^12

**13** For because you didn’t carry it at first, the LORD our God broke out in anger against us, because we didn’t seek him according to the ordinance.” ^13

**14** So the priests and the Levites sanctified themselves to bring up the ark of the LORD, the God of Israel. ^14

**15** The children of the Levites bore God’s ark on their shoulders with its poles, as Moses commanded according to the LORD’s word. ^15

**16** David spoke to the chief of the Levites to appoint their brothers as singers with instruments of music, stringed instruments, harps, and cymbals, sounding aloud and lifting up their voices with joy. ^16

**17** So the Levites appointed Heman the son of Joel; and of his brothers, Asaph the son of Berechiah; and of the sons of Merari their brothers, Ethan the son of Kushaiah; ^17

**18** and with them their brothers of the second rank: Zechariah, Ben, Jaaziel, Shemiramoth, Jehiel, Unni, Eliab, Benaiah, Maaseiah, Mattithiah, Eliphelehu, Mikneiah, Obed-Edom, and Jeiel, the doorkeepers. ^18

**19** So the singers, Heman, Asaph, and Ethan, were given cymbals of bronze to sound aloud; ^19

**20** and Zechariah, Aziel, Shemiramoth, Jehiel, Unni, Eliab, Maaseiah, and Benaiah, with stringed instruments set to Alamoth; ^20

**21** and Mattithiah, Eliphelehu, Mikneiah, Obed-Edom, Jeiel, and Azaziah, with harps tuned to the eight-stringed lyre, to lead. ^21

**22** Chenaniah, chief of the Levites, was over the singing. He taught the singers, because he was skillful. ^22

**23** Berechiah and Elkanah were doorkeepers for the ark. ^23

**24** Shebaniah, Joshaphat, Nethanel, Amasai, Zechariah, Benaiah, and Eliezer, the priests, blew the trumpets before God’s ark; and Obed-Edom and Jehiah were doorkeepers for the ark. ^24

**25** So David, the elders of Israel, and the captains over thousands went to bring the ark of the LORD’s covenant up out of the house of Obed-Edom with joy. ^25

**26** When God helped the Levites who bore the ark of the LORD’s covenant, they sacrificed seven bulls and seven rams. ^26

**27** David was clothed with a robe of fine linen, as were all the Levites who bore the ark, the singers, and Chenaniah the choir master with the singers; and David had an ephod of linen on him. ^27

**28** Thus all Israel brought the ark of the LORD’s covenant up with shouting, with sound of the cornet, with trumpets, and with cymbals, sounding aloud with stringed instruments and harps. ^28

**29** As the ark of the LORD’s covenant came to David’s city, Michal the daughter of Saul looked out at the window, and saw king David dancing and playing; and she despised him in her heart. ^29

← [[1 Chronicles 14 - WEBU]] | [[1 Chronicles 16 - WEBU]] →
