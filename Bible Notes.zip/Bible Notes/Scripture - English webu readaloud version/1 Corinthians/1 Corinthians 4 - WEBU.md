---
book: 1 Corinthians
chapter: 4
version: WEBU
---
# 1 Corinthians 4 (WEBU)

← [[1 Corinthians 3 - WEBU]] | [[1 Corinthians 5 - WEBU]] →

**1** So let a man think of us as Christ’s servants and stewards of God’s mysteries. ^1

**2** Here, moreover, it is required of stewards that they be found faithful. ^2

**3** But with me it is a very small thing that I should be judged by you, or by a human court. Yes, I don’t even judge my own self. ^3

**4** For I know nothing against myself. Yet I am not justified by this, but he who judges me is the Lord. ^4

**5** Therefore judge nothing before the time, until the Lord comes, who will both bring to light the hidden things of darkness and reveal the counsels of the hearts. Then each man will get his praise from God. ^5

**6** Now these things, brothers, I have in a figure transferred to myself and Apollos for your sakes, that in us you might learn not to think beyond the things which are written, that none of you be puffed up against one another. ^6

**7** For who makes you different? And what do you have that you didn’t receive? But if you did receive it, why do you boast as if you had not received it? ^7

**8** You are already filled. You have already become rich. You have come to reign without us. Yes, and I wish that you did reign, that we also might reign with you! ^8

**9** For I think that God has displayed us, the apostles, last of all, like men sentenced to death. For we are made a spectacle to the world, both to angels and men. ^9

**10** We are fools for Christ’s sake, but you are wise in Christ. We are weak, but you are strong. You have honor, but we have dishonor. ^10

**11** Even to this present hour we hunger, thirst, are naked, are beaten, and have no certain dwelling place. ^11

**12** We toil, working with our own hands. When people curse us, we bless. Being persecuted, we endure. ^12

**13** Being defamed, we entreat. We are made as the filth of the world, the dirt wiped off by all, even until now. ^13

**14** I don’t write these things to shame you, but to admonish you as my beloved children. ^14

**15** For though you have ten thousand tutors in Christ, you don’t have many fathers. For in Christ Jesus, I became your father through the Good News. ^15

**16** I beg you therefore, be imitators of me. ^16

**17** Because of this I have sent Timothy to you, who is my beloved and faithful child in the Lord, who will remind you of my ways which are in Christ, even as I teach everywhere in every assembly. ^17

**18** Now some are puffed up, as though I were not coming to you. ^18

**19** But I will come to you shortly, if the Lord is willing. And I will know, not the word of those who are puffed up, but the power. ^19

**20** For God’s Kingdom is not in word, but in power. ^20

**21** What do you want? Shall I come to you with a rod, or in love and a spirit of gentleness? ^21

← [[1 Corinthians 3 - WEBU]] | [[1 Corinthians 5 - WEBU]] →
