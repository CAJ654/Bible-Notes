---
book: 1 Corinthians
chapter: 9
version: WEBU
---
# 1 Corinthians 9 (WEBU)

← [[1 Corinthians 8 - WEBU]] | [[1 Corinthians 10 - WEBU]] →

**1** Am I not free? Am I not an apostle? Haven’t I seen Jesus Christ, our Lord? Aren’t you my work in the Lord? ^1

**2** If to others I am not an apostle, yet at least I am to you; for you are the seal of my apostleship in the Lord. ^2

**3** My defense to those who examine me is this: ^3

**4** Have we no right to eat and to drink? ^4

**5** Have we no right to take along a wife who is a believer, even as the rest of the apostles, and the brothers of the Lord, and Cephas? ^5

**6** Or have only Barnabas and I no right to not work? ^6

**7** What soldier ever serves at his own expense? Who plants a vineyard, and doesn’t eat of its fruit? Or who feeds a flock, and doesn’t drink from the flock’s milk? ^7

**8** Do I speak these things according to the ways of men? Or doesn’t the law also say the same thing? ^8

**9** For it is written in the law of Moses, “You shall not muzzle an ox while it treads out the grain.” Is it for the oxen that God cares, ^9

**10** or does he say it assuredly for our sake? Yes, it was written for our sake, because he who plows ought to plow in hope, and he who threshes in hope should partake of his hope. ^10

**11** If we sowed to you spiritual things, is it a great thing if we reap your fleshly things? ^11

**12** If others partake of this right over you, don’t we yet more? Nevertheless we didn’t use this right, but we bear all things, that we may cause no hindrance to the Good News of Christ. ^12

**13** Don’t you know that those who serve around sacred things eat from the things of the temple, and those who wait on the altar have their portion with the altar? ^13

**14** Even so the Lord ordained that those who proclaim the Good News should live from the Good News. ^14

**15** But I have used none of these things, and I don’t write these things that it may be done so in my case; for I would rather die, than that anyone should make my boasting void. ^15

**16** For if I preach the Good News, I have nothing to boast about, for necessity is laid on me; but woe is to me if I don’t preach the Good News. ^16

**17** For if I do this of my own will, I have a reward. But if not of my own will, I have a stewardship entrusted to me. ^17

**18** What then is my reward? That when I preach the Good News, I may present the Good News of Christ without charge, so as not to abuse my authority in the Good News. ^18

**19** For though I was free from all, I brought myself under bondage to all, that I might gain the more. ^19

**20** To the Jews I became as a Jew, that I might gain Jews; to those who are under the law, as under the law, that I might gain those who are under the law; ^20

**21** to those who are without law, as without law (not being without law toward God, but under law toward Christ), that I might win those who are without law. ^21

**22** To the weak I became as weak, that I might gain the weak. I have become all things to all men, that I may by all means save some. ^22

**23** Now I do this for the sake of the Good News, that I may be a joint partaker of it. ^23

**24** Don’t you know that those who run in a race all run, but one receives the prize? Run like that, so that you may win. ^24

**25** Every man who strives in the games exercises self-control in all things. Now they do it to receive a corruptible crown, but we an incorruptible. ^25

**26** I therefore run like that, not aimlessly. I fight like that, not beating the air, ^26

**27** but I beat my body and bring it into submission, lest by any means, after I have preached to others, I myself should be disqualified. ^27

← [[1 Corinthians 8 - WEBU]] | [[1 Corinthians 10 - WEBU]] →
