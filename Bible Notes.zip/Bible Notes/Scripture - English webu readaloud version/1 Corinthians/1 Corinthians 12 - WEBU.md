---
book: 1 Corinthians
chapter: 12
version: WEBU
---
# 1 Corinthians 12 (WEBU)

← [[1 Corinthians 11 - WEBU]] | [[1 Corinthians 13 - WEBU]] →

**1** Now concerning spiritual things, brothers, I don’t want you to be ignorant. ^1

**2** You know that when you were heathen, you were led away to those mute idols, however you might be led. ^2

**3** Therefore I make known to you that no man speaking by God’s Spirit says, “Jesus is accursed.” No one can say, “Jesus is Lord,” but by the Holy Spirit. ^3

**4** Now there are various kinds of gifts, but the same Spirit. ^4

**5** There are various kinds of service, and the same Lord. ^5

**6** There are various kinds of workings, but the same God who works all things in all. ^6

**7** But to each one is given the manifestation of the Spirit for the profit of all. ^7

**8** For to one is given through the Spirit the word of wisdom, and to another the word of knowledge according to the same Spirit, ^8

**9** to another faith by the same Spirit, and to another gifts of healings by the same Spirit, ^9

**10** and to another workings of miracles, and to another prophecy, and to another discerning of spirits, to another different kinds of languages, and to another the interpretation of languages. ^10

**11** But the one and the same Spirit produces all of these, distributing to each one separately as he desires. ^11

**12** For as the body is one and has many members, and all the members of the body, being many, are one body; so also is Christ. ^12

**13** For in one Spirit we were all baptized into one body, whether Jews or Greeks, whether bond or free; and were all given to drink into one Spirit. ^13

**14** For the body is not one member, but many. ^14

**15** If the foot would say, “Because I’m not the hand, I’m not part of the body,” it is not therefore not part of the body. ^15

**16** If the ear would say, “Because I’m not the eye, I’m not part of the body,” it’s not therefore not part of the body. ^16

**17** If the whole body were an eye, where would the hearing be? If the whole were hearing, where would the smelling be? ^17

**18** But now God has set the members, each one of them, in the body, just as he desired. ^18

**19** If they were all one member, where would the body be? ^19

**20** But now they are many members, but one body. ^20

**21** The eye can’t tell the hand, “I have no need for you,” or again the head to the feet, “I have no need for you.” ^21

**22** No, much rather, those members of the body which seem to be weaker are necessary. ^22

**23** Those parts of the body which we think to be less honorable, on those we bestow more abundant honor; and our unpresentable parts have more abundant modesty, ^23

**24** while our presentable parts have no such need. But God composed the body together, giving more abundant honor to the inferior part, ^24

**25** that there should be no division in the body, but that the members should have the same care for one another. ^25

**26** When one member suffers, all the members suffer with it. When one member is honored, all the members rejoice with it. ^26

**27** Now you are the body of Christ, and members individually. ^27

**28** God has set some in the assembly: first apostles, second prophets, third teachers, then miracle workers, then gifts of healings, helps, governments, and various kinds of languages. ^28

**29** Are all apostles? Are all prophets? Are all teachers? Are all miracle workers? ^29

**30** Do all have gifts of healings? Do all speak with various languages? Do all interpret? ^30

**31** But earnestly desire the best gifts. Moreover, I show a most excellent way to you. ^31

← [[1 Corinthians 11 - WEBU]] | [[1 Corinthians 13 - WEBU]] →
