---
book: 1 Corinthians
chapter: 6
version: WEBU
---
# 1 Corinthians 6 (WEBU)

← [[1 Corinthians 5 - WEBU]] | [[1 Corinthians 7 - WEBU]] →

**1** Dare any of you, having a matter against his neighbor, go to law before the unrighteous, and not before the saints? ^1

**2** Don’t you know that the saints will judge the world? And if the world is judged by you, are you unworthy to judge the smallest matters? ^2

**3** Don’t you know that we will judge angels? How much more, things that pertain to this life? ^3

**4** If then you have to judge things pertaining to this life, do you set them to judge who are of no account in the assembly? ^4

**5** I say this to move you to shame. Isn’t there even one wise man among you who would be able to decide between his brothers? ^5

**6** But brother goes to law with brother, and that before unbelievers! ^6

**7** Therefore it is already altogether a defect in you that you have lawsuits one with another. Why not rather be wronged? Why not rather be defrauded? ^7

**8** No, but you yourselves do wrong and defraud, and that against your brothers. ^8

**9** Or don’t you know that the unrighteous will not inherit God’s Kingdom? Don’t be deceived. Neither the sexually immoral, nor idolaters, nor adulterers, nor male prostitutes, nor homosexuals, ^9

**10** nor thieves, nor covetous, nor drunkards, nor slanderers, nor extortionists, will inherit God’s Kingdom. ^10

**11** Some of you were such, but you were washed. You were sanctified. You were justified in the name of the Lord Jesus, and in the Spirit of our God. ^11

**12** “All things are lawful for me,” but not all things are expedient. “All things are lawful for me,” but I will not be brought under the power of anything. ^12

**13** “Foods for the belly, and the belly for foods,” but God will bring to nothing both it and them. But the body is not for sexual immorality, but for the Lord, and the Lord for the body. ^13

**14** Now God raised up the Lord, and will also raise us up by his power. ^14

**15** Don’t you know that your bodies are members of Christ? Shall I then take the members of Christ and make them members of a prostitute? May it never be! ^15

**16** Or don’t you know that he who is joined to a prostitute is one body? For, “The two”, he says, “will become one flesh.” ^16

**17** But he who is joined to the Lord is one spirit. ^17

**18** Flee sexual immorality! “Every sin that a man does is outside the body,” but he who commits sexual immorality sins against his own body. ^18

**19** Or don’t you know that your body is a temple of the Holy Spirit who is in you, whom you have from God? You are not your own, ^19

**20** for you were bought with a price. Therefore glorify God in your body and in your spirit, which are God’s. ^20

← [[1 Corinthians 5 - WEBU]] | [[1 Corinthians 7 - WEBU]] →
