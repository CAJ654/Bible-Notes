---
book: 1 Corinthians
chapter: 1
version: WEBU
---
# 1 Corinthians 1 (WEBU)

[[1 Corinthians 2 - WEBU]] →

**1** Paul, called to be an apostle of Jesus Christ through the will of God, and our brother Sosthenes, ^1

**2** to the assembly of God which is at Corinth—those who are sanctified in Christ Jesus, called saints, with all who call on the name of our Lord Jesus Christ in every place, both theirs and ours: ^2

**3** Grace to you and peace from God our Father and the Lord Jesus Christ. ^3

**4** I always thank my God concerning you for the grace of God which was given you in Christ Jesus, ^4

**5** that in everything you were enriched in him, in all speech and all knowledge— ^5

**6** even as the testimony of Christ was confirmed in you— ^6

**7** so that you come behind in no gift, waiting for the revelation of our Lord Jesus Christ, ^7

**8** who will also confirm you until the end, blameless in the day of our Lord Jesus Christ. ^8

**9** God is faithful, through whom you were called into the fellowship of his Son, Jesus Christ our Lord. ^9

**10** Now I beg you, brothers, through the name of our Lord, Jesus Christ, that you all speak the same thing, and that there be no divisions among you, but that you be perfected together in the same mind and in the same judgment. ^10

**11** For it has been reported to me concerning you, my brothers, by those who are from Chloe’s household, that there are contentions among you. ^11

**12** Now I mean this, that each one of you says, “I follow Paul,” “I follow Apollos,” “I follow Cephas,” and, “I follow Christ.” ^12

**13** Is Christ divided? Was Paul crucified for you? Or were you baptized into the name of Paul? ^13

**14** I thank God that I baptized none of you except Crispus and Gaius, ^14

**15** so that no one should say that I had baptized you into my own name. ^15

**16** (I also baptized the household of Stephanas; besides them, I don’t know whether I baptized any other.) ^16

**17** For Christ sent me not to baptize, but to preach the Good News—not in wisdom of words, so that the cross of Christ wouldn’t be made void. ^17

**18** For the word of the cross is foolishness to those who are dying, but to us who are being saved it is the power of God. ^18

**19** For it is written, “I will destroy the wisdom of the wise. I will bring the discernment of the discerning to nothing.” ^19

**20** Where is the wise? Where is the scribe? Where is the debater of this age? Hasn’t God made foolish the wisdom of this world? ^20

**21** For seeing that in the wisdom of God, the world through its wisdom didn’t know God, it was God’s good pleasure through the foolishness of the preaching to save those who believe. ^21

**22** For Jews ask for signs, Greeks seek after wisdom, ^22

**23** but we preach Christ crucified, a stumbling block to Jews and foolishness to Greeks, ^23

**24** but to those who are called, both Jews and Greeks, Christ is the power of God and the wisdom of God; ^24

**25** because the foolishness of God is wiser than men, and the weakness of God is stronger than men. ^25

**26** For you see your calling, brothers, that not many are wise according to the flesh, not many mighty, and not many noble; ^26

**27** but God chose the foolish things of the world that he might put to shame those who are wise. God chose the weak things of the world that he might put to shame the things that are strong. ^27

**28** God chose the lowly things of the world, and the things that are despised, and the things that don’t exist, that he might bring to nothing the things that exist, ^28

**29** that no flesh should boast before God. ^29

**30** Because of him, you are in Christ Jesus, who was made to us wisdom from God, and righteousness and sanctification, and redemption, ^30

**31** that, as it is written, “He who boasts, let him boast in the Lord.” ^31

[[1 Corinthians 2 - WEBU]] →
