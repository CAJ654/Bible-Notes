---
book: 1 Corinthians
chapter: 8
version: WEBU
---
# 1 Corinthians 8 (WEBU)

← [[1 Corinthians 7 - WEBU]] | [[1 Corinthians 9 - WEBU]] →

**1** Now concerning things sacrificed to idols: We know that we all have knowledge. Knowledge puffs up, but love builds up. ^1

**2** But if anyone thinks that he knows anything, he doesn’t yet know as he ought to know. ^2

**3** But anyone who loves God is known by him. ^3

**4** Therefore concerning the eating of things sacrificed to idols, we know that no idol is anything in the world, and that there is no other God but one. ^4

**5** For though there are things that are called “gods”, whether in the heavens or on earth—as there are many “gods” and many “lords”— ^5

**6** yet to us there is one God, the Father, of whom are all things, and we for him; and one Lord, Jesus Christ, through whom are all things, and we live through him. ^6

**7** However, that knowledge isn’t in all men. But some, with consciousness of an idol until now, eat as of a thing sacrificed to an idol, and their conscience, being weak, is defiled. ^7

**8** But food will not commend us to God. For neither, if we don’t eat are we the worse, nor if we eat are we the better. ^8

**9** But be careful that by no means does this liberty of yours become a stumbling block to the weak. ^9

**10** For if a man sees you who have knowledge sitting in an idol’s temple, won’t his conscience, if he is weak, be emboldened to eat things sacrificed to idols? ^10

**11** And through your knowledge, he who is weak perishes, the brother for whose sake Christ died. ^11

**12** Thus, sinning against the brothers, and wounding their conscience when it is weak, you sin against Christ. ^12

**13** Therefore, if food causes my brother to stumble, I will eat no meat forever more, that I don’t cause my brother to stumble. ^13

← [[1 Corinthians 7 - WEBU]] | [[1 Corinthians 9 - WEBU]] →
