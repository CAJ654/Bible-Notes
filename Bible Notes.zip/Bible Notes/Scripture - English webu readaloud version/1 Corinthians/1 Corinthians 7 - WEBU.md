---
book: 1 Corinthians
chapter: 7
version: WEBU
---
# 1 Corinthians 7 (WEBU)

← [[1 Corinthians 6 - WEBU]] | [[1 Corinthians 8 - WEBU]] →

**1** Now concerning the things about which you wrote to me: it is good for a man not to touch a woman. ^1

**2** But, because of sexual immoralities, let each man have his own wife, and let each woman have her own husband. ^2

**3** Let the husband give his wife the affection owed her, and likewise also the wife her husband. ^3

**4** The wife doesn’t have authority over her own body, but the husband does. Likewise also the husband doesn’t have authority over his own body, but the wife does. ^4

**5** Don’t deprive one another, unless it is by consent for a season, that you may give yourselves to fasting and prayer, and may be together again, that Satan doesn’t tempt you because of your lack of self-control. ^5

**6** But this I say by way of concession, not of commandment. ^6

**7** Yet I wish that all men were like me. However, each man has his own gift from God, one of this kind, and another of that kind. ^7

**8** But I say to the unmarried and to widows, it is good for them if they remain even as I am. ^8

**9** But if they don’t have self-control, let them marry. For it’s better to marry than to burn with passion. ^9

**10** But to the married I command—not I, but the Lord—that the wife not leave her husband ^10

**11** (but if she departs, let her remain unmarried, or else be reconciled to her husband), and that the husband not leave his wife. ^11

**12** But to the rest I—not the Lord—say, if any brother has an unbelieving wife, and she is content to live with him, let him not leave her. ^12

**13** The woman who has an unbelieving husband, and he is content to live with her, let her not leave her husband. ^13

**14** For the unbelieving husband is sanctified in the wife, and the unbelieving wife is sanctified in the husband. Otherwise your children would be unclean, but now they are holy. ^14

**15** Yet if the unbeliever departs, let there be separation. The brother or the sister is not under bondage in such cases, but God has called us in peace. ^15

**16** For how do you know, wife, whether you will save your husband? Or how do you know, husband, whether you will save your wife? ^16

**17** Only, as the Lord has distributed to each man, as God has called each, so let him walk. So I command in all the assemblies. ^17

**18** Was anyone called having been circumcised? Let him not become uncircumcised. Has anyone been called in uncircumcision? Let him not be circumcised. ^18

**19** Circumcision is nothing, and uncircumcision is nothing, but what matters is keeping God’s commandments. ^19

**20** Let each man stay in that calling in which he was called. ^20

**21** Were you called being a bondservant? Don’t let that bother you, but if you get an opportunity to become free, use it. ^21

**22** For he who was called in the Lord being a bondservant is the Lord’s free man. Likewise he who was called being free is Christ’s bondservant. ^22

**23** You were bought with a price. Don’t become bondservants of men. ^23

**24** Brothers, let each man, in whatever condition he was called, stay in that condition with God. ^24

**25** Now concerning virgins, I have no commandment from the Lord, but I give my judgment as one who has obtained mercy from the Lord to be trustworthy. ^25

**26** Therefore I think that because of the distress that is on us, it’s good for a man to remain as he is. ^26

**27** Are you bound to a wife? Don’t seek to be freed. Are you free from a wife? Don’t seek a wife. ^27

**28** But if you marry, you have not sinned. If a virgin marries, she has not sinned. Yet such will have oppression in the flesh, and I want to spare you. ^28

**29** But I say this, brothers: the time is short. From now on, both those who have wives may be as though they had none; ^29

**30** and those who weep, as though they didn’t weep; and those who rejoice, as though they didn’t rejoice; and those who buy, as though they didn’t possess; ^30

**31** and those who use the world, as not using it to the fullest. For the mode of this world passes away. ^31

**32** But I desire to have you to be free from cares. He who is unmarried is concerned for the things of the Lord, how he may please the Lord; ^32

**33** but he who is married is concerned about the things of the world, how he may please his wife. ^33

**34** There is also a difference between a wife and a virgin. The unmarried woman cares about the things of the Lord, that she may be holy both in body and in spirit. But she who is married cares about the things of the world—how she may please her husband. ^34

**35** This I say for your own benefit, not that I may ensnare you, but for that which is appropriate, and that you may attend to the Lord without distraction. ^35

**36** But if any man thinks that he is behaving inappropriately toward his virgin, if she is past the flower of her age, and if need so requires, let him do what he desires. He doesn’t sin. Let them marry. ^36

**37** But he who stands steadfast in his heart, having no urgency, but has power over his own will, and has determined in his own heart to keep his own virgin, does well. ^37

**38** So then both he who gives his own virgin in marriage does well, and he who doesn’t give her in marriage does better. ^38

**39** A wife is bound by law for as long as her husband lives; but if the husband is dead, she is free to be married to whomever she desires, only in the Lord. ^39

**40** But she is happier if she stays as she is, in my judgment, and I think that I also have God’s Spirit. ^40

← [[1 Corinthians 6 - WEBU]] | [[1 Corinthians 8 - WEBU]] →
