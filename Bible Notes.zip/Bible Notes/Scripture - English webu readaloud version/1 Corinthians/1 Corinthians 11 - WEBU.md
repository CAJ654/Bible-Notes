---
book: 1 Corinthians
chapter: 11
version: WEBU
---
# 1 Corinthians 11 (WEBU)

← [[1 Corinthians 10 - WEBU]] | [[1 Corinthians 12 - WEBU]] →

**1** Be imitators of me, even as I also am of Christ. ^1

**2** Now I praise you, brothers, that you remember me in all things, and hold firm the traditions, even as I delivered them to you. ^2

**3** But I would have you know that the head of every man is Christ, and the head of the woman is man, and the head of Christ is God. ^3

**4** Every man praying or prophesying, having his head covered, dishonors his head. ^4

**5** But every woman praying or prophesying with her head uncovered dishonors her head. For it is one and the same thing as if she were shaved. ^5

**6** For if a woman is not covered, let her hair also be cut off. But if it is shameful for a woman to have her hair cut off or be shaved, let her be covered. ^6

**7** For a man indeed ought not to have his head covered, because he is the image and glory of God, but the woman is the glory of the man. ^7

**8** For man is not from woman, but woman from man; ^8

**9** for man wasn’t created for the woman, but woman for the man. ^9

**10** For this cause the woman ought to have authority over her own head, because of the angels. ^10

**11** Nevertheless, neither is the woman independent of the man, nor the man independent of the woman, in the Lord. ^11

**12** For as woman came from man, so a man also comes through a woman; but all things are from God. ^12

**13** Judge for yourselves. Is it appropriate that a woman pray to God unveiled? ^13

**14** Doesn’t even nature itself teach you that if a man has long hair, it is a dishonor to him? ^14

**15** But if a woman has long hair, it is a glory to her, for her hair is given to her for a covering. ^15

**16** But if any man seems to be contentious, we have no such custom, neither do God’s assemblies. ^16

**17** But in giving you this command I don’t praise you, because you come together not for the better but for the worse. ^17

**18** For first of all, when you come together in the assembly, I hear that divisions exist among you, and I partly believe it. ^18

**19** For there also must be factions among you, that those who are approved may be revealed among you. ^19

**20** When therefore you assemble yourselves together, it is not the Lord’s supper that you eat. ^20

**21** For in your eating each one takes his own supper first. One is hungry, and another is drunken. ^21

**22** What, don’t you have houses to eat and to drink in? Or do you despise God’s assembly and put them to shame who don’t have enough? What shall I tell you? Shall I praise you? In this I don’t praise you. ^22

**23** For I received from the Lord that which also I delivered to you, that the Lord Jesus on the night in which he was betrayed took bread. ^23

**24** When he had given thanks, he broke it and said, “Take, eat. This is my body, which is broken for you. Do this in memory of me.” ^24

**25** In the same way he also took the cup after supper, saying, “This cup is the new covenant in my blood. Do this, as often as you drink, in memory of me.” ^25

**26** For as often as you eat this bread and drink this cup, you proclaim the Lord’s death until he comes. ^26

**27** Therefore whoever eats this bread or drinks the Lord’s cup in a way unworthy of the Lord will be guilty of the body and the blood of the Lord. ^27

**28** But let a man examine himself, and so let him eat of the bread and drink of the cup. ^28

**29** For he who eats and drinks in an unworthy way eats and drinks judgment to himself if he doesn’t discern the Lord’s body. ^29

**30** For this cause many among you are weak and sickly, and not a few sleep. ^30

**31** For if we discerned ourselves, we wouldn’t be judged. ^31

**32** But when we are judged, we are disciplined by the Lord, that we may not be condemned with the world. ^32

**33** Therefore, my brothers, when you come together to eat, wait for one another. ^33

**34** But if anyone is hungry, let him eat at home, lest your coming together be for judgment. The rest I will set in order whenever I come. ^34

← [[1 Corinthians 10 - WEBU]] | [[1 Corinthians 12 - WEBU]] →
