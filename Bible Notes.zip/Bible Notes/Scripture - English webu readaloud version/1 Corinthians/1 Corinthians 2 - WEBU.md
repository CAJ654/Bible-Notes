---
book: 1 Corinthians
chapter: 2
version: WEBU
---
# 1 Corinthians 2 (WEBU)

← [[1 Corinthians 1 - WEBU]] | [[1 Corinthians 3 - WEBU]] →

**1** When I came to you, brothers, I didn’t come with excellence of speech or of wisdom, proclaiming to you the testimony of God. ^1

**2** For I determined not to know anything among you except Jesus Christ and him crucified. ^2

**3** I was with you in weakness, in fear, and in much trembling. ^3

**4** My speech and my preaching were not in persuasive words of human wisdom, but in demonstration of the Spirit and of power, ^4

**5** that your faith wouldn’t stand in the wisdom of men, but in the power of God. ^5

**6** We speak wisdom, however, among those who are full grown, yet a wisdom not of this world nor of the rulers of this world who are coming to nothing. ^6

**7** But we speak God’s wisdom in a mystery, the wisdom that has been hidden, which God foreordained before the worlds for our glory, ^7

**8** which none of the rulers of this world has known. For had they known it, they wouldn’t have crucified the Lord of glory. ^8

**9** But as it is written, “Things which an eye didn’t see, and an ear didn’t hear, which didn’t enter into the heart of man, these God has prepared for those who love him.” ^9

**10** But to us, God revealed them through the Spirit. For the Spirit searches all things, yes, the deep things of God. ^10

**11** For who among men knows the things of a man except the spirit of the man which is in him? Even so, no one knows the things of God except God’s Spirit. ^11

**12** But we received not the spirit of the world, but the Spirit which is from God, that we might know the things that were freely given to us by God. ^12

**13** We also speak these things, not in words which man’s wisdom teaches but which the Holy Spirit teaches, comparing spiritual things with spiritual things. ^13

**14** Now the natural man doesn’t receive the things of God’s Spirit, for they are foolishness to him; and he can’t know them, because they are spiritually discerned. ^14

**15** But he who is spiritual discerns all things, and he himself is to be judged by no one. ^15

**16** “For who has known the mind of the Lord that he should instruct him?” But we have Christ’s mind. ^16

← [[1 Corinthians 1 - WEBU]] | [[1 Corinthians 3 - WEBU]] →
