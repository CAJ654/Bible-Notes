---
book: 1 Corinthians
chapter: 14
version: WEBU
---
# 1 Corinthians 14 (WEBU)

← [[1 Corinthians 13 - WEBU]] | [[1 Corinthians 15 - WEBU]] →

**1** Follow after love and earnestly desire spiritual gifts, but especially that you may prophesy. ^1

**2** For he who speaks in another language speaks not to men, but to God, for no one understands, but in the Spirit he speaks mysteries. ^2

**3** But he who prophesies speaks to men for their edification, exhortation, and consolation. ^3

**4** He who speaks in another language edifies himself, but he who prophesies edifies the assembly. ^4

**5** Now I desire to have you all speak with other languages, but even more that you would prophesy. For he is greater who prophesies than he who speaks with other languages, unless he interprets, that the assembly may be built up. ^5

**6** But now, brothers, if I come to you speaking with other languages, what would I profit you unless I speak to you either by way of revelation, or of knowledge, or of prophesying, or of teaching? ^6

**7** Even lifeless things that make a sound, whether pipe or harp, if they didn’t give a distinction in the sounds, how would it be known what is piped or harped? ^7

**8** For if the trumpet gave an uncertain sound, who would prepare himself for war? ^8

**9** So also you, unless you uttered by the tongue words easy to understand, how would it be known what is spoken? For you would be speaking into the air. ^9

**10** There are, it may be, so many kinds of languages in the world, and none of them is without meaning. ^10

**11** If then I don’t know the meaning of the language, I would be to him who speaks a foreigner, and he who speaks would be a foreigner to me. ^11

**12** So also you, since you are zealous for spiritual gifts, seek that you may abound to the building up of the assembly. ^12

**13** Therefore let him who speaks in another language pray that he may interpret. ^13

**14** For if I pray in another language, my spirit prays, but my understanding is unfruitful. ^14

**15** What should I do? I will pray with the spirit, and I will pray with the understanding also. I will sing with the spirit, and I will sing with the understanding also. ^15

**16** Otherwise, if you bless with the spirit, how will he who fills the place of the unlearned say the “Amen” at your giving of thanks, seeing he doesn’t know what you say? ^16

**17** For you most certainly give thanks well, but the other person is not built up. ^17

**18** I thank my God, I speak with other languages more than you all. ^18

**19** However, in the assembly I would rather speak five words with my understanding, that I might instruct others also, than ten thousand words in another language. ^19

**20** Brothers, don’t be children in thoughts, yet in malice be babies, but in thoughts be mature. ^20

**21** In the law it is written, “By men of strange languages and by the lips of strangers I will speak to this people. They won’t even listen to me that way, says the Lord.” ^21

**22** Therefore other languages are for a sign, not to those who believe, but to the unbelieving; but prophesying is for a sign, not to the unbelieving, but to those who believe. ^22

**23** If therefore the whole assembly is assembled together and all speak with other languages, and unlearned or unbelieving people come in, won’t they say that you are crazy? ^23

**24** But if all prophesy, and someone unbelieving or unlearned comes in, he is reproved by all, and he is judged by all. ^24

**25** And thus the secrets of his heart are revealed. So he will fall down on his face and worship God, declaring that God is among you indeed. ^25

**26** What is it then, brothers? When you come together, each one of you has a psalm, has a teaching, has a revelation, has another language, or has an interpretation. Let all things be done to build each other up. ^26

**27** If any man speaks in another language, let there be two, or at the most three, and in turn; and let one interpret. ^27

**28** But if there is no interpreter, let him keep silent in the assembly, and let him speak to himself and to God. ^28

**29** Let two or three of the prophets speak, and let the others discern. ^29

**30** But if a revelation is made to another sitting by, let the first keep silent. ^30

**31** For you all can prophesy one by one, that all may learn and all may be exhorted. ^31

**32** The spirits of the prophets are subject to the prophets, ^32

**33** for God is not a God of confusion but of peace, as in all the assemblies of the saints. ^33

**34** Let the wives be quiet in the assemblies, for it has not been permitted for them to be talking except in submission, as the law also says, ^34

**35** if they desire to learn anything. “Let them ask their own husbands at home, for it is shameful for a wife to be talking in the assembly.” ^35

**36** What!? Was it from you that the word of God went out? Or did it come to you alone? ^36

**37** If any man thinks himself to be a prophet or spiritual, let him recognize the things which I write to you, that they are the commandment of the Lord. ^37

**38** But if anyone is ignorant, let him be ignorant. ^38

**39** Therefore, brothers, desire earnestly to prophesy, and don’t forbid speaking with other languages. ^39

**40** Let all things be done decently and in order. ^40

← [[1 Corinthians 13 - WEBU]] | [[1 Corinthians 15 - WEBU]] →
