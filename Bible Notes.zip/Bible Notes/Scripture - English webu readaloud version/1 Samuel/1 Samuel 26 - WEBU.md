---
book: 1 Samuel
chapter: 26
version: WEBU
---
# 1 Samuel 26 (WEBU)

← [[1 Samuel 25 - WEBU]] | [[1 Samuel 27 - WEBU]] →

**1** The Ziphites came to Saul to Gibeah, saying, “Doesn’t David hide himself in the hill of Hachilah, which is before the desert?” ^1

**2** Then Saul arose and went down to the wilderness of Ziph, having three thousand chosen men of Israel with him, to seek David in the wilderness of Ziph. ^2

**3** Saul encamped in the hill of Hachilah, which is before the desert, by the way. But David stayed in the wilderness, and he saw that Saul came after him into the wilderness. ^3

**4** David therefore sent out spies, and understood that Saul had certainly come. ^4

**5** Then David arose and came to the place where Saul had encamped; and David saw the place where Saul lay, with Abner the son of Ner, the captain of his army. Saul lay within the place of the wagons, and the people were encamped around him. ^5

**6** Then David answered and said to Ahimelech the Hittite, and to Abishai the son of Zeruiah, brother of Joab, saying, “Who will go down with me to Saul to the camp?” Abishai said, “I will go down with you.” ^6

**7** So David and Abishai came to the people by night; and, behold, Saul lay sleeping within the place of the wagons, with his spear stuck in the ground at his head; and Abner and the people lay around him. ^7

**8** Then Abishai said to David, “God has delivered up your enemy into your hand today. Now therefore please let me strike him with the spear to the earth at one stroke, and I will not strike him the second time.” ^8

**9** David said to Abishai, “Don’t destroy him, for who can stretch out his hand against the LORD’s anointed, and be guiltless?” ^9

**10** David said, “As the LORD lives, the LORD will strike him; or his day shall come to die, or he shall go down into battle and perish. ^10

**11** The LORD forbid that I should stretch out my hand against the LORD’s anointed; but now please take the spear that is at his head and the jar of water, and let’s go.” ^11

**12** So David took the spear and the jar of water from Saul’s head, and they went away. No man saw it, or knew it, nor did any awake; for they were all asleep, because a deep sleep from the LORD had fallen on them. ^12

**13** Then David went over to the other side, and stood on the top of the mountain far away, a great space being between them; ^13

**14** and David cried to the people, and to Abner the son of Ner, saying, “Don’t you answer, Abner?” Then Abner answered, “Who are you who calls to the king?” ^14

**15** David said to Abner, “Aren’t you a man? Who is like you in Israel? Why then have you not kept watch over your lord the king? For one of the people came in to destroy your lord the king. ^15

**16** This thing isn’t good that you have done. As the LORD lives, you are worthy to die, because you have not kept watch over your lord, the LORD’s anointed. Now see where the king’s spear is, and the jar of water that was at his head.” ^16

**17** Saul recognized David’s voice, and said, “Is this your voice, my son David?” David said, “It is my voice, my lord, O king.” ^17

**18** He said, “Why does my lord pursue his servant? For what have I done? What evil is in my hand? ^18

**19** Now therefore, please let my lord the king hear the words of his servant. If it is so that the LORD has stirred you up against me, let him accept an offering. But if it is the children of men, they are cursed before the LORD; for they have driven me out today that I shouldn’t cling to the LORD’s inheritance, saying, ‘Go, serve other gods!’ ^19

**20** Now therefore, don’t let my blood fall to the earth away from the presence of the LORD; for the king of Israel has come out to seek a flea, as when one hunts a partridge in the mountains.” ^20

**21** Then Saul said, “I have sinned. Return, my son David; for I will no more do you harm, because my life was precious in your eyes today. Behold, I have played the fool, and have erred exceedingly.” ^21

**22** David answered, “Behold the spear, O king! Let one of the young men come over and get it. ^22

**23** The LORD will give to every man his righteousness and his faithfulness; because the LORD delivered you into my hand today, and I wouldn’t stretch out my hand against the LORD’s anointed. ^23

**24** Behold, as your life was respected today in my eyes, so let my life be respected in the LORD’s eyes, and let him deliver me out of all oppression.” ^24

**25** Then Saul said to David, “You are blessed, my son David. You will both do mightily, and will surely prevail.” So David went his way, and Saul returned to his place. ^25

← [[1 Samuel 25 - WEBU]] | [[1 Samuel 27 - WEBU]] →
