---
book: 1 Samuel
chapter: 9
version: WEBU
---
# 1 Samuel 9 (WEBU)

← [[1 Samuel 8 - WEBU]] | [[1 Samuel 10 - WEBU]] →

**1** Now there was a man of Benjamin, whose name was Kish the son of Abiel, the son of Zeror, the son of Becorath, the son of Aphiah, the son of a Benjamite, a mighty man of valor. ^1

**2** He had a son whose name was Saul, an impressive young man; and there was not among the children of Israel a more handsome person than he. From his shoulders and upward he was taller than any of the people. ^2

**3** The donkeys of Kish, Saul’s father, were lost. Kish said to Saul his son, “Now take one of the servants with you, and arise, go look for the donkeys.” ^3

**4** He passed through the hill country of Ephraim, and passed through the land of Shalishah, but they didn’t find them. Then they passed through the land of Shaalim, and they weren’t there. Then he passed through the land of the Benjamites, but they didn’t find them. ^4

**5** When they had come to the land of Zuph, Saul said to his servant who was with him, “Come! Let’s return, lest my father stop caring about the donkeys and be anxious for us.” ^5

**6** The servant said to him, “Behold now, there is a man of God in this city, and he is a man who is held in honor. All that he says surely happens. Now let’s go there. Perhaps he can tell us which way to go.” ^6

**7** Then Saul said to his servant, “But behold, if we go, what should we bring the man? For the bread is spent in our sacks, and there is not a present to bring to the man of God. What do we have?” ^7

**8** The servant answered Saul again and said, “Behold, I have in my hand the fourth part of a shekel of silver. I will give that to the man of God, to tell us our way.” ^8

**9** (In earlier times in Israel, when a man went to inquire of God, he said, “Come! Let’s go to the seer;” for he who is now called a prophet was before called a seer.) ^9

**10** Then Saul said to his servant, “Well said. Come! Let’s go.” So they went to the city where the man of God was. ^10

**11** As they went up the ascent to the city, they found young maidens going out to draw water, and said to them, “Is the seer here?” ^11

**12** They answered them and said, “He is. Behold, he is before you. Hurry now, for he has come today into the city; for the people have a sacrifice today in the high place. ^12

**13** As soon as you have come into the city, you will immediately find him before he goes up to the high place to eat; for the people will not eat until he comes, because he blesses the sacrifice. Afterwards those who are invited eat. Now therefore go up; for at this time you will find him.” ^13

**14** They went up to the city. As they came within the city, behold, Samuel came out toward them to go up to the high place. ^14

**15** Now the LORD had revealed to Samuel a day before Saul came, saying, ^15

**16** “Tomorrow about this time I will send you a man out of the land of Benjamin, and you shall anoint him to be prince over my people Israel. He will save my people out of the hand of the Philistines; for I have looked upon my people, because their cry has come to me.” ^16

**17** When Samuel saw Saul, the LORD said to him, “Behold, the man of whom I spoke to you! He will have authority over my people.” ^17

**18** Then Saul approached Samuel in the gateway, and said, “Please tell me where the seer’s house is.” ^18

**19** Samuel answered Saul and said, “I am the seer. Go up before me to the high place, for you are to eat with me today. In the morning I will let you go and will tell you all that is in your heart. ^19

**20** As for your donkeys who were lost three days ago, don’t set your mind on them, for they have been found. For whom does all Israel desire? Is it not you and all your father’s house?” ^20

**21** Saul answered, “Am I not a Benjamite, of the smallest of the tribes of Israel? And my family the least of all the families of the tribe of Benjamin? Why then do you speak to me like this?” ^21

**22** Samuel took Saul and his servant and brought them into the guest room, and made them sit in the best place among those who were invited, who were about thirty persons. ^22

**23** Samuel said to the cook, “Bring the portion which I gave you, of which I said to you, ‘Set it aside.’” ^23

**24** The cook took up the thigh, and that which was on it, and set it before Saul. Samuel said, “Behold, that which has been reserved! Set it before yourself and eat; because it has been kept for you for the appointed time, for I said, ‘I have invited the people.’” So Saul ate with Samuel that day. ^24

**25** When they had come down from the high place into the city, he talked with Saul on the housetop. ^25

**26** They arose early; and about daybreak, Samuel called to Saul on the housetop, saying, “Get up, that I may send you away.” Saul arose, and they both went outside, he and Samuel, together. ^26

**27** As they were going down at the end of the city, Samuel said to Saul, “Tell the servant to go on ahead of us.” He went ahead, then Samuel said, “But stand still first, that I may cause you to hear God’s message.” ^27

← [[1 Samuel 8 - WEBU]] | [[1 Samuel 10 - WEBU]] →
