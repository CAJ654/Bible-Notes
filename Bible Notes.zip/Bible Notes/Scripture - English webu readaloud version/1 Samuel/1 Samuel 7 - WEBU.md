---
book: 1 Samuel
chapter: 7
version: WEBU
---
# 1 Samuel 7 (WEBU)

← [[1 Samuel 6 - WEBU]] | [[1 Samuel 8 - WEBU]] →

**1** The men of Kiriath Jearim came and took the LORD’s ark, and brought it into Abinadab’s house on the hill, and consecrated Eleazar his son to keep the LORD’s ark. ^1

**2** From the day that the ark stayed in Kiriath Jearim, the time was long—for it was twenty years; and all the house of Israel lamented after the LORD. ^2

**3** Samuel spoke to all the house of Israel, saying, “If you are returning to the LORD with all your heart, then put away the foreign gods and the Ashtaroth from among you, and direct your hearts to the LORD, and serve him only; and he will deliver you out of the hand of the Philistines.” ^3

**4** Then the children of Israel removed the Baals and the Ashtaroth, and served the LORD only. ^4

**5** Samuel said, “Gather all Israel to Mizpah, and I will pray to the LORD for you.” ^5

**6** They gathered together to Mizpah, and drew water, and poured it out before the LORD, and fasted on that day, and said there, “We have sinned against the LORD.” Samuel judged the children of Israel in Mizpah. ^6

**7** When the Philistines heard that the children of Israel were gathered together at Mizpah, the lords of the Philistines went up against Israel. When the children of Israel heard it, they were afraid of the Philistines. ^7

**8** The children of Israel said to Samuel, “Don’t stop crying to the LORD our God for us, that he will save us out of the hand of the Philistines.” ^8

**9** Samuel took a suckling lamb, and offered it for a whole burnt offering to the LORD. Samuel cried to the LORD for Israel, and the LORD answered him. ^9

**10** As Samuel was offering up the burnt offering, the Philistines came near to battle against Israel; but the LORD thundered with a great thunder on that day on the Philistines and confused them; and they were struck down before Israel. ^10

**11** The men of Israel went out of Mizpah and pursued the Philistines, and struck them until they came under Beth Kar. ^11

**12** Then Samuel took a stone and set it between Mizpah and Shen, and called its name Ebenezer, saying, “The LORD helped us until now.” ^12

**13** So the Philistines were subdued, and they stopped coming within the border of Israel. The LORD’s hand was against the Philistines all the days of Samuel. ^13

**14** The cities which the Philistines had taken from Israel were restored to Israel, from Ekron even to Gath; and Israel recovered its border out of the hand of the Philistines. There was peace between Israel and the Amorites. ^14

**15** Samuel judged Israel all the days of his life. ^15

**16** He went from year to year in a circuit to Bethel, Gilgal, and Mizpah; and he judged Israel in all those places. ^16

**17** His return was to Ramah, for his house was there, and he judged Israel there; and he built an altar to the LORD there. ^17

← [[1 Samuel 6 - WEBU]] | [[1 Samuel 8 - WEBU]] →
