---
book: 1 Samuel
chapter: 28
version: WEBU
---
# 1 Samuel 28 (WEBU)

← [[1 Samuel 27 - WEBU]] | [[1 Samuel 29 - WEBU]] →

**1** In those days, the Philistines gathered their armies together for warfare, to fight with Israel. Achish said to David, “Know assuredly that you will go out with me in the army, you and your men.” ^1

**2** David said to Achish, “Therefore you will know what your servant can do.” Achish said to David, “Therefore I will make you my bodyguard forever.” ^2

**3** Now Samuel was dead, and all Israel had mourned for him and buried him in Ramah, even in his own city. Saul had sent away those who had familiar spirits and the wizards out of the land. ^3

**4** The Philistines gathered themselves together, and came and encamped in Shunem; and Saul gathered all Israel together, and they encamped in Gilboa. ^4

**5** When Saul saw the army of the Philistines, he was afraid, and his heart trembled greatly. ^5

**6** When Saul inquired of the LORD, the LORD didn’t answer him by dreams, by Urim, or by prophets. ^6

**7** Then Saul said to his servants, “Seek for me a woman who has a familiar spirit, that I may go to her and inquire of her.” His servants said to him, “Behold, there is a woman who has a familiar spirit at Endor.” ^7

**8** Saul disguised himself and put on other clothing, and went, he and two men with him, and they came to the woman by night. Then he said, “Please consult for me by the familiar spirit, and bring me up whomever I shall name to you.” ^8

**9** The woman said to him, “Behold, you know what Saul has done, how he has cut off those who have familiar spirits and the wizards out of the land. Why then do you lay a snare for my life, to cause me to die?” ^9

**10** Saul swore to her by the LORD, saying, “As the LORD lives, no punishment will happen to you for this thing.” ^10

**11** Then the woman said, “Whom shall I bring up to you?” He said, “Bring Samuel up for me.” ^11

**12** When the woman saw Samuel, she cried with a loud voice; and the woman spoke to Saul, saying, “Why have you deceived me? For you are Saul!” ^12

**13** The king said to her, “Don’t be afraid! What do you see?” The woman said to Saul, “I see a god coming up out of the earth.” ^13

**14** He said to her, “What does he look like?” She said, “An old man comes up. He is covered with a robe.” Saul perceived that it was Samuel, and he bowed with his face to the ground, and showed respect. ^14

**15** Samuel said to Saul, “Why have you disturbed me, to bring me up?” Saul answered, “I am very distressed; for the Philistines make war against me, and God has departed from me, and answers me no more, by prophets, or by dreams. Therefore I have called you, that you may make known to me what I shall do.” ^15

**16** Samuel said, “Why then do you ask me, since the LORD has departed from you and has become your adversary? ^16

**17** The LORD has done to you as he spoke by me. The LORD has torn the kingdom out of your hand and given it to your neighbor, even to David. ^17

**18** Because you didn’t obey the LORD’s voice, and didn’t execute his fierce wrath on Amalek, therefore the LORD has done this thing to you today. ^18

**19** Moreover the LORD will deliver Israel also with you into the hand of the Philistines; and tomorrow you and your sons will be with me. The LORD will deliver the army of Israel also into the hand of the Philistines.” ^19

**20** Then Saul fell immediately his full length on the earth, and was terrified, because of Samuel’s words. There was no strength in him, for he had eaten no bread all day long or all night long. ^20

**21** The woman came to Saul and saw that he was very troubled, and said to him, “Behold, your servant has listened to your voice, and I have put my life in my hand, and have listened to your words which you spoke to me. ^21

**22** Now therefore, please listen also to the voice of your servant, and let me set a morsel of bread before you. Eat, that you may have strength when you go on your way.” ^22

**23** But he refused, and said, “I will not eat.” But his servants, together with the woman, constrained him; and he listened to their voice. So he arose from the earth and sat on the bed. ^23

**24** The woman had a fattened calf in the house. She hurried and killed it; and she took flour and kneaded it, and baked unleavened bread of it. ^24

**25** She brought it before Saul and before his servants, and they ate. Then they rose up and went away that night. ^25

← [[1 Samuel 27 - WEBU]] | [[1 Samuel 29 - WEBU]] →
