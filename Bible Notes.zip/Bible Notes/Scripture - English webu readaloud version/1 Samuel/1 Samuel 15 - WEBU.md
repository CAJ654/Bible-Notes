---
book: 1 Samuel
chapter: 15
version: WEBU
---
# 1 Samuel 15 (WEBU)

← [[1 Samuel 14 - WEBU]] | [[1 Samuel 16 - WEBU]] →

**1** Samuel said to Saul, “The LORD sent me to anoint you to be king over his people, over Israel. Now therefore listen to the voice of the LORD’s words. ^1

**2** The LORD of Armies says, ‘I remember what Amalek did to Israel, how he set himself against him on the way when he came up out of Egypt. ^2

**3** Now go and strike Amalek, and utterly destroy all that they have, and don’t spare them; but kill both man and woman, infant and nursing baby, ox and sheep, camel and donkey.’” ^3

**4** Saul summoned the people, and counted them in Telaim, two hundred thousand footmen and ten thousand men of Judah. ^4

**5** Saul came to the city of Amalek, and set an ambush in the valley. ^5

**6** Saul said to the Kenites, “Go, depart, go down from among the Amalekites, lest I destroy you with them; for you showed kindness to all the children of Israel when they came up out of Egypt.” So the Kenites departed from among the Amalekites. ^6

**7** Saul struck the Amalekites, from Havilah as you go to Shur, which is before Egypt. ^7

**8** He took Agag the king of the Amalekites alive, and utterly destroyed all the people with the edge of the sword. ^8

**9** But Saul and the people spared Agag and the best of the sheep, of the cattle, of the fat calves, of the lambs, and all that was good, and were not willing to utterly destroy them; but everything that was vile and refuse, that they destroyed utterly. ^9

**10** Then the LORD’s word came to Samuel, saying, ^10

**11** “It grieves me that I have set up Saul to be king, for he has turned back from following me, and has not performed my commandments.” Samuel was angry; and he cried to the LORD all night. ^11

**12** Samuel rose early to meet Saul in the morning; and Samuel was told, saying, “Saul came to Carmel, and behold, he set up a monument for himself, turned, passed on, and went down to Gilgal.” ^12

**13** Samuel came to Saul; and Saul said to him, “You are blessed by the LORD! I have performed the commandment of the LORD.” ^13

**14** Samuel said, “Then what does this bleating of the sheep in my ears and the lowing of the cattle which I hear mean?” ^14

**15** Saul said, “They have brought them from the Amalekites; for the people spared the best of the sheep and of the cattle, to sacrifice to the LORD your God. We have utterly destroyed the rest.” ^15

**16** Then Samuel said to Saul, “Stay, and I will tell you what the LORD said to me last night.” He said to him, “Say on.” ^16

**17** Samuel said, “Though you were little in your own sight, weren’t you made the head of the tribes of Israel? The LORD anointed you king over Israel; ^17

**18** and the LORD sent you on a journey, and said, ‘Go, and utterly destroy the sinners the Amalekites, and fight against them until they are consumed.’ ^18

**19** Why then didn’t you obey the LORD’s voice, but took the plunder, and did that which was evil in the LORD’s sight?” ^19

**20** Saul said to Samuel, “But I have obeyed the LORD’s voice, and have gone the way which the LORD sent me, and have brought Agag the king of Amalek, and have utterly destroyed the Amalekites. ^20

**21** But the people took of the plunder, sheep and cattle, the best of the devoted things, to sacrifice to the LORD your God in Gilgal.” ^21

**22** Samuel said, “Has the LORD as great delight in burnt offerings and sacrifices, as in obeying the LORD’s voice? Behold, to obey is better than sacrifice, and to listen than the fat of rams. ^22

**23** For rebellion is as the sin of witchcraft, and stubbornness is as idolatry and teraphim. Because you have rejected the LORD’s word, he has also rejected you from being king.” ^23

**24** Saul said to Samuel, “I have sinned; for I have transgressed the commandment of the LORD and your words, because I feared the people and obeyed their voice. ^24

**25** Now therefore, please pardon my sin, and turn again with me, that I may worship the LORD.” ^25

**26** Samuel said to Saul, “I will not return with you; for you have rejected the LORD’s word, and the LORD has rejected you from being king over Israel.” ^26

**27** As Samuel turned around to go away, Saul grabbed the skirt of his robe, and it tore. ^27

**28** Samuel said to him, “The LORD has torn the kingdom of Israel from you today, and has given it to a neighbor of yours who is better than you. ^28

**29** Also the Strength of Israel will not lie nor repent; for he is not a man, that he should repent.” ^29

**30** Then he said, “I have sinned; yet please honor me now before the elders of my people and before Israel, and come back with me, that I may worship the LORD your God.” ^30

**31** So Samuel went back with Saul; and Saul worshiped the LORD. ^31

**32** Then Samuel said, “Bring Agag the king of the Amalekites here to me!” Agag came to him cheerfully. Agag said, “Surely the bitterness of death is past.” ^32

**33** Samuel said, “As your sword has made women childless, so your mother will be childless among women!” Then Samuel cut Agag in pieces before the LORD in Gilgal. ^33

**34** Then Samuel went to Ramah; and Saul went up to his house to Gibeah of Saul. ^34

**35** Samuel came no more to see Saul until the day of his death, but Samuel mourned for Saul. The LORD grieved that he had made Saul king over Israel. ^35

← [[1 Samuel 14 - WEBU]] | [[1 Samuel 16 - WEBU]] →
