---
book: 1 Samuel
chapter: 14
version: WEBU
---
# 1 Samuel 14 (WEBU)

← [[1 Samuel 13 - WEBU]] | [[1 Samuel 15 - WEBU]] →

**1** Now it happened on a day that Jonathan the son of Saul said to the young man who bore his armor, “Come! Let’s go over to the Philistines’ garrison that is on the other side.” But he didn’t tell his father. ^1

**2** Saul stayed in the uttermost part of Gibeah under the pomegranate tree which is in Migron; and the people who were with him were about six hundred men, ^2

**3** including Ahijah the son of Ahitub, Ichabod’s brother, the son of Phinehas, the son of Eli the priest of the LORD in Shiloh, wearing an ephod. The people didn’t know that Jonathan was gone. ^3

**4** Between the passes, by which Jonathan sought to go over to the Philistines’ garrison, there was a rocky crag on the one side and a rocky crag on the other side; and the name of the one was Bozez, and the name of the other Seneh. ^4

**5** The one crag rose up on the north in front of Michmash, and the other on the south in front of Geba. ^5

**6** Jonathan said to the young man who bore his armor, “Come! Let’s go over to the garrison of these uncircumcised. It may be that the LORD will work for us, for there is no restraint on the LORD to save by many or by few.” ^6

**7** His armor bearer said to him, “Do all that is in your heart. Go, and behold, I am with you according to your heart.” ^7

**8** Then Jonathan said, “Behold, we will pass over to the men, and we will reveal ourselves to them. ^8

**9** If they say this to us, ‘Wait until we come to you!’ then we will stand still in our place and will not go up to them. ^9

**10** But if they say this, ‘Come up to us!’ then we will go up, for the LORD has delivered them into our hand. This shall be the sign to us.” ^10

**11** Both of them revealed themselves to the garrison of the Philistines; and the Philistines said, “Behold, the Hebrews are coming out of the holes where they had hidden themselves!” ^11

**12** The men of the garrison answered Jonathan and his armor bearer, and said, “Come up to us, and we will show you something!” Jonathan said to his armor bearer, “Come up after me, for the LORD has delivered them into the hand of Israel.” ^12

**13** Jonathan climbed up on his hands and on his feet, and his armor bearer after him, and they fell before Jonathan; and his armor bearer killed them after him. ^13

**14** That first slaughter, which Jonathan and his armor bearer made, was about twenty men, within as it were half a furrow’s length in an acre of land. ^14

**15** There was a trembling in the camp, in the field, and among all the people; the garrison and the raiders also trembled; and the earth quaked, so there was an exceedingly great trembling. ^15

**16** The watchmen of Saul in Gibeah of Benjamin looked; and behold, the multitude melted away and scattered. ^16

**17** Then Saul said to the people who were with him, “Count now, and see who is missing from us.” When they had counted, behold, Jonathan and his armor bearer were not there. ^17

**18** Saul said to Ahijah, “Bring God’s ark here.” For God’s ark was with the children of Israel at that time. ^18

**19** While Saul talked to the priest, the tumult that was in the camp of the Philistines went on and increased; and Saul said to the priest, “Withdraw your hand!” ^19

**20** Saul and all the people who were with him were gathered together, and came to the battle; and behold, they were all striking each other with their swords in very great confusion. ^20

**21** Now the Hebrews who were with the Philistines before and who went up with them into the camp from all around, even they also turned to be with the Israelites who were with Saul and Jonathan. ^21

**22** Likewise all the men of Israel who had hidden themselves in the hill country of Ephraim, when they heard that the Philistines fled, even they also followed hard after them in the battle. ^22

**23** So the LORD saved Israel that day; and the battle passed over by Beth Aven. ^23

**24** The men of Israel were distressed that day; for Saul had adjured the people, saying, “Cursed is the man who eats any food until it is evening, and I am avenged of my enemies.” So none of the people tasted food. ^24

**25** All the people came into the forest; and there was honey on the ground. ^25

**26** When the people had come to the forest, behold, honey was dripping, but no one put his hand to his mouth, for the people feared the oath. ^26

**27** But Jonathan didn’t hear when his father commanded the people with the oath. Therefore he put out the end of the rod that was in his hand and dipped it in the honeycomb, and put his hand to his mouth; and his eyes brightened. ^27

**28** Then one of the people answered, and said, “Your father directly commanded the people with an oath, saying, ‘Cursed is the man who eats food today.’” So the people were faint. ^28

**29** Then Jonathan said, “My father has troubled the land. Please look how my eyes have brightened because I tasted a little of this honey. ^29

**30** How much more, if perhaps the people had eaten freely today of the plunder of their enemies which they found? For now there has been no great slaughter among the Philistines.” ^30

**31** They struck the Philistines that day from Michmash to Aijalon. The people were very faint; ^31

**32** and the people pounced on the plunder, and took sheep, cattle, and calves, and killed them on the ground; and the people ate them with the blood. ^32

**33** Then they told Saul, saying, “Behold, the people are sinning against the LORD, in that they eat meat with the blood.” He said, “You have dealt treacherously. Roll a large stone to me today!” ^33

**34** Saul said, “Disperse yourselves among the people, and tell them, ‘Every man bring me here his ox, and every man his sheep, and kill them here, and eat; and don’t sin against the LORD in eating meat with the blood.’” All the people brought every man his ox with him that night, and killed them there. ^34

**35** Saul built an altar to the LORD. This was the first altar that he built to the LORD. ^35

**36** Saul said, “Let’s go down after the Philistines by night, and take plunder among them until the morning light. Let’s not leave a man of them.” They said, “Do whatever seems good to you.” Then the priest said, “Let’s draw near here to God.” ^36

**37** Saul asked counsel of God: “Shall I go down after the Philistines? Will you deliver them into the hand of Israel?” But he didn’t answer him that day. ^37

**38** Saul said, “Draw near here, all you chiefs of the people, and know and see in whom this sin has been today. ^38

**39** For as the LORD lives, who saves Israel, though it is in Jonathan my son, he shall surely die.” But there was not a man among all the people who answered him. ^39

**40** Then he said to all Israel, “You be on one side, and I and Jonathan my son will be on the other side.” The people said to Saul, “Do what seems good to you.” ^40

**41** Therefore Saul said to the LORD, the God of Israel, “Show the right.” Jonathan and Saul were chosen, but the people escaped. ^41

**42** Saul said, “Cast lots between me and Jonathan my son.” Jonathan was selected. ^42

**43** Then Saul said to Jonathan, “Tell me what you have done!” Jonathan told him, and said, “I certainly did taste a little honey with the end of the rod that was in my hand; and behold, I must die.” ^43

**44** Saul said, “God do so and more also; for you shall surely die, Jonathan.” ^44

**45** The people said to Saul, “Shall Jonathan die, who has worked this great salvation in Israel? Far from it! As the LORD lives, there shall not one hair of his head fall to the ground, for he has worked with God today!” So the people rescued Jonathan, so he didn’t die. ^45

**46** Then Saul went up from following the Philistines; and the Philistines went to their own place. ^46

**47** Now when Saul had taken the kingdom over Israel, he fought against all his enemies on every side: against Moab, and against the children of Ammon, and against Edom, and against the kings of Zobah, and against the Philistines. Wherever he turned himself, he defeated them. ^47

**48** He did valiantly and struck the Amalekites, and delivered Israel out of the hands of those who plundered them. ^48

**49** Now the sons of Saul were Jonathan, Ishvi, and Malchishua; and the names of his two daughters were these: the name of the firstborn Merab, and the name of the younger Michal. ^49

**50** The name of Saul’s wife was Ahinoam the daughter of Ahimaaz. The name of the captain of his army was Abner the son of Ner, Saul’s uncle. ^50

**51** Kish was the father of Saul, and Ner the father of Abner was the son of Abiel. ^51

**52** There was severe war against the Philistines all the days of Saul; and when Saul saw any mighty man or any valiant man, he took him into his service. ^52

← [[1 Samuel 13 - WEBU]] | [[1 Samuel 15 - WEBU]] →
