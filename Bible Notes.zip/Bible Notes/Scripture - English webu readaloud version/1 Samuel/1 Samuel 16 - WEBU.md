---
book: 1 Samuel
chapter: 16
version: WEBU
---
# 1 Samuel 16 (WEBU)

← [[1 Samuel 15 - WEBU]] | [[1 Samuel 17 - WEBU]] →

**1** The LORD said to Samuel, “How long will you mourn for Saul, since I have rejected him from being king over Israel? Fill your horn with oil, and go. I will send you to Jesse the Bethlehemite, for I have provided a king for myself among his sons.” ^1

**2** Samuel said, “How can I go? If Saul hears it, he will kill me.” The LORD said, “Take a heifer with you, and say, ‘I have come to sacrifice to the LORD.’ ^2

**3** Call Jesse to the sacrifice, and I will show you what you shall do. You shall anoint to me him whom I name to you.” ^3

**4** Samuel did that which the LORD spoke, and came to Bethlehem. The elders of the city came to meet him trembling, and said, “Do you come peaceably?” ^4

**5** He said, “Peaceably; I have come to sacrifice to the LORD. Sanctify yourselves, and come with me to the sacrifice.” He sanctified Jesse and his sons, and called them to the sacrifice. ^5

**6** When they had come, he looked at Eliab, and said, “Surely the LORD’s anointed is before him.” ^6

**7** But the LORD said to Samuel, “Don’t look on his face, or on the height of his stature, because I have rejected him; for I don’t see as man sees. For man looks at the outward appearance, but the LORD looks at the heart.” ^7

**8** Then Jesse called Abinadab, and made him pass before Samuel. He said, “The LORD has not chosen this one, either.” ^8

**9** Then Jesse made Shammah to pass by. He said, “The LORD has not chosen this one, either.” ^9

**10** Jesse made seven of his sons to pass before Samuel. Samuel said to Jesse, “The LORD has not chosen these.” ^10

**11** Samuel said to Jesse, “Are all your children here?” He said, “There remains yet the youngest. Behold, he is keeping the sheep.” Samuel said to Jesse, “Send and get him, for we will not sit down until he comes here.” ^11

**12** He sent, and brought him in. Now he was ruddy, with a handsome face and good appearance. The LORD said, “Arise! Anoint him, for this is he.” ^12

**13** Then Samuel took the horn of oil and anointed him in the middle of his brothers. Then the LORD’s Spirit came mightily on David from that day forward. So Samuel rose up and went to Ramah. ^13

**14** Now the LORD’s Spirit departed from Saul, and an evil spirit from the LORD troubled him. ^14

**15** Saul’s servants said to him, “See now, an evil spirit from God troubles you. ^15

**16** Let our lord now command your servants who are in front of you to seek out a man who is a skillful player on the harp. Then when the evil spirit from God is on you, he will play with his hand, and you will be well.” ^16

**17** Saul said to his servants, “Provide me now a man who can play well, and bring him to me.” ^17

**18** Then one of the young men answered and said, “Behold, I have seen a son of Jesse the Bethlehemite who is skillful in playing, a mighty man of valor, a man of war, prudent in speech, and a handsome person; and the LORD is with him.” ^18

**19** Therefore Saul sent messengers to Jesse, and said, “Send me David your son, who is with the sheep.” ^19

**20** Jesse took a donkey loaded with bread, a container of wine, and a young goat, and sent them by David his son to Saul. ^20

**21** David came to Saul and stood before him. He loved him greatly; and he became his armor bearer. ^21

**22** Saul sent to Jesse, saying, “Please let David stand before me, for he has found favor in my sight.” ^22

**23** When the spirit from God was on Saul, David took the harp and played with his hand; so Saul was refreshed and was well, and the evil spirit departed from him. ^23

← [[1 Samuel 15 - WEBU]] | [[1 Samuel 17 - WEBU]] →
