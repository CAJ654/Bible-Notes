---
book: 1 Samuel
chapter: 25
version: WEBU
---
# 1 Samuel 25 (WEBU)

← [[1 Samuel 24 - WEBU]] | [[1 Samuel 26 - WEBU]] →

**1** Samuel died; and all Israel gathered themselves together and mourned for him, and buried him at his house at Ramah. Then David arose and went down to the wilderness of Paran. ^1

**2** There was a man in Maon whose possessions were in Carmel; and the man was very great. He had three thousand sheep and a thousand goats; and he was shearing his sheep in Carmel. ^2

**3** Now the name of the man was Nabal; and the name of his wife Abigail. This woman was intelligent and had a beautiful face; but the man was surly and evil in his doings. He was of the house of Caleb. ^3

**4** David heard in the wilderness that Nabal was shearing his sheep. ^4

**5** David sent ten young men; and David said to the young men, “Go up to Carmel, and go to Nabal, and greet him in my name. ^5

**6** Tell him, ‘Long life to you! Peace be to you! Peace be to your house! Peace be to all that you have! ^6

**7** Now I have heard that you have shearers. Your shepherds have now been with us, and we didn’t harm them. Nothing was missing from them all the time they were in Carmel. ^7

**8** Ask your young men, and they will tell you. Therefore let the young men find favor in your eyes, for we come on a good day. Please give whatever comes to your hand to your servants and to your son David.’” ^8

**9** When David’s young men came, they spoke to Nabal all those words in the name of David, and waited. ^9

**10** Nabal answered David’s servants and said, “Who is David? Who is the son of Jesse? There are many servants who break away from their masters these days. ^10

**11** Shall I then take my bread, my water, and my meat that I have killed for my shearers, and give it to men who I don’t know where they come from?” ^11

**12** So David’s young men turned on their way and went back, and came and told him all these words. ^12

**13** David said to his men, “Every man put on his sword!” Every man put on his sword. David also put on his sword. About four hundred men followed David, and two hundred stayed by the baggage. ^13

**14** But one of the young men told Abigail, Nabal’s wife, saying, “Behold, David sent messengers out of the wilderness to greet our master; and he insulted them. ^14

**15** But the men were very good to us, and we were not harmed, and we didn’t miss anything as long as we went with them, when we were in the fields. ^15

**16** They were a wall to us both by night and by day, all the while we were with them keeping the sheep. ^16

**17** Now therefore know and consider what you will do; for evil is determined against our master and against all his house, for he is such a worthless fellow that one can’t speak to him.” ^17

**18** Then Abigail hurried and took two hundred loaves of bread, two containers of wine, five sheep ready dressed, five seahs of parched grain, one hundred clusters of raisins, and two hundred cakes of figs, and laid them on donkeys. ^18

**19** She said to her young men, “Go on before me. Behold, I am coming after you.” But she didn’t tell her husband, Nabal. ^19

**20** As she rode on her donkey, and came down hidden by the mountain, behold, David and his men came down toward her, and she met them. ^20

**21** Now David had said, “Surely in vain I have kept all that this fellow has in the wilderness, so that nothing was missed of all that pertained to him. He has returned me evil for good. ^21

**22** God do so to the enemies of David, and more also, if I leave of all that belongs to him by the morning light so much as one who urinates on a wall.” ^22

**23** When Abigail saw David, she hurried and got off her donkey, and fell before David on her face and bowed herself to the ground. ^23

**24** She fell at his feet and said, “On me, my lord, on me be the blame! Please let your servant speak in your ears. Hear the words of your servant. ^24

**25** Please don’t let my lord pay attention to this worthless fellow, Nabal, for as his name is, so is he. Nabal is his name, and folly is with him; but I, your servant, didn’t see my lord’s young men whom you sent. ^25

**26** Now therefore, my lord, as the LORD lives and as your soul lives, since the LORD has withheld you from blood guiltiness and from avenging yourself with your own hand, now therefore let your enemies and those who seek evil to my lord be as Nabal. ^26

**27** Now this present which your servant has brought to my lord, let it be given to the young men who follow my lord. ^27

**28** Please forgive the trespass of your servant. For the LORD will certainly make my lord a sure house, because my lord fights the LORD’s battles. Evil will not be found in you all your days. ^28

**29** Though men may rise up to pursue you and to seek your soul, yet the soul of my lord will be bound in the bundle of life with the LORD your God. He will sling out the souls of your enemies as from a sling’s pocket. ^29

**30** It will come to pass, when the LORD has done to my lord according to all the good that he has spoken concerning you, and has appointed you prince over Israel, ^30

**31** that this shall be no grief to you, nor offense of heart to my lord, either that you have shed blood without cause, or that my lord has avenged himself. When the LORD has dealt well with my lord, then remember your servant.” ^31

**32** David said to Abigail, “Blessed is the LORD, the God of Israel, who sent you today to meet me! ^32

**33** Blessed is your discretion, and blessed are you, who have kept me today from blood guiltiness, and from avenging myself with my own hand. ^33

**34** For indeed, as the LORD the God of Israel lives, who has withheld me from harming you, unless you had hurried and come to meet me, surely there wouldn’t have been left to Nabal by the morning light so much as one who urinates on a wall.” ^34

**35** So David received from her hand that which she had brought him. Then he said to her, “Go up in peace to your house. Behold, I have listened to your voice and have granted your request.” ^35

**36** Abigail came to Nabal; and behold, he held a feast in his house like the feast of a king. Nabal’s heart was merry within him, for he was very drunk. Therefore she told him nothing until the morning light. ^36

**37** In the morning, when the wine had gone out of Nabal, his wife told him these things; and his heart died within him, and he became as a stone. ^37

**38** About ten days later, the LORD struck Nabal, so that he died. ^38

**39** When David heard that Nabal was dead, he said, “Blessed is the LORD, who has pleaded the cause of my reproach from the hand of Nabal, and has kept back his servant from evil. The LORD has returned the evildoing of Nabal on his own head.” David sent and spoke concerning Abigail, to take her to himself as wife. ^39

**40** When David’s servants had come to Abigail to Carmel, they spoke to her, saying, “David has sent us to you, to take you to him as wife.” ^40

**41** She arose and bowed herself with her face to the earth, and said, “Behold, your servant is a servant to wash the feet of the servants of my lord.” ^41

**42** Abigail hurriedly arose and rode on a donkey with her five maids who followed her; and she went after the messengers of David, and became his wife. ^42

**43** David also took Ahinoam of Jezreel; and they both became his wives. ^43

**44** Now Saul had given Michal his daughter, David’s wife, to Palti the son of Laish, who was of Gallim. ^44

← [[1 Samuel 24 - WEBU]] | [[1 Samuel 26 - WEBU]] →
