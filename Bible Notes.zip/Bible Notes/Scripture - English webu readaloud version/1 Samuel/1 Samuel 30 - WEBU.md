---
book: 1 Samuel
chapter: 30
version: WEBU
---
# 1 Samuel 30 (WEBU)

← [[1 Samuel 29 - WEBU]] | [[1 Samuel 31 - WEBU]] →

**1** When David and his men had come to Ziklag on the third day, the Amalekites had made a raid on the South and on Ziklag, and had struck Ziklag and burned it with fire, ^1

**2** and had taken captive the women and all who were in it, both small and great. They didn’t kill any, but carried them off and went their way. ^2

**3** When David and his men came to the city, behold, it was burned with fire; and their wives, their sons, and their daughters were taken captive. ^3

**4** Then David and the people who were with him lifted up their voice and wept until they had no more power to weep. ^4

**5** David’s two wives were taken captive, Ahinoam the Jezreelitess, and Abigail the wife of Nabal the Carmelite. ^5

**6** David was greatly distressed, for the people spoke of stoning him, because the souls of all the people were grieved, every man for his sons and for his daughters; but David strengthened himself in the LORD his God. ^6

**7** David said to Abiathar the priest, the son of Ahimelech, “Please bring the ephod here to me.” Abiathar brought the ephod to David. ^7

**8** David inquired of the LORD, saying, “If I pursue after this troop, will I overtake them?” He answered him, “Pursue, for you will surely overtake them, and will without fail recover all.” ^8

**9** So David went, he and the six hundred men who were with him, and came to the brook Besor, where those who were left behind stayed. ^9

**10** But David pursued, he and four hundred men; for two hundred stayed behind, who were so faint that they couldn’t go over the brook Besor. ^10

**11** They found an Egyptian in the field, and brought him to David, and gave him bread, and he ate; and they gave him water to drink. ^11

**12** They gave him a piece of a cake of figs and two clusters of raisins. When he had eaten, his spirit came again to him; for he had eaten no bread, and drank no water for three days and three nights. ^12

**13** David asked him, “To whom do you belong? Where are you from?” He said, “I am a young man of Egypt, servant to an Amalekite; and my master left me, because three days ago I got sick. ^13

**14** We made a raid on the South of the Cherethites, and on that which belongs to Judah, and on the South of Caleb; and we burned Ziklag with fire.” ^14

**15** David said to him, “Will you bring me down to this troop?” He said, “Swear to me by God that you will not kill me and not deliver me up into the hands of my master, and I will bring you down to this troop.” ^15

**16** When he had brought him down, behold, they were spread around over all the ground, eating, drinking, and dancing, because of all the great plunder that they had taken out of the land of the Philistines, and out of the land of Judah. ^16

**17** David struck them from the twilight even to the evening of the next day. Not a man of them escaped from there, except four hundred young men who rode on camels and fled. ^17

**18** David recovered all that the Amalekites had taken, and David rescued his two wives. ^18

**19** There was nothing lacking to them, neither small nor great, neither sons nor daughters, neither plunder, nor anything that they had taken. David brought them all back. ^19

**20** David took all the flocks and the herds, which they drove before those other livestock, and said, “This is David’s plunder.” ^20

**21** David came to the two hundred men, who were so faint that they could not follow David, whom also they had made to stay at the brook Besor; and they went out to meet David, and to meet the people who were with him. When David came near to the people, he greeted them. ^21

**22** Then all the wicked men and worthless fellows of those who went with David answered and said, “Because they didn’t go with us, we will not give them anything of the plunder that we have recovered, except to every man his wife and his children, that he may lead them away and depart.” ^22

**23** Then David said, “Do not do so, my brothers, with that which the LORD has given to us, who has preserved us, and delivered the troop that came against us into our hand. ^23

**24** Who will listen to you in this matter? For as his share is who goes down to the battle, so shall his share be who stays with the baggage. They shall share alike.” ^24

**25** It was so from that day forward that he made it a statute and an ordinance for Israel to this day. ^25

**26** When David came to Ziklag, he sent some of the plunder to the elders of Judah, even to his friends, saying, “Behold, a present for you from the plunder of the LORD’s enemies.” ^26

**27** He sent it to those who were in Bethel, to those who were in Ramoth of the South, to those who were in Jattir, ^27

**28** to those who were in Aroer, to those who were in Siphmoth, to those who were in Eshtemoa, ^28

**29** to those who were in Racal, to those who were in the cities of the Jerahmeelites, to those who were in the cities of the Kenites, ^29

**30** to those who were in Hormah, to those who were in Borashan, to those who were in Athach, ^30

**31** to those who were in Hebron, and to all the places where David himself and his men used to stay. ^31

← [[1 Samuel 29 - WEBU]] | [[1 Samuel 31 - WEBU]] →
