---
book: 1 Samuel
chapter: 3
version: WEBU
---
# 1 Samuel 3 (WEBU)

← [[1 Samuel 2 - WEBU]] | [[1 Samuel 4 - WEBU]] →

**1** The child Samuel ministered to the LORD before Eli. The LORD’s word was rare in those days. There were not many visions, then. ^1

**2** At that time, when Eli was laid down in his place (now his eyes had begun to grow dim, so that he could not see), ^2

**3** and God’s lamp hadn’t yet gone out, and Samuel had laid down in the LORD’s temple where God’s ark was, ^3

**4** The LORD called Samuel. He said, “Here I am.” ^4

**5** He ran to Eli and said, “Here I am; for you called me.” He said, “I didn’t call. Lie down again.” He went and lay down. ^5

**6** The LORD called yet again, “Samuel!” Samuel arose and went to Eli and said, “Here I am; for you called me.” He answered, “I didn’t call, my son. Lie down again.” ^6

**7** Now Samuel didn’t yet know the LORD, neither was the LORD’s word yet revealed to him. ^7

**8** The LORD called Samuel again the third time. He arose and went to Eli and said, “Here I am; for you called me.” Eli perceived that the LORD had called the child. ^8

**9** Therefore Eli said to Samuel, “Go, lie down. It shall be, if he calls you, that you shall say, ‘Speak, LORD; for your servant hears.’” So Samuel went and lay down in his place. ^9

**10** The LORD came, and stood, and called as at other times, “Samuel! Samuel!” Then Samuel said, “Speak; for your servant hears.” ^10

**11** The LORD said to Samuel, “Behold, I will do a thing in Israel at which both the ears of everyone who hears it will tingle. ^11

**12** In that day I will perform against Eli all that I have spoken concerning his house, from the beginning even to the end. ^12

**13** For I have told him that I will judge his house forever for the iniquity which he knew, because his sons brought a curse on themselves, and he didn’t restrain them. ^13

**14** Therefore I have sworn to the house of Eli that the iniquity of Eli’s house shall not be removed with sacrifice or offering forever.” ^14

**15** Samuel lay until the morning, and opened the doors of the LORD’s house. Samuel was afraid to show Eli the vision. ^15

**16** Then Eli called Samuel and said, “Samuel, my son!” He said, “Here I am.” ^16

**17** He said, “What is the thing that he has spoken to you? Please don’t hide it from me. God do so to you, and more also, if you hide anything from me of all the things that he spoke to you.” ^17

**18** Samuel told him every bit, and hid nothing from him. He said, “It is the LORD. Let him do what seems good to him.” ^18

**19** Samuel grew, and the LORD was with him and let none of his words fall to the ground. ^19

**20** All Israel from Dan even to Beersheba knew that Samuel was established to be a prophet of the LORD. ^20

**21** The LORD appeared again in Shiloh; for the LORD revealed himself to Samuel in Shiloh by the LORD’s word. ^21

← [[1 Samuel 2 - WEBU]] | [[1 Samuel 4 - WEBU]] →
