---
book: 1 Samuel
chapter: 23
version: WEBU
---
# 1 Samuel 23 (WEBU)

← [[1 Samuel 22 - WEBU]] | [[1 Samuel 24 - WEBU]] →

**1** David was told, “Behold, the Philistines are fighting against Keilah, and are robbing the threshing floors.” ^1

**2** Therefore David inquired of the LORD, saying, “Shall I go and strike these Philistines?” The LORD said to David, “Go strike the Philistines, and save Keilah.” ^2

**3** David’s men said to him, “Behold, we are afraid here in Judah. How much more then if we go to Keilah against the armies of the Philistines?” ^3

**4** Then David inquired of the LORD yet again. The LORD answered him, and said, “Arise, go down to Keilah; for I will deliver the Philistines into your hand.” ^4

**5** David and his men went to Keilah and fought with the Philistines, and brought away their livestock, and killed them with a great slaughter. So David saved the inhabitants of Keilah. ^5

**6** When Abiathar the son of Ahimelech fled to David to Keilah, he came down with an ephod in his hand. ^6

**7** Saul was told that David had come to Keilah. Saul said, “God has delivered him into my hand, for he is shut in by entering into a town that has gates and bars.” ^7

**8** Saul summoned all the people to war, to go down to Keilah to besiege David and his men. ^8

**9** David knew that Saul was devising mischief against him. He said to Abiathar the priest, “Bring the ephod here.” ^9

**10** Then David said, “O LORD, the God of Israel, your servant has surely heard that Saul seeks to come to Keilah to destroy the city for my sake. ^10

**11** Will the men of Keilah deliver me up into his hand? Will Saul come down, as your servant has heard? LORD, the God of Israel, I beg you, tell your servant.” The LORD said, “He will come down.” ^11

**12** Then David said, “Will the men of Keilah deliver me and my men into the hand of Saul?” The LORD said, “They will deliver you up.” ^12

**13** Then David and his men, who were about six hundred, arose and departed out of Keilah and went wherever they could go. Saul was told that David had escaped from Keilah; and he gave up going there. ^13

**14** David stayed in the wilderness in the strongholds, and remained in the hill country in the wilderness of Ziph. Saul sought him every day, but God didn’t deliver him into his hand. ^14

**15** David saw that Saul had come out to seek his life. David was in the wilderness of Ziph in the woods. ^15

**16** Jonathan, Saul’s son, arose and went to David into the woods, and strengthened his hand in God. ^16

**17** He said to him, “Don’t be afraid, for the hand of Saul my father won’t find you; and you will be king over Israel, and I will be next to you; and Saul my father knows that also.” ^17

**18** They both made a covenant before the LORD. Then David stayed in the woods and Jonathan went to his house. ^18

**19** Then the Ziphites came up to Saul to Gibeah, saying, “Doesn’t David hide himself with us in the strongholds in the woods, in the hill of Hachilah, which is on the south of the desert? ^19

**20** Now therefore, O king, come down. According to all the desire of your soul to come down; and our part will be to deliver him up into the king’s hand.” ^20

**21** Saul said, “You are blessed by the LORD, for you have had compassion on me. ^21

**22** Please go make yet more sure, and know and see his place where his haunt is, and who has seen him there; for I have been told that he is very cunning. ^22

**23** See therefore, and take knowledge of all the lurking places where he hides himself; and come again to me with certainty, and I will go with you. It shall happen, if he is in the land, that I will search him out among all the thousands of Judah.” ^23

**24** They arose, and went to Ziph before Saul; but David and his men were in the wilderness of Maon, in the Arabah on the south of the desert. ^24

**25** Saul and his men went to seek him. When David was told, he went down to the rock, and stayed in the wilderness of Maon. When Saul heard that, he pursued David in the wilderness of Maon. ^25

**26** Saul went on this side of the mountain, and David and his men on that side of the mountain; and David hurried to get away for fear of Saul, for Saul and his men surrounded David and his men to take them. ^26

**27** But a messenger came to Saul, saying, “Hurry and come, for the Philistines have made a raid on the land!” ^27

**28** So Saul returned from pursuing David, and went against the Philistines. Therefore they called that place Sela Hammahlekoth. ^28

**29** David went up from there and lived in the strongholds of En Gedi. ^29

← [[1 Samuel 22 - WEBU]] | [[1 Samuel 24 - WEBU]] →
