---
book: 1 Samuel
chapter: 18
version: WEBU
---
# 1 Samuel 18 (WEBU)

← [[1 Samuel 17 - WEBU]] | [[1 Samuel 19 - WEBU]] →

**1** When he had finished speaking to Saul, the soul of Jonathan was knit with the soul of David, and Jonathan loved him as his own soul. ^1

**2** Saul took him that day, and wouldn’t let him go home to his father’s house any more. ^2

**3** Then Jonathan and David made a covenant, because he loved him as his own soul. ^3

**4** Jonathan stripped himself of the robe that was on him and gave it to David with his clothing, even including his sword, his bow, and his sash. ^4

**5** David went out wherever Saul sent him, and behaved himself wisely; and Saul set him over the men of war. It was good in the sight of all the people, and also in the sight of Saul’s servants. ^5

**6** As they came, when David returned from the slaughter of the Philistine, the women came out of all the cities of Israel, singing and dancing, to meet King Saul with tambourines, with joy, and with instruments of music. ^6

**7** The women sang to one another as they played, and said, “Saul has slain his thousands, and David his ten thousands.” ^7

**8** Saul was very angry, and this saying displeased him. He said, “They have credited David with ten thousands, and they have only credited me with thousands. What can he have more but the kingdom?” ^8

**9** Saul watched David from that day and forward. ^9

**10** On the next day, an evil spirit from God came mightily on Saul, and he prophesied in the middle of the house. David played with his hand, as he did day by day. Saul had his spear in his hand; ^10

**11** and Saul threw the spear, for he said, “I will pin David to the wall!” David escaped from his presence twice. ^11

**12** Saul was afraid of David, because the LORD was with him, and had departed from Saul. ^12

**13** Therefore Saul removed him from his presence, and made him his captain over a thousand; and he went out and came in before the people. ^13

**14** David behaved himself wisely in all his ways; and the LORD was with him. ^14

**15** When Saul saw that he behaved himself very wisely, he stood in awe of him. ^15

**16** But all Israel and Judah loved David; for he went out and came in before them. ^16

**17** Saul said to David, “Behold, my elder daughter Merab. I will give her to you as wife. Only be valiant for me, and fight the LORD’s battles.” For Saul said, “Don’t let my hand be on him, but let the hand of the Philistines be on him.” ^17

**18** David said to Saul, “Who am I, and what is my life, or my father’s family in Israel, that I should be son-in-law to the king?” ^18

**19** But at the time when Merab, Saul’s daughter, should have been given to David, she was given to Adriel the Meholathite as wife. ^19

**20** Michal, Saul’s daughter, loved David; and they told Saul, and the thing pleased him. ^20

**21** Saul said, I will give her to him, that she may be a snare to him and that the hand of the Philistines may be against him. Therefore Saul said to David a second time, “You shall today be my son-in-law.” ^21

**22** Saul commanded his servants, “Talk with David secretly, and say, ‘Behold, the king has delight in you, and all his servants love you. Now therefore be the king’s son-in-law.’” ^22

**23** Saul’s servants spoke those words in the ears of David. David said, “Does it seem to you a light thing to be the king’s son-in-law, since I am a poor man and little known?” ^23

**24** The servants of Saul told him, saying, “David spoke like this.” ^24

**25** Saul said, “Tell David, ‘The king desires no dowry except one hundred foreskins of the Philistines, to be avenged of the king’s enemies.’” Now Saul thought he would make David fall by the hand of the Philistines. ^25

**26** When his servants told David these words, it pleased David well to be the king’s son-in-law. Before the deadline, ^26

**27** David arose and went, he and his men, and killed two hundred men of the Philistines. Then David brought their foreskins, and they gave them in full number to the king, that he might be the king’s son-in-law. Then Saul gave him Michal his daughter as wife. ^27

**28** Saul saw and knew that the LORD was with David; and Michal, Saul’s daughter, loved him. ^28

**29** Saul was even more afraid of David; and Saul was David’s enemy continually. ^29

**30** Then the princes of the Philistines went out; and as often as they went out, David behaved himself more wisely than all the servants of Saul, so that his name was highly esteemed. ^30

← [[1 Samuel 17 - WEBU]] | [[1 Samuel 19 - WEBU]] →
