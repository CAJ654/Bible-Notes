---
book: 1 Samuel
chapter: 8
version: WEBU
---
# 1 Samuel 8 (WEBU)

← [[1 Samuel 7 - WEBU]] | [[1 Samuel 9 - WEBU]] →

**1** When Samuel was old, he made his sons judges over Israel. ^1

**2** Now the name of his firstborn was Joel, and the name of his second, Abijah. They were judges in Beersheba. ^2

**3** His sons didn’t walk in his ways, but turned away after dishonest gain, took bribes, and perverted justice. ^3

**4** Then all the elders of Israel gathered themselves together and came to Samuel to Ramah. ^4

**5** They said to him, “Behold, you are old, and your sons don’t walk in your ways. Now make us a king to judge us like all the nations.” ^5

**6** But the thing displeased Samuel when they said, “Give us a king to judge us.” Samuel prayed to the LORD. ^6

**7** The LORD said to Samuel, “Listen to the voice of the people in all that they tell you; for they have not rejected you, but they have rejected me as the king over them. ^7

**8** According to all the works which they have done since the day that I brought them up out of Egypt even to this day, in that they have forsaken me and served other gods, so they also do to you. ^8

**9** Now therefore, listen to their voice. However, you shall protest solemnly to them, and shall show them the way of the king who will reign over them.” ^9

**10** Samuel told all the LORD’s words to the people who asked him for a king. ^10

**11** He said, “This will be the way of the king who shall reign over you: he will take your sons and appoint them as his servants, for his chariots and to be his horsemen; and they will run before his chariots. ^11

**12** He will appoint them to him for captains of thousands and captains of fifties; and he will assign some to plow his ground and to reap his harvest; and to make his instruments of war and the instruments of his chariots. ^12

**13** He will take your daughters to be perfumers, to be cooks, and to be bakers. ^13

**14** He will take your fields, your vineyards, and your olive groves, even your best, and give them to his servants. ^14

**15** He will take one tenth of your seed and of your vineyards, and give it to his officers and to his servants. ^15

**16** He will take your male servants, your female servants, your best young men, and your donkeys, and assign them to his own work. ^16

**17** He will take one tenth of your flocks; and you will be his servants. ^17

**18** You will cry out in that day because of your king whom you will have chosen for yourselves; and the LORD will not answer you in that day.” ^18

**19** But the people refused to listen to the voice of Samuel; and they said, “No, but we will have a king over us, ^19

**20** that we also may be like all the nations; and that our king may judge us, and go out before us, and fight our battles.” ^20

**21** Samuel heard all the words of the people, and he rehearsed them in the ears of the LORD. ^21

**22** The LORD said to Samuel, “Listen to their voice, and make them a king.” Samuel said to the men of Israel, “Everyone go to your own city.” ^22

← [[1 Samuel 7 - WEBU]] | [[1 Samuel 9 - WEBU]] →
