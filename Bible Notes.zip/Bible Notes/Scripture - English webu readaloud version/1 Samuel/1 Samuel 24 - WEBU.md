---
book: 1 Samuel
chapter: 24
version: WEBU
---
# 1 Samuel 24 (WEBU)

← [[1 Samuel 23 - WEBU]] | [[1 Samuel 25 - WEBU]] →

**1** When Saul had returned from following the Philistines, he was told, “Behold, David is in the wilderness of En Gedi.” ^1

**2** Then Saul took three thousand chosen men out of all Israel, and went to seek David and his men on the rocks of the wild goats. ^2

**3** He came to the sheep pens by the way, where there was a cave; and Saul went in to relieve himself. Now David and his men were staying in the innermost parts of the cave. ^3

**4** David’s men said to him, “Behold, the day of which the LORD said to you, ‘Behold, I will deliver your enemy into your hand, and you shall do to him as it shall seem good to you.’” Then David arose and cut off the skirt of Saul’s robe secretly. ^4

**5** Afterward, David’s heart struck him because he had cut off Saul’s skirt. ^5

**6** He said to his men, “The LORD forbid that I should do this thing to my lord, the LORD’s anointed, to stretch out my hand against him, since he is the LORD’s anointed.” ^6

**7** So David checked his men with these words, and didn’t allow them to rise against Saul. Saul rose up out of the cave, and went on his way. ^7

**8** David also arose afterward, and went out of the cave and cried after Saul, saying, “My lord the king!” When Saul looked behind him, David bowed with his face to the earth, and showed respect. ^8

**9** David said to Saul, “Why do you listen to men’s words, saying, ‘Behold, David seeks to harm you’? ^9

**10** Behold, today your eyes have seen how the LORD had delivered you today into my hand in the cave. Some urged me to kill you, but I spared you. I said, ‘I will not stretch out my hand against my lord, for he is the LORD’s anointed.’ ^10

**11** Moreover, my father, behold, yes, see the skirt of your robe in my hand; for in that I cut off the skirt of your robe and didn’t kill you, know and see that there is neither evil nor disobedience in my hand. I have not sinned against you, though you hunt for my life to take it. ^11

**12** May the LORD judge between me and you, and may the LORD avenge me of you; but my hand will not be on you. ^12

**13** As the proverb of the ancients says, ‘Out of the wicked comes wickedness;’ but my hand will not be on you. ^13

**14** Against whom has the king of Israel come out? Whom do you pursue? A dead dog? A flea? ^14

**15** May the LORD therefore be judge, and give sentence between me and you, and see, and plead my cause, and deliver me out of your hand.” ^15

**16** It came to pass, when David had finished speaking these words to Saul, that Saul said, “Is that your voice, my son David?” Saul lifted up his voice and wept. ^16

**17** He said to David, “You are more righteous than I; for you have done good to me, whereas I have done evil to you. ^17

**18** You have declared today how you have dealt well with me, because when the LORD had delivered me up into your hand, you didn’t kill me. ^18

**19** For if a man finds his enemy, will he let him go away unharmed? Therefore may the LORD reward you good for that which you have done to me today. ^19

**20** Now, behold, I know that you will surely be king, and that the kingdom of Israel will be established in your hand. ^20

**21** Swear now therefore to me by the LORD that you will not cut off my offspring after me, and that you will not destroy my name out of my father’s house.” ^21

**22** David swore to Saul. Saul went home, but David and his men went up to the stronghold. ^22

← [[1 Samuel 23 - WEBU]] | [[1 Samuel 25 - WEBU]] →
