---
book: 1 Samuel
chapter: 17
version: WEBU
---
# 1 Samuel 17 (WEBU)

← [[1 Samuel 16 - WEBU]] | [[1 Samuel 18 - WEBU]] →

**1** Now the Philistines gathered together their armies to battle; and they were gathered together at Socoh, which belongs to Judah, and encamped between Socoh and Azekah in Ephesdammim. ^1

**2** Saul and the men of Israel were gathered together, and encamped in the valley of Elah, and set the battle in array against the Philistines. ^2

**3** The Philistines stood on the mountain on the one side, and Israel stood on the mountain on the other side: and there was a valley between them. ^3

**4** A champion out of the camp of the Philistines named Goliath of Gath, whose height was six cubits and a span went out. ^4

**5** He had a helmet of bronze on his head, and he wore a coat of mail; and the weight of the coat was five thousand shekels of bronze. ^5

**6** He had bronze shin armor on his legs and a bronze javelin between his shoulders. ^6

**7** The staff of his spear was like a weaver’s beam; and his spear’s head weighed six hundred shekels of iron. His shield bearer went before him. ^7

**8** He stood and cried to the armies of Israel, and said to them, “Why have you come out to set your battle in array? Am I not a Philistine, and you servants to Saul? Choose a man for yourselves, and let him come down to me. ^8

**9** If he is able to fight with me and kill me, then will we be your servants; but if I prevail against him and kill him, then you will be our servants and serve us.” ^9

**10** The Philistine said, “I defy the armies of Israel today! Give me a man, that we may fight together!” ^10

**11** When Saul and all Israel heard those words of the Philistine, they were dismayed and greatly afraid. ^11

**12** Now David was the son of that Ephrathite of Bethlehem Judah, whose name was Jesse; and he had eight sons. The man was an elderly old man in the days of Saul. ^12

**13** The three oldest sons of Jesse had gone after Saul to the battle; and the names of his three sons who went to the battle were Eliab the firstborn, and next to him Abinadab, and the third Shammah. ^13

**14** David was the youngest; and the three oldest followed Saul. ^14

**15** Now David went back and forth from Saul to feed his father’s sheep at Bethlehem. ^15

**16** The Philistine came near morning and evening, and presented himself forty days. ^16

**17** Jesse said to David his son, “Now take for your brothers an ephah of this parched grain and these ten loaves, and carry them quickly to the camp to your brothers; ^17

**18** and bring these ten cheeses to the captain of their thousand; and see how your brothers are doing, and bring back news.” ^18

**19** Now Saul, and they, and all the men of Israel were in the valley of Elah, fighting with the Philistines. ^19

**20** David rose up early in the morning and left the sheep with a keeper, and took the provisions and went, as Jesse had commanded him. He came to the place of the wagons as the army which was going out to the fight shouted for the battle. ^20

**21** Israel and the Philistines put the battle in array, army against army. ^21

**22** David left his baggage in the hand of the keeper of the baggage and ran to the army, and came and greeted his brothers. ^22

**23** As he talked with them, behold, the champion, the Philistine of Gath, Goliath by name, came up out of the ranks of the Philistines, and said the same words; and David heard them. ^23

**24** All the men of Israel, when they saw the man, fled from him and were terrified. ^24

**25** The men of Israel said, “Have you seen this man who has come up? He has surely come up to defy Israel. The king will give great riches to the man who kills him, and will give him his daughter, and will make his father’s house tax-free in Israel.” ^25

**26** David spoke to the men who stood by him, saying, “What shall be done to the man who kills this Philistine and takes away the reproach from Israel? For who is this uncircumcised Philistine, that he should defy the armies of the living God?” ^26

**27** The people answered him in this way, saying, “So shall it be done to the man who kills him.” ^27

**28** Eliab his oldest brother heard when he spoke to the men; and Eliab’s anger burned against David, and he said, “Why have you come down? With whom have you left those few sheep in the wilderness? I know your pride and the evil of your heart; for you have come down that you might see the battle.” ^28

**29** David said, “What have I now done? Is there not a cause?” ^29

**30** He turned away from him toward another, and spoke like that again; and the people answered him again the same way. ^30

**31** When the words were heard which David spoke, they rehearsed them before Saul; and he sent for him. ^31

**32** David said to Saul, “Let no man’s heart fail because of him. Your servant will go and fight with this Philistine.” ^32

**33** Saul said to David, “You are not able to go against this Philistine to fight with him; for you are but a youth, and he a man of war from his youth.” ^33

**34** David said to Saul, “Your servant was keeping his father’s sheep; and when a lion or a bear came and took a lamb out of the flock, ^34

**35** I went out after him, struck him, and rescued it out of his mouth. When he arose against me, I caught him by his beard, struck him, and killed him. ^35

**36** Your servant struck both the lion and the bear. This uncircumcised Philistine shall be as one of them, since he has defied the armies of the living God.” ^36

**37** David said, “The LORD, who delivered me out of the paw of the lion and out of the paw of the bear, will deliver me out of the hand of this Philistine.” Saul said to David, “Go! The LORD will be with you.” ^37

**38** Saul dressed David with his clothing. He put a helmet of bronze on his head, and he clad him with a coat of mail. ^38

**39** David strapped his sword on his clothing and he tried to move, for he had not tested it. David said to Saul, “I can’t go with these, for I have not tested them.” Then David took them off. ^39

**40** He took his staff in his hand, and chose for himself five smooth stones out of the brook, and put them in the pouch of his shepherd’s bag which he had. His sling was in his hand; and he came near to the Philistine. ^40

**41** The Philistine walked and came near to David; and the man who bore the shield went before him. ^41

**42** When the Philistine looked around and saw David, he disdained him; for he was but a youth, and ruddy, and had a good looking face. ^42

**43** The Philistine said to David, “Am I a dog, that you come to me with sticks?” The Philistine cursed David by his gods. ^43

**44** The Philistine said to David, “Come to me, and I will give your flesh to the birds of the sky and to the animals of the field.” ^44

**45** Then David said to the Philistine, “You come to me with a sword, with a spear, and with a javelin; but I come to you in the name of the LORD of Armies, the God of the armies of Israel, whom you have defied. ^45

**46** Today, the LORD will deliver you into my hand. I will strike you and take your head from off you. I will give the dead bodies of the army of the Philistines today to the birds of the sky and to the wild animals of the earth, that all the earth may know that there is a God in Israel, ^46

**47** and that all this assembly may know that the LORD doesn’t save with sword and spear; for the battle is the LORD’s, and he will give you into our hand.” ^47

**48** When the Philistine arose, and walked and came near to meet David, David hurried and ran toward the army to meet the Philistine. ^48

**49** David put his hand in his bag, took a stone and slung it, and struck the Philistine in his forehead. The stone sank into his forehead, and he fell on his face to the earth. ^49

**50** So David prevailed over the Philistine with a sling and with a stone, and struck the Philistine and killed him; but there was no sword in David’s hand. ^50

**51** Then David ran, stood over the Philistine, took his sword, drew it out of its sheath, killed him, and cut off his head with it. When the Philistines saw that their champion was dead, they fled. ^51

**52** The men of Israel and of Judah arose and shouted, and pursued the Philistines as far as Gai and to the gates of Ekron. The wounded of the Philistines fell down by the way to Shaaraim, even to Gath and to Ekron. ^52

**53** The children of Israel returned from chasing after the Philistines, and they plundered their camp. ^53

**54** David took the head of the Philistine and brought it to Jerusalem, but he put his armor in his tent. ^54

**55** When Saul saw David go out against the Philistine, he said to Abner, the captain of the army, “Abner, whose son is this youth?” Abner said, “As your soul lives, O king, I can’t tell.” ^55

**56** The king said, “Inquire whose son the young man is!” ^56

**57** As David returned from the slaughter of the Philistine, Abner took him and brought him before Saul with the head of the Philistine in his hand. ^57

**58** Saul said to him, “Whose son are you, you young man?” David answered, “I am the son of your servant Jesse the Bethlehemite.” ^58

← [[1 Samuel 16 - WEBU]] | [[1 Samuel 18 - WEBU]] →
