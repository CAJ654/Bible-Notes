---
book: 1 Samuel
chapter: 1
version: WEBU
---
# 1 Samuel 1 (WEBU)

[[1 Samuel 2 - WEBU]] →

**1** Now there was a certain man of Ramathaim Zophim, of the hill country of Ephraim, and his name was Elkanah, the son of Jeroham, the son of Elihu, the son of Tohu, the son of Zuph, an Ephraimite. ^1

**2** He had two wives. The name of one was Hannah, and the name of the other Peninnah. Peninnah had children, but Hannah had no children. ^2

**3** This man went up out of his city from year to year to worship and to sacrifice to the LORD of Armies in Shiloh. The two sons of Eli, Hophni and Phinehas, priests to the LORD, were there. ^3

**4** When the day came that Elkanah sacrificed, he gave portions to Peninnah his wife and to all her sons and her daughters; ^4

**5** but he gave a double portion to Hannah, for he loved Hannah, but the LORD had shut up her womb. ^5

**6** Her rival provoked her severely, to irritate her, because the LORD had shut up her womb. ^6

**7** So year by year, when she went up to the LORD’s house, her rival provoked her. Therefore she wept, and didn’t eat. ^7

**8** Elkanah her husband said to her, “Hannah, why do you weep? Why don’t you eat? Why is your heart grieved? Am I not better to you than ten sons?” ^8

**9** So Hannah rose up after they had finished eating and drinking in Shiloh. Now Eli the priest was sitting on his seat by the doorpost of the LORD’s temple. ^9

**10** She was in bitterness of soul, and prayed to the LORD, weeping bitterly. ^10

**11** She vowed a vow, and said, “LORD of Armies, if you will indeed look at the affliction of your servant and remember me, and not forget your servant, but will give to your servant a boy, then I will give him to the LORD all the days of his life, and no razor shall come on his head.” ^11

**12** As she continued praying before the LORD, Eli saw her mouth. ^12

**13** Now Hannah spoke in her heart. Only her lips moved, but her voice was not heard. Therefore Eli thought she was drunk. ^13

**14** Eli said to her, “How long will you be drunk? Get rid of your wine!” ^14

**15** Hannah answered, “No, my lord, I am a woman of a sorrowful spirit. I have not been drinking wine or strong drink, but I poured out my soul before the LORD. ^15

**16** Don’t consider your servant a wicked woman; for I have been speaking out of the abundance of my complaint and my provocation.” ^16

**17** Then Eli answered, “Go in peace; and may the God of Israel grant your petition that you have asked of him.” ^17

**18** She said, “Let your servant find favor in your sight.” So the woman went her way and ate; and her facial expression wasn’t sad any more. ^18

**19** They rose up in the morning early and worshiped the LORD, then returned and came to their house to Ramah. Then Elkanah knew Hannah his wife; and the LORD remembered her. ^19

**20** When the time had come, Hannah conceived, and bore a son; and she named him Samuel, saying, “Because I have asked him of the LORD.” ^20

**21** The man Elkanah, and all his house, went up to offer to the LORD the yearly sacrifice and his vow. ^21

**22** But Hannah didn’t go up, for she said to her husband, “Not until the child is weaned; then I will bring him, that he may appear before the LORD, and stay there forever.” ^22

**23** Elkanah her husband said to her, “Do what seems good to you. Wait until you have weaned him; only may the LORD establish his word.” So the woman waited and nursed her son until she weaned him. ^23

**24** When she had weaned him, she took him up with her, with three bulls, and one ephah of meal, and a container of wine, and brought him to the LORD’s house in Shiloh. The child was young. ^24

**25** They killed the bull, and brought the child to Eli. ^25

**26** She said, “Oh, my lord, as your soul lives, my lord, I am the woman who stood by you here, praying to the LORD. ^26

**27** I prayed for this child, and the LORD has given me my petition which I asked of him. ^27

**28** Therefore I have also given him to the LORD. As long as he lives he is given to the LORD.” He worshiped the LORD there. ^28

[[1 Samuel 2 - WEBU]] →
