---
book: 1 Samuel
chapter: 21
version: WEBU
---
# 1 Samuel 21 (WEBU)

← [[1 Samuel 20 - WEBU]] | [[1 Samuel 22 - WEBU]] →

**1** Then David came to Nob to Ahimelech the priest. Ahimelech came to meet David trembling, and said to him, “Why are you alone, and no man with you?” ^1

**2** David said to Ahimelech the priest, “The king has commanded me to do something, and has said to me, ‘Let no one know anything about the business about which I send you, and what I have commanded you. I have sent the young men to a certain place.’ ^2

**3** Now therefore what is under your hand? Please give me five loaves of bread in my hand, or whatever is available.” ^3

**4** The priest answered David, and said, “I have no common bread, but there is holy bread; if only the young men have kept themselves from women.” ^4

**5** David answered the priest, and said to him, “Truly, women have been kept from us as usual these three days. When I came out, the vessels of the young men were holy, though it was only a common journey. How much more then today shall their vessels be holy?” ^5

**6** So the priest gave him holy bread; for there was no bread there but the show bread that was taken from before the LORD, to be replaced with hot bread in the day when it was taken away. ^6

**7** Now a certain man of the servants of Saul was there that day, detained before the LORD; and his name was Doeg the Edomite, the best of the herdsmen who belonged to Saul. ^7

**8** David said to Ahimelech, “Isn’t there here under your hand spear or sword? For I haven’t brought my sword or my weapons with me, because the king’s business required haste.” ^8

**9** The priest said, “Behold, the sword of Goliath the Philistine, whom you killed in the valley of Elah, is here wrapped in a cloth behind the ephod. If you would like to take that, take it, for there is no other except that here.” David said, “There is none like that. Give it to me.” ^9

**10** David arose and fled that day for fear of Saul, and went to Achish the king of Gath. ^10

**11** The servants of Achish said to him, “Isn’t this David the king of the land? Didn’t they sing to one another about him in dances, saying, ‘Saul has slain his thousands, and David his ten thousands’?” ^11

**12** David laid up these words in his heart, and was very afraid of Achish the king of Gath. ^12

**13** He changed his behavior before them and pretended to be insane in their hands, and scribbled on the doors of the gate, and let his spittle fall down on his beard. ^13

**14** Then Achish said to his servants, “Look, you see the man is insane. Why then have you brought him to me? ^14

**15** Do I lack madmen, that you have brought this fellow to play the madman in my presence? Should this fellow come into my house?” ^15

← [[1 Samuel 20 - WEBU]] | [[1 Samuel 22 - WEBU]] →
