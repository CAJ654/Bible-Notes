---
book: 1 Samuel
chapter: 20
version: WEBU
---
# 1 Samuel 20 (WEBU)

← [[1 Samuel 19 - WEBU]] | [[1 Samuel 21 - WEBU]] →

**1** David fled from Naioth in Ramah, and came and said to Jonathan, “What have I done? What is my iniquity? What is my sin before your father, that he seeks my life?” ^1

**2** He said to him, “Far from it; you will not die. Behold, my father does nothing either great or small, but that he discloses it to me. Why would my father hide this thing from me? It is not so.” ^2

**3** David swore moreover, and said, “Your father knows well that I have found favor in your eyes; and he says, ‘Don’t let Jonathan know this, lest he be grieved;’ but truly as the LORD lives, and as your soul lives, there is but a step between me and death.” ^3

**4** Then Jonathan said to David, “Whatever your soul desires, I will even do it for you.” ^4

**5** David said to Jonathan, “Behold, tomorrow is the new moon, and I should not fail to dine with the king; but let me go, that I may hide myself in the field to the third day at evening. ^5

**6** If your father misses me at all, then say, ‘David earnestly asked leave of me that he might run to Bethlehem, his city; for it is the yearly sacrifice there for all the family.’ ^6

**7** If he says, ‘It is well,’ your servant shall have peace; but if he is angry, then know that evil is determined by him. ^7

**8** Therefore deal kindly with your servant, for you have brought your servant into a covenant of the LORD with you; but if there is iniquity in me, kill me yourself, for why should you bring me to your father?” ^8

**9** Jonathan said, “Far be it from you; for if I should at all know that evil were determined by my father to come on you, then wouldn’t I tell you that?” ^9

**10** Then David said to Jonathan, “Who will tell me if your father answers you roughly?” ^10

**11** Jonathan said to David, “Come! Let’s go out into the field.” They both went out into the field. ^11

**12** Jonathan said to David, “By the LORD, the God of Israel, when I have sounded out my father about this time tomorrow, or the third day, behold, if there is good toward David, won’t I then send to you and disclose it to you? ^12

**13** The LORD do so to Jonathan and more also, should it please my father to do you evil, if I don’t disclose it to you and send you away, that you may go in peace. May the LORD be with you as he has been with my father. ^13

**14** You shall not only show me the loving kindness of the LORD while I still live, that I not die; ^14

**15** but you shall also not cut off your kindness from my house forever, no, not when the LORD has cut off every one of the enemies of David from the surface of the earth.” ^15

**16** So Jonathan made a covenant with David’s house, saying, “The LORD will require it at the hand of David’s enemies.” ^16

**17** Jonathan caused David to swear again, for the love that he had for him; for he loved him as he loved his own soul. ^17

**18** Then Jonathan said to him, “Tomorrow is the new moon, and you will be missed, because your seat will be empty. ^18

**19** When you have stayed three days, go down quickly and come to the place where you hid yourself when this started, and remain by the stone Ezel. ^19

**20** I will shoot three arrows on its side, as though I shot at a mark. ^20

**21** Behold, I will send the boy, saying, ‘Go, find the arrows!’ If I tell the boy, ‘Behold, the arrows are on this side of you. Take them;’ then come, for there is peace to you and no danger, as the LORD lives. ^21

**22** But if I say this to the boy, ‘Behold, the arrows are beyond you,’ then go your way, for the LORD has sent you away. ^22

**23** Concerning the matter which you and I have spoken of, behold, the LORD is between you and me forever.” ^23

**24** So David hid himself in the field. When the new moon had come, the king sat himself down to eat food. ^24

**25** The king sat on his seat, as at other times, even on the seat by the wall; and Jonathan stood up, and Abner sat by Saul’s side, but David’s place was empty. ^25

**26** Nevertheless Saul didn’t say anything that day, for he thought, “Something has happened to him. He is not clean. Surely he is not clean.” ^26

**27** On the next day after the new moon, the second day, David’s place was empty. Saul said to Jonathan his son, “Why didn’t the son of Jesse come to eat, either yesterday, or today?” ^27

**28** Jonathan answered Saul, “David earnestly asked permission of me to go to Bethlehem. ^28

**29** He said, ‘Please let me go, for our family has a sacrifice in the city. My brother has commanded me to be there. Now, if I have found favor in your eyes, please let me go away and see my brothers.’ Therefore he has not come to the king’s table.” ^29

**30** Then Saul’s anger burned against Jonathan, and he said to him, “You son of a perverse rebellious woman, don’t I know that you have chosen the son of Jesse to your own shame, and to the shame of your mother’s nakedness? ^30

**31** For as long as the son of Jesse lives on the earth, you will not be established, nor will your kingdom. Therefore now send and bring him to me, for he shall surely die!” ^31

**32** Jonathan answered Saul his father, and said to him, “Why should he be put to death? What has he done?” ^32

**33** Saul cast his spear at him to strike him. By this Jonathan knew that his father was determined to put David to death. ^33

**34** So Jonathan arose from the table in fierce anger, and ate no food the second day of the month; for he was grieved for David, because his father had treated him shamefully. ^34

**35** In the morning, Jonathan went out into the field at the time appointed with David, and a little boy with him. ^35

**36** He said to his boy, “Run, find now the arrows which I shoot.” As the boy ran, he shot an arrow beyond him. ^36

**37** When the boy had come to the place of the arrow which Jonathan had shot, Jonathan cried after the boy, and said, “Isn’t the arrow beyond you?” ^37

**38** Jonathan cried after the boy, “Go fast! Hurry! Don’t delay!” Jonathan’s boy gathered up the arrows, and came to his master. ^38

**39** But the boy didn’t know anything. Only Jonathan and David knew the matter. ^39

**40** Jonathan gave his weapons to his boy, and said to him, “Go, carry them to the city.” ^40

**41** As soon as the boy was gone, David arose out of the south, and fell on his face to the ground, and bowed himself three times. They kissed one another and wept with one another, and David wept the most. ^41

**42** Jonathan said to David, “Go in peace, because we have both sworn in the LORD’s name, saying, ‘The LORD is between me and you, and between my offspring and your offspring, forever.’” He arose and departed; and Jonathan went into the city. ^42

← [[1 Samuel 19 - WEBU]] | [[1 Samuel 21 - WEBU]] →
