---
book: 1 Samuel
chapter: 10
version: WEBU
---
# 1 Samuel 10 (WEBU)

← [[1 Samuel 9 - WEBU]] | [[1 Samuel 11 - WEBU]] →

**1** Then Samuel took the vial of oil and poured it on his head, then kissed him and said, “Hasn’t the LORD anointed you to be prince over his inheritance? ^1

**2** When you have departed from me today, then you will find two men by Rachel’s tomb, on the border of Benjamin at Zelzah. They will tell you, ‘The donkeys which you went to look for have been found; and behold, your father has stopped caring about the donkeys and is anxious for you, saying, “What shall I do for my son?”’ ^2

**3** “Then you will go on forward from there, and you will come to the oak of Tabor. Three men will meet you there going up to God to Bethel: one carrying three young goats, and another carrying three loaves of bread, and another carrying a container of wine. ^3

**4** They will greet you and give you two loaves of bread, which you shall receive from their hand. ^4

**5** “After that you will come to the hill of God, where the garrison of the Philistines is; and it will happen, when you have come there to the city, that you will meet a band of prophets coming down from the high place with a lute, a tambourine, a pipe, and a harp before them; and they will be prophesying. ^5

**6** Then the LORD’s Spirit will come mightily on you, then you will prophesy with them and will be turned into another man. ^6

**7** Let it be, when these signs have come to you, that you do what is appropriate for the occasion; for God is with you. ^7

**8** “Go down ahead of me to Gilgal; and behold, I will come down to you to offer burnt offerings and to sacrifice sacrifices of peace offerings. Wait seven days, until I come to you and show you what you are to do.” ^8

**9** It was so, that when he had turned his back to go from Samuel, God gave him another heart; and all those signs happened that day. ^9

**10** When they came there to the hill, behold, a band of prophets met him; and the Spirit of God came mightily on him, and he prophesied among them. ^10

**11** When all who knew him before saw that, behold, he prophesied with the prophets, then the people said to one another, “What is this that has come to the son of Kish? Is Saul also among the prophets?” ^11

**12** One from the same place answered, “Who is their father?” Therefore it became a proverb, “Is Saul also among the prophets?” ^12

**13** When he had finished prophesying, he came to the high place. ^13

**14** Saul’s uncle said to him and to his servant, “Where did you go?” He said, “To seek the donkeys. When we saw that they were not found, we came to Samuel.” ^14

**15** Saul’s uncle said, “Please tell me what Samuel said to you.” ^15

**16** Saul said to his uncle, “He told us plainly that the donkeys were found.” But concerning the matter of the kingdom, of which Samuel spoke, he didn’t tell him. ^16

**17** Samuel called the people together to the LORD to Mizpah; ^17

**18** and he said to the children of Israel, “The LORD, the God of Israel, says ‘I brought Israel up out of Egypt and I delivered you out of the hand of the Egyptians, and out of the hand of all the kingdoms that oppressed you.’ ^18

**19** But you have today rejected your God, who himself saves you out of all your calamities and your distresses; and you have said to him, ‘No! Set a king over us!’ Now therefore present yourselves before the LORD by your tribes and by your thousands.” ^19

**20** So Samuel brought all the tribes of Israel near, and the tribe of Benjamin was chosen. ^20

**21** He brought the tribe of Benjamin near by their families and the family of the Matrites was chosen. Then Saul the son of Kish was chosen; but when they looked for him, he could not be found. ^21

**22** Therefore they asked of the LORD further, “Is there yet a man to come here?” The LORD answered, “Behold, he has hidden himself among the baggage.” ^22

**23** They ran and got him there. When he stood among the people, he was higher than any of the people from his shoulders and upward. ^23

**24** Samuel said to all the people, “Do you see him whom the LORD has chosen, that there is no one like him among all the people?” All the people shouted and said, “Long live the king!” ^24

**25** Then Samuel told the people the regulations of the kingdom, and wrote it in a book and laid it up before the LORD. Samuel sent all the people away, every man to his house. ^25

**26** Saul also went to his house in Gibeah; and the army went with him, whose hearts God had touched. ^26

**27** But certain worthless fellows said, “How could this man save us?” They despised him, and brought him no tribute. But he held his peace. ^27

← [[1 Samuel 9 - WEBU]] | [[1 Samuel 11 - WEBU]] →
