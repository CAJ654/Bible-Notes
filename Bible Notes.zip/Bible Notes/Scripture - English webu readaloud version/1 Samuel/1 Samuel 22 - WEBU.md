---
book: 1 Samuel
chapter: 22
version: WEBU
---
# 1 Samuel 22 (WEBU)

← [[1 Samuel 21 - WEBU]] | [[1 Samuel 23 - WEBU]] →

**1** David therefore departed from there and escaped to Adullam’s cave. When his brothers and all his father’s house heard it, they went down there to him. ^1

**2** Everyone who was in distress, everyone who was in debt, and everyone who was discontented gathered themselves to him; and he became captain over them. There were with him about four hundred men. ^2

**3** David went from there to Mizpeh of Moab; and he said to the king of Moab, “Please let my father and my mother come out to you, until I know what God will do for me.” ^3

**4** He brought them before the king of Moab; and they lived with him all the time that David was in the stronghold. ^4

**5** The prophet Gad said to David, “Don’t stay in the stronghold. Depart, and go into the land of Judah.” Then David departed, and came into the forest of Hereth. ^5

**6** Saul heard that David was discovered, with the men who were with him. Now Saul was sitting in Gibeah, under the tamarisk tree in Ramah, with his spear in his hand, and all his servants were standing around him. ^6

**7** Saul said to his servants who stood around him, “Hear now, you Benjamites! Will the son of Jesse give everyone of you fields and vineyards? Will he make you all captains of thousands and captains of hundreds? ^7

**8** Is that why all of you have conspired against me, and there is no one who discloses to me when my son makes a treaty with the son of Jesse, and there is none of you who is sorry for me, or discloses to me that my son has stirred up my servant against me, to lie in wait, as it is today?” ^8

**9** Then Doeg the Edomite, who stood by the servants of Saul, answered and said, “I saw the son of Jesse coming to Nob, to Ahimelech the son of Ahitub. ^9

**10** He inquired of the LORD for him, gave him food, and gave him the sword of Goliath the Philistine.” ^10

**11** Then the king sent to call Ahimelech the priest, the son of Ahitub, and all his father’s house, the priests who were in Nob; and they all came to the king. ^11

**12** Saul said, “Hear now, you son of Ahitub.” He answered, “Here I am, my lord.” ^12

**13** Saul said to him, “Why have you conspired against me, you and the son of Jesse, in that you have given him bread, and a sword, and have inquired of God for him, that he should rise against me, to lie in wait, as it is today?” ^13

**14** Then Ahimelech answered the king, and said, “Who among all your servants is so faithful as David, who is the king’s son-in-law, captain of your body guard, and honored in your house? ^14

**15** Have I today begun to inquire of God for him? Be it far from me! Don’t let the king impute anything to his servant, nor to all the house of my father; for your servant knew nothing of all this, less or more.” ^15

**16** The king said, “You shall surely die, Ahimelech, you and all your father’s house.” ^16

**17** The king said to the guard who stood about him, “Turn and kill the priests of the LORD, because their hand also is with David, and because they knew that he fled and didn’t disclose it to me.” But the servants of the king wouldn’t put out their hand to fall on the priests of the LORD. ^17

**18** The king said to Doeg, “Turn and attack the priests!” Doeg the Edomite turned, and he attacked the priests, and he killed on that day eighty-five people who wore a linen ephod. ^18

**19** He struck Nob, the city of the priests, with the edge of the sword—both men and women, children and nursing babies, and cattle, donkeys, and sheep, with the edge of the sword. ^19

**20** One of the sons of Ahimelech the son of Ahitub, named Abiathar, escaped and fled after David. ^20

**21** Abiathar told David that Saul had slain the LORD’s priests. ^21

**22** David said to Abiathar, “I knew on that day, when Doeg the Edomite was there, that he would surely tell Saul. I am responsible for the death of all the persons of your father’s house. ^22

**23** Stay with me. Don’t be afraid, for he who seeks my life seeks your life. You will be safe with me.” ^23

← [[1 Samuel 21 - WEBU]] | [[1 Samuel 23 - WEBU]] →
