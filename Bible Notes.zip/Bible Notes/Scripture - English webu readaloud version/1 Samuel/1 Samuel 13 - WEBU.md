---
book: 1 Samuel
chapter: 13
version: WEBU
---
# 1 Samuel 13 (WEBU)

← [[1 Samuel 12 - WEBU]] | [[1 Samuel 14 - WEBU]] →

**1** Saul was thirty years old when he became king, and he reigned over Israel forty-two years. ^1

**2** Saul chose for himself three thousand men of Israel, of which two thousand were with Saul in Michmash and in the Mount of Bethel, and one thousand were with Jonathan in Gibeah of Benjamin. He sent the rest of the people to their own tents. ^2

**3** Jonathan struck the garrison of the Philistines that was in Geba, and the Philistines heard of it. Saul blew the trumpet throughout all the land, saying, “Let the Hebrews hear!” ^3

**4** All Israel heard that Saul had struck the garrison of the Philistines, and also that Israel was considered an abomination to the Philistines. The people were gathered together after Saul to Gilgal. ^4

**5** The Philistines assembled themselves together to fight with Israel: thirty thousand chariots, six thousand horsemen, and people as the sand which is on the seashore in multitude. They came up and encamped in Michmash, eastward of Beth Aven. ^5

**6** When the men of Israel saw that they were in trouble (for the people were distressed), then the people hid themselves in caves, in thickets, in rocks, in tombs, and in pits. ^6

**7** Now some of the Hebrews had gone over the Jordan to the land of Gad and Gilead; but as for Saul, he was yet in Gilgal, and all the people followed him trembling. ^7

**8** He stayed seven days, according to the time set by Samuel; but Samuel didn’t come to Gilgal, and the people were scattering from him. ^8

**9** Saul said, “Bring the burnt offering to me here, and the peace offerings.” He offered the burnt offering. ^9

**10** It came to pass that as soon as he had finished offering the burnt offering, behold, Samuel came; and Saul went out to meet him, that he might greet him. ^10

**11** Samuel said, “What have you done?” Saul said, “Because I saw that the people were scattered from me, and that you didn’t come within the days appointed, and that the Philistines assembled themselves together at Michmash, ^11

**12** therefore I said, ‘Now the Philistines will come down on me to Gilgal, and I haven’t entreated the favor of the LORD.’ I forced myself therefore, and offered the burnt offering.” ^12

**13** Samuel said to Saul, “You have done foolishly. You have not kept the commandment of the LORD your God, which he commanded you; for now the LORD would have established your kingdom on Israel forever. ^13

**14** But now your kingdom will not continue. The LORD has sought for himself a man after his own heart, and the LORD has appointed him to be prince over his people, because you have not kept that which the LORD commanded you.” ^14

**15** Samuel arose, and went from Gilgal to Gibeah of Benjamin. Saul counted the people who were present with him, about six hundred men. ^15

**16** Saul, and Jonathan his son, and the people who were present with them, stayed in Geba of Benjamin; but the Philistines encamped in Michmash. ^16

**17** The raiders came out of the camp of the Philistines in three companies: one company turned to the way that leads to Ophrah, to the land of Shual; ^17

**18** another company turned the way to Beth Horon; and another company turned the way of the border that looks down on the valley of Zeboim toward the wilderness. ^18

**19** Now there was no blacksmith found throughout all the land of Israel, for the Philistines said, “Lest the Hebrews make themselves swords or spears”; ^19

**20** but all the Israelites went down to the Philistines, each man to sharpen his own plowshare, mattock, ax, and sickle. ^20

**21** The price was one payim each to sharpen mattocks, plowshares, pitchforks, axes, and goads. ^21

**22** So it came to pass in the day of battle that neither sword nor spear was found in the hand of any of the people who were with Saul and Jonathan; but Saul and Jonathan his son had them. ^22

**23** The garrison of the Philistines went out to the pass of Michmash. ^23

← [[1 Samuel 12 - WEBU]] | [[1 Samuel 14 - WEBU]] →
