---
book: 2 Esdras
chapter: 10
version: WEBU
---
# 2 Esdras 10 (WEBU)

← [[2 Esdras 9 - WEBU]] | [[2 Esdras 11 - WEBU]] →

**1** “So it came to pass that when my son was entered into his wedding chamber, he fell down and died. ^1

**2** Then we all put out the lamps, and all my neighbors rose up to comfort me. I remained quiet until the second day at night. ^2

**3** It came to pass, when they had all stopped consoling me, encouraging me to be quiet, then rose I up by night, and fled, and came here into this field, as you see. ^3

**4** Now I don’t intend to return into the city, but to stay here, and not eat or drink, but to continually mourn and fast until I die.” ^4

**5** Then I left the reflections I was engaged in, and answered her in anger, ^5

**6** “You most foolish woman, don’t you see our mourning, and what has happened to us? ^6

**7** For Zion the mother of us all is full of sorrow, and much humbled. ^7

**8** It is right now to mourn deeply, since we all mourn, and to be sorrowful, since we are all in sorrow, but you are mourning for one son. ^8

**9** Ask the earth, and she will tell you that it is she which ought to mourn for so many that grow upon her. ^9

**10** For out of her, all had their beginnings, and others will come; and, behold, almost all of them walk into destruction, and the multitude of them is utterly doomed. ^10

**11** Who then should mourn more, she who has lost so great a multitude, or you, who are grieved but for one? ^11

**12** But if you say to me, ‘My lamentation is not like the earth’s, for I have lost the fruit of my womb, which I brought forth with pains, and bare with sorrows;’ ^12

**13** but it is with the earth after the manner of the earth. The multitude present in it has gone as it came. ^13

**14** Then say I to you, ‘Just as you have brought forth with sorrow, even so the earth also has given her fruit, namely, people, ever since the beginning to him who made her.’ ^14

**15** Now therefore keep your sorrow to yourself, and bear with a good courage the adversities which have happened to you. ^15

**16** For if you will acknowledge the decree of God to be just, you will both receive your son in time, and will be praised among women. ^16

**17** Go your way then into the city to your husband.” ^17

**18** She said to me, “I won’t do that. I will not go into the city, but I will die here.” ^18

**19** So I proceeded to speak further to her, and said, ^19

**20** “Don’t do so, but allow yourself to be persuaded by reason of the adversities of Zion; and be comforted by reason of the sorrow of Jerusalem. ^20

**21** For you see that our sanctuary has been laid waste, our altar broken down, our temple destroyed, ^21

**22** our lute has been brought low, our song is put to silence, our rejoicing is at an end, the light of our candlestick is put out, the ark of our covenant is plundered, our holy things are defiled, and the name that we are called is profaned. Our free men are despitefully treated, our priests are burned, our Levites have gone into captivity, our virgins are defiled and our wives ravished, our righteous men carried away, our little ones betrayed, our young men are brought into bondage, and our strong men have become weak. ^22

**23** What is more than all, the seal of Zion has now lost the seal of her honor, and is delivered into the hands of those who hate us. ^23

**24** Therefore shake off your great heaviness, and put away from yourself the multitude of sorrows, that the Mighty One may be merciful to you again, and the Most High may give you rest, even ease from your troubles.” ^24

**25** It came to pass while I was talking with her, behold, her face suddenly began to shine exceedingly, and her countenance flashed like lightning, so that I was very afraid of her, and wondered what this meant. ^25

**26** Behold, suddenly she made a great and very fearful cry, so that the earth shook at the noise. ^26

**27** I looked, and behold, the woman appeared to me no more, but there was a city built, and a place shown itself from large foundations. Then I was afraid, and cried with a loud voice, ^27

**28** “Where is Uriel the angel, who came to me at the first? For he has caused me to fall into this great trance, and my end has turned into corruption, and my prayer a reproach!” ^28

**29** As I was speaking these words, behold, the angel who had come to me at first came to me, and he looked at me. ^29

**30** Behold, I lay as one who had been dead, and my understanding was taken from me. He took me by the right hand, and comforted me, and set me on my feet, and said to me, ^30

**31** “What ails you? Why are you so troubled? Why is your understanding and the thoughts of your heart troubled?” ^31

**32** I said, “Because you have forsaken me; yet I did according to your words, and went into the field, and, behold, I have seen, and still see, that which I am not able to explain.” ^32

**33** He said to me, “Stand up like a man, and I will instruct you.” ^33

**34** Then I said, “Speak on, my Lord; only don’t forsake me, lest I die before my time. ^34

**35** For I have seen what I didn’t know, and hear what I don’t know. ^35

**36** Or is my sense deceived, or my soul in a dream? ^36

**37** Now therefore I beg you to explain to your servant what this vision means.” ^37

**38** He answered me, “Listen to me, and I will inform you, and tell you about the things you are afraid of, for the Most High has revealed many secret things to you. ^38

**39** He has seen that your way is righteous, because you are continually sorry for your people, and make great lamentation for Zion. ^39

**40** This therefore is the meaning of the vision. ^40

**41** The woman who appeared to you a little while ago, whom you saw mourning, and began to comfort her, ^41

**42** but now you no longer see the likeness of the woman, but a city under construction appeared to you, ^42

**43** and she told you of the death of her son, this is the interpretation: ^43

**44** This woman, whom you saw, is Zion, whom you now see as a city being built. ^44

**45** She told you that she had been barren for thirty years because there were three thousand years in the world in which there was no offering as yet offered in her. ^45

**46** And it came to pass after three thousand years that Solomon built the city and offered offerings. It was then that the barren bore a son. ^46

**47** She told you that she nourished him with great care. That was the dwelling in Jerusalem. ^47

**48** When she said to you, ‘My son died when he entered into his marriage chamber, and that misfortune befell her,’ this was the destruction that came to Jerusalem. ^48

**49** Behold, you saw her likeness, how she mourned for her son, and you began to comfort her for what has happened to her. These were the things to be opened to you. ^49

**50** For now the Most High, seeing that you are sincerely grieved and suffer from your whole heart for her, has shown you the brightness of her glory and the attractiveness of her beauty. ^50

**51** Therefore I asked you to remain in the field where no house was built, ^51

**52** for I knew that the Most High would show this to you. ^52

**53** Therefore I commanded you to come into the field, where no foundation of any building was. ^53

**54** For no human construction could stand in the place in which the city of the Most High was to be shown. ^54

**55** Therefore don’t be afraid nor let your heart be terrified, but go your way in and see the beauty and greatness of the building, as much as your eyes are able to see. ^55

**56** Then will you hear as much as your ears may comprehend. ^56

**57** For you are more blessed than many, and are called by name to be with the Most High, like only a few. ^57

**58** But tomorrow at night you shall remain here, ^58

**59** and so the Most High will show you those visions in dreams of what the Most High will do to those who live on the earth in the last days.” So I slept that night and another, as he commanded me. ^59

← [[2 Esdras 9 - WEBU]] | [[2 Esdras 11 - WEBU]] →
