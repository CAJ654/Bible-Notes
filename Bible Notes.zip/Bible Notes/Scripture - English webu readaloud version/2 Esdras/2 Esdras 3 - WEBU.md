---
book: 2 Esdras
chapter: 3
version: WEBU
---
# 2 Esdras 3 (WEBU)

← [[2 Esdras 2 - WEBU]] | [[2 Esdras 4 - WEBU]] →

**1** In the thirtieth year after the ruin of the city, I Salathiel, also called Esdras, was in Babylon, and lay troubled upon my bed, and my thoughts came up over my heart, ^1

**2** for I saw the desolation of Zion and the wealth of those who lived at Babylon. ^2

**3** My spirit was very agitated, so that I began to speak words full of fear to the Most High, and said, ^3

**4** “O sovereign Lord, didn’t you speak at the beginning when you formed the earth—and that yourself alone—and commanded the dust ^4

**5** and it gave you Adam, a body without a soul? Yet it was the workmanship of your hands, and you breathed into him the breath of life, and he was made alive in your presence. ^5

**6** You led him into the garden which your right hand planted before the earth appeared. ^6

**7** You gave him your one commandment, which he transgressed, and immediately you appointed death for him and his descendants. From him were born nations, tribes, peoples, and kindred without number. ^7

**8** Every nation walked after their own will, did ungodly things in your sight, and despised your commandments, and you didn’t hinder them. ^8

**9** Nevertheless, again in process of time, you brought the flood on those who lived in the world and destroyed them. ^9

**10** It came to pass that the same thing happened to them. Just as death came to Adam, so was the flood to these. ^10

**11** Nevertheless, you left one of them, Noah with his household, and all the righteous men who descended from him. ^11

**12** “It came to pass that when those who lived upon the earth began to multiply, they also multiplied children, peoples, and many nations, and began again to be more ungodly than their ancestors. ^12

**13** It came to pass, when they did wickedly before you, you chose one from among them, whose name was Abraham. ^13

**14** You loved, and to him only you showed the end of the times secretly by night, ^14

**15** and made an everlasting covenant with him, promising him that you would never forsake his descendants. To him, you gave Isaac, and to Isaac you gave Jacob and Esau. ^15

**16** You set apart Jacob for yourself, but rejected Esau. Jacob became a great multitude. ^16

**17** It came to pass that when you led his descendants out of Egypt, you brought them up to Mount Sinai. ^17

**18** You bowed the heavens also, shook the earth, moved the whole world, made the depths tremble, and troubled the age. ^18

**19** Your glory went through four gates, of fire, of earthquake, of wind, and of ice, that you might give the law to the descendants of Jacob, and the commandment to the descendants of Israel. ^19

**20** “Yet you didn’t take away from them their wicked heart, that your law might produce fruit in them. ^20

**21** For the first Adam, burdened with a wicked heart transgressed and was overcome, as were all who are descended from him. ^21

**22** Thus disease was made permanent. The law was in the heart of the people along with the wickedness of the root. So the good departed away and that which was wicked remained. ^22

**23** So the times passed away, and the years were brought to an end. Then you raised up a servant, called David, ^23

**24** whom you commanded to build a city to your name, and to offer burnt offerings to you in it from what is yours. ^24

**25** When this was done many years, then those who inhabited the city did evil, ^25

**26** in all things doing as Adam and all his generations had done, for they also had a wicked heart. ^26

**27** So you gave your city over into the hands of your enemies. ^27

**28** “Then I said in my heart, ‘Are their deeds of those who inhabit Babylon any better? Is that why it gained dominion over Zion?’ ^28

**29** For it came to pass when I came here, that I also saw impieties without number, and my soul saw many sinners in this thirtieth year, so that my heart failed me. ^29

**30** For I have seen how you endure them sinning, and have spared those who act ungodly, and have destroyed your people, and have preserved your enemies; ^30

**31** and you have not shown how your way may be comprehended. Are the deeds of Babylon better than those of Zion? ^31

**32** Or is there any other nation that knows you beside Israel? Or what tribes have so believed your covenants as these tribes of Jacob? ^32

**33** Yet their reward doesn’t appear, and their labor has no fruit, for I have gone here and there through the nations, and I see that they abound in wealth, and don’t think about your commandments. ^33

**34** Weigh therefore our iniquities now in the balance, and theirs also who dwell in the world, and so will it be found which way the scale inclines. ^34

**35** Or when was it that they who dwell on the earth have not sinned in your sight? Or what nation has kept your commandments so well? ^35

**36** You will find some men by name who have kept your precepts, but you won’t find nations.” ^36

← [[2 Esdras 2 - WEBU]] | [[2 Esdras 4 - WEBU]] →
