---
book: 2 Esdras
chapter: 11
version: WEBU
---
# 2 Esdras 11 (WEBU)

← [[2 Esdras 10 - WEBU]] | [[2 Esdras 12 - WEBU]] →

**1** It came to pass the second night that I saw a dream, and behold, an eagle which had twelve feathered wings and three heads came up from the sea. ^1

**2** I saw, and behold, she spread her wings over all the earth, and all the winds of heaven blew on her, and the clouds were gathered together against her. ^2

**3** I saw, and out of her wings there grew other wings near them; and they became little, tiny wings. ^3

**4** But her heads were at rest. The head in the middle was larger than the other heads, yet rested it with them. ^4

**5** Moreover I saw, and behold, the eagle flew with her wings to reign over the earth and over those who dwell therein. ^5

**6** I saw how all things under heaven were subject to her, and no one spoke against her—no, not one creature on earth. ^6

**7** I saw, and behold, the eagle rose on her talons, and uttered her voice to her wings, saying, ^7

**8** “Don’t all watch at the same time. Let each one sleep in his own place and watch in turn; ^8

**9** but let the heads be preserved for the last.” ^9

**10** I saw, and behold, the voice didn’t come out of her heads, but from the midst of her body. ^10

**11** I counted her wings that were near the others, and behold, there were eight of them. ^11

**12** I saw, and behold, on the right side one wing arose and reigned over all the earth. ^12

**13** When it reigned, the end of it came, and it disappeared, so that its place appeared no more. The next wing rose up and reigned, and it ruled a long time. ^13

**14** It happened that when it reigned, its end came also, so that it disappeared, like the first. ^14

**15** Behold, a voice came to it, and said, ^15

**16** “Listen, you who have ruled over the earth all this time! I proclaim this to you, before you disappear, ^16

**17** none after you will rule as long as you, not even half as long.” ^17

**18** Then the third arose, and ruled as the others before, and it also disappeared. ^18

**19** So it went with all the wings one after another, as every one ruled, and then disappeared. ^19

**20** I saw, and behold, in process of time the wings that followed were set up on the right side, that they might rule also. Some of them ruled, but in a while they disappeared. ^20

**21** Some of them also were set up, but didn’t rule. ^21

**22** After this I saw, and behold, the twelve wings disappeared, along with two of the little wings. ^22

**23** There was no more left on the eagle’s body, except the three heads that rested, and six little wings. ^23

**24** I saw, and behold, two little wings divided themselves from the six and remained under the head that was on the right side; but four remained in their place. ^24

**25** I saw, and behold, these under wings planned to set themselves up and to rule. ^25

**26** I saw, and behold, there was one set up, but in a while it disappeared. ^26

**27** A second also did so, and it disappeared faster than the first. ^27

**28** I saw, and behold, the two that remained also planned between themselves to reign. ^28

**29** While they thought about it, behold, one of the heads at rest awakened, the one that was in the middle, for that was greater than the two other heads. ^29

**30** I saw how it joined the two other heads with it. ^30

**31** Behold, the head turned with those who were with it, and ate the two under wings that planned to reign. ^31

**32** But this head held the whole earth in possession, and ruled over those who dwell in it with much oppression. It had stronger governance over the world than all the wings that had gone before. ^32

**33** After this I saw, and behold, the head also that was in the middle suddenly disappeared, like the wings. ^33

**34** But the two heads remained, which also reigned the same way over the earth and over those who dwell in it. ^34

**35** I saw, and behold, the head on the right side devoured the one that was on the left side. ^35

**36** Then I heard a voice, which said to me, “Look in front of you, and consider the thing that you see.” ^36

**37** I saw, and behold, something like a lion roused out of the woods roaring. I heard how he sent out a man’s voice to the eagle, and spoke, saying, ^37

**38** “Listen and I will talk with you. The Most High will say to you, ^38

**39** ‘Aren’t you the one that remains of the four animals whom I made to reign in my world, that the end of my times might come through them? ^39

**40** The fourth came and overcame all the animals that were past, and ruled the world with great trembling, and the whole extent of the earth with grievous oppression. He lived on the earth such a long time with deceit. ^40

**41** You have judged the earth, but not with truth. ^41

**42** For you have afflicted the meek, you have hurt the peaceful, you have hated those who speak truth, you have loved liars, destroyed the dwellings of those who produced fruit, and threw down the walls of those who did you no harm. ^42

**43** Your insolence has come up to the Most High, and your pride to the Mighty. ^43

**44** The Most High also has looked at his times, and behold, they are ended, and his ages are fulfilled. ^44

**45** Therefore appear no more, you eagle, nor your horrible wings, nor your evil little wings, nor your cruel heads, nor your hurtful talons, nor all your worthless body, ^45

**46** that all the earth may be refreshed and relieved, being delivered from your violence, and that she may hope for the judgment and mercy of him who made her.’” ^46

← [[2 Esdras 10 - WEBU]] | [[2 Esdras 12 - WEBU]] →
