---
book: 2 Esdras
chapter: 6
version: WEBU
---
# 2 Esdras 6 (WEBU)

← [[2 Esdras 5 - WEBU]] | [[2 Esdras 7 - WEBU]] →

**1** He said to me, “In the beginning, when the earth was made, before the portals of the world were fixed and before the gatherings of the winds blew, ^1

**2** before the voices of the thunder sounded and before the flashes of the lightning shone, before the foundations of paradise were laid, ^2

**3** before the fair flowers were seen, before the powers of the earthquake were established, before the innumerable army of angels were gathered together, ^3

**4** before the heights of the air were lifted up, before the measures of the firmament were named, before the footstool of Zion was established, ^4

**5** before the present years were reckoned, before the imaginations of those who now sin were estranged, and before they were sealed who have gathered faith for a treasure— ^5

**6** then I considered these things, and they all were made through me alone, and not through another; just as by me also they will be ended, and not by another.” ^6

**7** Then I answered, “What will be the dividing of the times? Or when will be the end of the first and the beginning of the age that follows?” ^7

**8** He said to me, “From Abraham to Isaac, because Jacob and Esau were born to him, for Jacob’s hand held Esau’s heel from the beginning. ^8

**9** For Esau is the end of this age, and Jacob is the beginning of the one that follows. ^9

**10** The beginning of a man is his hand, and the end of a man is his heel. Seek nothing else between the heel and the hand, Esdras!” ^10

**11** Then I answered, “O sovereign Lord, if I have found favor in your sight, ^11

**12** I beg you, show your servant the end of your signs which you showed me part on a previous night.” ^12

**13** So he answered, “Stand up upon your feet, and you will hear a mighty sounding voice. ^13

**14** If the place you stand on is greatly moved ^14

**15** when it speaks don’t be afraid, for the word is of the end, and the foundations of the earth will understand ^15

**16** that the speech is about them. They will tremble and be moved, for they know that their end must be changed.” ^16

**17** It happened that when I had heard it, I stood up on my feet, and listened, and, behold, there was a voice that spoke, and its sound was like the sound of many waters. ^17

**18** It said, “Behold, the days come when I draw near to visit those who dwell upon the earth, ^18

**19** and when I investigate those who have caused harm unjustly with their unrighteousness, and when the affliction of Zion is complete, ^19

**20** and when the seal will be set on the age that is to pass away, then I will show these signs: the books will be opened before the firmament, and all will see together. ^20

**21** The children a year old will speak with their voices. The women with child will deliver premature children at three or four months, and they will live and dance. ^21

**22** Suddenly the sown places will appear unsown. The full storehouses will suddenly be found empty. ^22

**23** The trumpet will give a sound which when every man hears, they will suddenly be afraid. ^23

**24** At that time friends will make war against one another like enemies. The earth will stand in fear with those who dwell in it. The springs of the fountains will stand still, so that for three hours they won’t flow. ^24

**25** “It will be that whoever remains after all these things that I have told you of, he will be saved and will see my salvation, and the end of my world. ^25

**26** They will see the men who have been taken up, who have not tasted death from their birth. The heart of the inhabitants will be changed and turned into a different spirit. ^26

**27** For evil will be blotted out and deceit will be quenched. ^27

**28** Faith will flourish. Corruption will be overcome, and the truth, which has been so long without fruit, will be declared.” ^28

**29** When he talked with me, behold, little by little, the place I stood on rocked back and forth. ^29

**30** He said to me, “I came to show you these things tonight. ^30

**31** If therefore you will pray yet again, and fast seven more days, I will again tell you greater things than these. ^31

**32** For your voice has surely been heard before the Most High. For the Mighty has seen your righteousness. He has also seen your purity, which you have maintained ever since your youth. ^32

**33** Therefore he has sent me to show you all these things, and to say to you, ‘Believe, and don’t be afraid! ^33

**34** Don’t be hasty to think vain things about the former times, that you may not hasten in the latter times.’” ^34

**35** It came to pass after this, that I wept again, and fasted seven days in like manner, that I might fulfill the three weeks which he told me. ^35

**36** On the eighth night, my heart was troubled within me again, and I began to speak in the presence of the Most High. ^36

**37** For my spirit was greatly aroused, and my soul was in distress. ^37

**38** I said, “O Lord, truly you spoke at the beginning of the creation, on the first day, and said this: ‘Let heaven and earth be made,’ and your word perfected the work. ^38

**39** Then the spirit was hovering, and darkness and silence were on every side. The sound of man’s voice was not yet there. ^39

**40** Then you commanded a ray of light to be brought out of your treasuries, that your works might then appear. ^40

**41** “On the second day, again you made the spirit of the firmament and commanded it to divide and to separate the waters, that the one part might go up, and the other remain beneath. ^41

**42** “On the third day, you commanded that the waters should be gathered together in the seventh part of the earth. You dried up six parts and kept them, to the intent that of these some being both planted and tilled might serve before you. ^42

**43** For as soon as your word went out, the work was done. ^43

**44** Immediately, great and innumerable fruit grew, with many pleasant tastes, and flowers of inimitable color, and fragrances of most exquisite smell. This was done the third day. ^44

**45** “On the fourth day, you commanded that the sun should shine, the moon give its light, and the stars should be in their order; ^45

**46** and gave them a command to serve mankind, who was to be made. ^46

**47** “On the fifth day, you said to the seventh part, where the water was gathered together, that it should produce living creatures, fowls and fishes; and so it came to pass ^47

**48** that the mute and lifeless water produced living things as it was told, that the nations might therefore praise your wondrous works. ^48

**49** “Then you preserved two living creatures. The one you called Behemoth, and the other you called Leviathan. ^49

**50** You separated the one from the other; for the seventh part, namely, where the water was gathered together, might not hold them both. ^50

**51** To Behemoth, you gave one part, which was dried up on the third day, that he should dwell in it, in which are a thousand hills; ^51

**52** but to Leviathan you gave the seventh part, namely, the watery part. You have kept them to be devoured by whom you wish, when you wish. ^52

**53** “But on the sixth day, you commanded the earth to produce before you cattle, animals, and creeping things. ^53

**54** Over these, you ordained Adam as ruler over all the works that you have made. Of him came all of us, the people whom you have chosen. ^54

**55** “All this have I spoken before you, O Lord, because you have said that for our sakes you made this world. ^55

**56** As for the other nations, which also come from Adam, you have said that they are nothing, and are like spittle. You have likened the abundance of them to a drop that falls from a bucket. ^56

**57** Now, O Lord, behold these nations, which are reputed as nothing, being rulers over us and devouring us. ^57

**58** But we your people, whom you have called your firstborn, your only children, and your fervent lover, are given into their hands. ^58

**59** Now if the world is made for our sakes, why don’t we possess our world for an inheritance? How long will this endure?” ^59

← [[2 Esdras 5 - WEBU]] | [[2 Esdras 7 - WEBU]] →
