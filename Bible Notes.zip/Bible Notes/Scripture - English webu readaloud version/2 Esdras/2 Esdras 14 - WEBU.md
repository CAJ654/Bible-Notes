---
book: 2 Esdras
chapter: 14
version: WEBU
---
# 2 Esdras 14 (WEBU)

← [[2 Esdras 13 - WEBU]] | [[2 Esdras 15 - WEBU]] →

**1** It came to pass upon the third day, I sat under an oak, and, behold, a voice came out of a bush near me, and said, “Esdras, Esdras!” ^1

**2** I said, “Here I am, Lord,” and I stood up on my feet. ^2

**3** Then he said to me, “I revealed myself in a bush and talked with Moses when my people were in bondage in Egypt. ^3

**4** I sent him, and he led my people out of Egypt. I brought him up to Mount Sinai, where I kept him with me for many days. ^4

**5** I told him many wondrous things, and showed him the secrets of the times and the end of the seasons. I commanded him, saying, ^5

**6** ‘You shall publish these openly, and these you shall hide.’ ^6

**7** Now I say to you: ^7

**8** Lay up in your heart the signs that I have shown, the dreams that you have seen, and the interpretations which you have heard; ^8

**9** for you will be taken away from men, and from now on you will live with my Son and with those who are like you, until the times have ended. ^9

**10** For the world has lost its youth, and the times begin to grow old. ^10

**11** For the age is divided into twelve parts, and ten parts of it are already gone, even the half of the tenth part. ^11

**12** There remain of it two parts after the middle of the tenth part. ^12

**13** Now therefore set your house in order, reprove your people, comfort the lowly among them, and instruct those of them who are wise, and now renounce the life that is corruptible, ^13

**14** and let go of the mortal thoughts, cast away from you the burdens of man, put off now your weak nature, ^14

**15** lay aside the thoughts that are most grievous to you, and hurry to escape from these times. ^15

**16** For worse evils than those which you have seen happen will be done after this. ^16

**17** For look how much the world will be weaker through age, so much that more evils will increase on those who dwell in it. ^17

**18** For the truth will withdraw itself further off, and falsehood will be near. For now the eagle which you saw in vision hurries to come.” ^18

**19** Then I answered and said, “Let me speak in your presence, O Lord. ^19

**20** Behold, I will go, as you have commanded me, and reprove the people who now live, but who will warn those who will be born afterward? For the world is set in darkness, and those who dwell in it are without light. ^20

**21** For your law has been burned, therefore no one knows the things that are done by you, or the works that will be done. ^21

**22** But if I have found favor before you, send the Holy Spirit to me, and I will write all that has been done in the world since the beginning, even the things that were written in your law, that men may be able to find the path, and that those who would live in the latter days may live.” ^22

**23** He answered me and said, “Go your way, gather the people together, and tell them not to seek you for forty days. ^23

**24** But prepare for yourself many tablets, and take with you Sarea, Dabria, Selemia, Ethanus, and Asiel, these five, which are ready to write swiftly; ^24

**25** and come here, and I will light a lamp of understanding in your heart which will not be put out until the things have ended about which you will write. ^25

**26** When you are done, some things you shall publish openly, and some things you shall deliver in secret to the wise. Tomorrow at this hour you will begin to write.” ^26

**27** Then I went out, as he commanded me, and gathered all the people together, and said, ^27

**28** “Hear these words, O Israel! ^28

**29** Our fathers at the beginning were foreigners in Egypt, and they were delivered from there, ^29

**30** and received the law of life, which they didn’t keep, which you also have transgressed after them. ^30

**31** Then the land of Zion was given to you for a possession; but you yourselves and your ancestors have done unrighteousness, and have not kept the ways which the Most High commanded you. ^31

**32** Because he is a righteous judge, in due time, he took from you what he had given you. ^32

**33** Now you are here, and your kindred are among you. ^33

**34** Therefore if you will rule over your own understanding and instruct your hearts, you will be kept alive, and after death you will obtain mercy. ^34

**35** For after death the judgment will come, when we will live again. Then the names of the righteous will become manifest, and the works of the ungodly will be declared. ^35

**36** Let no one therefore come to me now, nor seek me for forty days.” ^36

**37** So I took the five men, as he commanded me, and we went out into the field, and remained there. ^37

**38** It came to pass on the next day that, behold, a voice called me, saying, “Esdras, open your mouth, and drink what I give you to drink.” ^38

**39** Then opened I my mouth, and behold, a full cup was handed to me. It was full of something like water, but its color was like fire. ^39

**40** I took it, and drank. When I had drunk it, my heart uttered understanding, and wisdom grew in my chest, for my spirit retained its memory. ^40

**41** My mouth was opened, and shut no more. ^41

**42** The Most High gave understanding to the five men, and they wrote by course the things that were told them, in characters which they didn’t know, and they sat forty days. Now they wrote in the day-time, and at night they ate bread. ^42

**43** As for me, I spoke in the day, and by night I didn’t hold my tongue. ^43

**44** So in forty days, ninety-four books were written. ^44

**45** It came to pass, when the forty days were fulfilled, that the Most High spoke to me, saying, “The first books that you have written, publish openly, and let the worthy and unworthy read them; ^45

**46** but keep the last seventy, that you may deliver them to those who are wise among your people; ^46

**47** for in them is the spring of understanding, the fountain of wisdom, and the stream of knowledge.” ^47

**48** I did so. ^48

← [[2 Esdras 13 - WEBU]] | [[2 Esdras 15 - WEBU]] →
