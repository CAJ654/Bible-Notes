---
book: 2 Esdras
chapter: 7
version: WEBU
---
# 2 Esdras 7 (WEBU)

← [[2 Esdras 6 - WEBU]] | [[2 Esdras 8 - WEBU]] →

**1** When I had finished speaking these words, the angel which had been sent to me the nights before was sent to me. ^1

**2** He said to me, “Rise, Esdras, and hear the words that I have come to tell you.” ^2

**3** I said, “Speak on, my Lord.” Then he said to me, “There is a sea set in a wide place, that it might be broad and vast, ^3

**4** but its entrance is set in a narrow place so as to be like a river. ^4

**5** Whoever desires to go into the sea to look at it, or to rule it, if he didn’t go through the narrow entrance, how could he come into the broad part? ^5

**6** Another thing also: There is a city built and set in a plain country, and full of all good things, ^6

**7** but its entrance is narrow, and is set in a dangerous place to fall, having fire on the right hand, and deep water on the left. ^7

**8** There is only one path between them both, even between the fire and the water, so that only one person can go there at once. ^8

**9** If this city is now given to a man for an inheritance, if the heir doesn’t pass the danger before him, how will he receive his inheritance?” ^9

**10** I said, “That is so, Lord.” Then said he to me, “Even so also is Israel’s portion. ^10

**11** I made the world for their sakes. What is now done was decreed when Adam transgressed my statutes. ^11

**12** Then the entrances of this world were made narrow, sorrowful, and toilsome. They are but few and evil, full of perils, and involved in great toils. ^12

**13** For the entrances of the greater world are wide and safe, and produce fruit of immortality. ^13

**14** So if those who live don’t enter these difficult and vain things, they can never receive those that are reserved for them. ^14

**15** Now therefore why are you disturbed, seeing you are but a corruptible man? Why are you moved, since you are mortal? ^15

**16** Why haven’t you considered in your mind that which is to come, rather than that which is present?” ^16

**17** Then I answered and said, “O sovereign Lord, behold, you have ordained in your law that the righteous will inherit these things, but that the ungodly will perish. ^17

**18** The righteous therefore will suffer difficult things, and hope for easier things, but those who have done wickedly have suffered the difficult things, and yet will not see the easier things.” ^18

**19** He said to me, “You are not a judge above God, neither do you have more understanding than the Most High. ^19

**20** Yes, let many perish who now live, rather than that the law of God which is set before them be despised. ^20

**21** For God strictly commanded those who came, even as they came, what they should do to live, and what they should observe to avoid punishment. ^21

**22** Nevertheless, they weren’t obedient to him, but spoke against him and imagined for themselves vain things. ^22

**23** They made cunning plans of wickedness, and said moreover of the Most High that he doesn’t exist, and they didn’t know his ways. ^23

**24** They despised his law and denied his covenants. They haven’t been faithful to his statutes, and haven’t performed his works. ^24

**25** Therefore, Esdras, for the empty are empty things, and for the full are the full things. ^25

**26** For behold, the time will come, and it will be, when these signs of which I told you before will come to pass, that the bride will appear, even the city coming forth, and she will be seen who now is withdrawn from the earth. ^26

**27** Whoever is delivered from the foretold evils will see my wonders. ^27

**28** For my son Jesus will be revealed with those who are with him, and those who remain will rejoice four hundred years. ^28

**29** After these years my son Christ will die, along with all of those who have the breath of life. ^29

**30** Then the world will be turned into the old silence seven days, like as in the first beginning, so that no human will remain. ^30

**31** After seven days the world that is not yet awake will be raised up, and what is corruptible will die. ^31

**32** The earth will restore those who are asleep in it, and the dust those who dwell in it in silence, and the secret places will deliver those souls that were committed to them. ^32

**33** The Most High will be revealed on the judgment seat, and compassion will pass away, and patience will be withdrawn. ^33

**34** Only judgment will remain. Truth will stand. Faith will grow strong. ^34

**35** Recompense will follow. The reward will be shown. Good deeds will awake, and wicked deeds won’t sleep. ^35

**36** The pit of torment will appear, and near it will be the place of rest. The furnace of hellwill be shown, and near it the paradise of delight. ^36

**37** Then the Most High will say to the nations that are raised from the dead, ‘Look and understand whom you have denied, whom you haven’t served, whose commandments you have despised. ^37

**38** Look on this side and on that. Here is delight and rest, and there fire and torments.’ Thus he will speak to them in the day of judgment. ^38

**39** This is a day that has neither sun, nor moon, nor stars, ^39

**40** neither cloud, nor thunder, nor lightning, neither wind, nor water, nor air, neither darkness, nor evening, nor morning, ^40

**41** neither summer, nor spring, nor heat, nor winter, neither frost, nor cold, nor hail, nor rain, nor dew, ^41

**42** neither noon, nor night, nor dawn, neither shining, nor brightness, nor light, except only the splendor of the glory of the Most High, by which all will see the things that are set before them. ^42

**43** It will endure as though it were a week of years. ^43

**44** This is my judgment and its prescribed order; but I have only shown these things to you.” ^44

**45** I answered, “I said then, O Lord, and I say now: Blessed are those who are now alive and keep your commandments! ^45

**46** But what about those for whom I prayed? For who is there of those who are alive who has not sinned, and who of the children of men hasn’t transgressed your covenant? ^46

**47** Now I see that the world to come will bring delight to few, but torments to many. ^47

**48** For an evil heart has grown up in us, which has led us astray from these commandments and has brought us into corruption and into the ways of death. It has shown us the paths of perdition and removed us far from life—and that, not a few only, but nearly all who have been created.” ^48

**49** He answered me, “Listen to me, and I will instruct you. I will admonish you yet again. ^49

**50** For this reason, the Most High has not made one world, but two. ^50

**51** For because you have said that the just are not many, but few, and the ungodly abound, hear the explanation. ^51

**52** If you have just a few precious stones, will you add them to lead and clay?” ^52

**53** I said, “Lord, how could that be?” ^53

**54** He said to me, “Not only that, but ask the earth, and she will tell you. Defer to her, and she will declare it to you. ^54

**55** Say to her, ‘You produce gold, silver, and brass, and also iron, lead, and clay; ^55

**56** but silver is more abundant than gold, and brass than silver, and iron than brass, and lead than iron, and clay than lead.’ ^56

**57** Judge therefore which things are precious and to be desired, what is abundant or what is rare?” ^57

**58** I said, “O sovereign Lord, that which is plentiful is of less worth, for that which is more rare is more precious.” ^58

**59** He answered me, “Weigh within yourself the things that you have thought, for he who has what is hard to get rejoices over him who has what is plentiful. ^59

**60** So also is the judgment which I have promised; for I will rejoice over the few that will be saved, because these are those who have made my glory to prevail now, and through them, my name is now honored. ^60

**61** I won’t grieve over the multitude of those who perish; for these are those who are now like mist, and have become like flame and smoke; they are set on fire and burn hotly, and are extinguished.” ^61

**62** I answered, “O earth, why have you produced, if the mind is made out of dust, like all other created things? ^62

**63** For it would have been better that the dust itself had been unborn, so that the mind might not have been made from it. ^63

**64** But now the mind grows with us, and because of this we are tormented, because we perish and we know it. ^64

**65** Let the race of men lament and the animals of the field be glad. Let all who are born lament, but let the four-footed animals and the livestock rejoice. ^65

**66** For it is far better with them than with us; for they don’t look forward to judgment, neither do they know of torments or of salvation promised to them after death. ^66

**67** For what does it profit us, that we will be preserved alive, but yet be afflicted with torment? ^67

**68** For all who are born are defiled with iniquities, and are full of sins and laden with transgressions. ^68

**69** If after death we were not to come into judgment, perhaps it would have been better for us.” ^69

**70** He answered me, “When the Most High made the world and Adam and all those who came from him, he first prepared the judgment and the things that pertain to the judgment. ^70

**71** Now understand from your own words, for you have said that the mind grows with us. ^71

**72** They therefore who dwell on the earth will be tormented for this reason, that having understanding they have committed iniquity, and receiving commandments have not kept them, and having obtained a law they dealt unfaithfully with that which they received. ^72

**73** What then will they have to say in the judgment, or how will they answer in the last times? ^73

**74** For how long a time has the Most High been patient with those who inhabit the world, and not for their sakes, but because of the times which he has foreordained!” ^74

**75** I answered, “If I have found grace in your sight, O Lord, show this also to your servant, whether after death, even now when every one of us gives up his soul, we will be kept in rest until those times come, in which you renew the creation, or whether we will be tormented immediately.” ^75

**76** He answered me, “I will show you this also; but don’t join yourself with those who are scorners, nor count yourself with those who are tormented. ^76

**77** For you have a treasure of works laid up with the Most High, but it won’t be shown you until the last times. ^77

**78** For concerning death the teaching is: When the decisive sentence has gone out from the Most High that a man shall die, as the spirit leaves the body to return again to him who gave it, it adores the glory of the Most High first of all. ^78

**79** And if it is one of those who have been scorners and have not kept the way of the Most High, and that have despised his law, and who hate those who fear God, ^79

**80** these spirits won’t enter into habitations, but will wander and be in torments immediately, ever grieving and sad, in seven ways. ^80

**81** The first way, because they have despised the law of the Most High. ^81

**82** The second way, because they can’t now make a good repentance that they may live. ^82

**83** The third way, they will see the reward laid up for those who have believed the covenants of the Most High. ^83

**84** The fourth way, they will consider the torment laid up for themselves in the last days. ^84

**85** The fifth way, they will see the dwelling places of the others guarded by angels, with great quietness. ^85

**86** The sixth way, they will see how immediately some of them will pass into torment. ^86

**87** The seventh way, which is more grievous than all the aforesaid ways, because they will pine away in confusion and be consumed with shame, and will be withered up by fears, seeing the glory of the Most High before whom they have sinned while living, and before whom they will be judged in the last times. ^87

**88** “Now this is the order of those who have kept the ways of the Most High, when they will be separated from their mortal body. ^88

**89** In the time that they lived in it, they painfully served the Most High, and were in jeopardy every hour, that they might keep the law of the lawgiver perfectly. ^89

**90** Therefore this is the teaching concerning them: ^90

**91** First of all they will see with great joy the glory of him who takes them up, for they will have rest in seven orders. ^91

**92** The first order, because they have labored with great effort to overcome the evil thought which was fashioned together with them, that it might not lead them astray from life into death. ^92

**93** The second order, because they see the perplexity in which the souls of the ungodly wander, and the punishment that awaits them. ^93

**94** The third order, they see the testimony which he who fashioned them gives concerning them, that while they lived they kept the law which was given them in trust. ^94

**95** The fourth order, they understand the rest which, being gathered in their chambers, they now enjoy with great quietness, guarded by angels, and the glory that awaits them in the last days. ^95

**96** The fifth order, they rejoice that they have now escaped from that which is corruptible, and that they will inherit that which is to come, while they see in addition the difficulty and the pain from which they have been delivered, and the spacious liberty which they will receive with joy and immortality. ^96

**97** The sixth order, when it is shown to them how their face will shine like the sun, and how they will be made like the light of the stars, being incorruptible from then on. ^97

**98** The seventh order, which is greater than all the previously mentioned orders, because they will rejoice with confidence, and because they will be bold without confusion, and will be glad without fear, for they hurry to see the face of him whom in their lifetime they served, and from whom they will receive their reward in glory. ^98

**99** This is the order of the souls of the just, as from henceforth is announced to them. Previously mentioned are the ways of torture which those who would not give heed will suffer from after this.” ^99

**100** I answered, “Will time therefore be given to the souls after they are separated from the bodies, that they may see what you have described to me?” ^100

**101** He said, “Their freedom will be for seven days, that for seven days they may see the things you have been told, and afterwards they will be gathered together in their habitations.” ^101

**102** I answered, “If I have found favor in your sight, show further to me your servant whether in the day of judgment the just will be able to intercede for the ungodly or to entreat the Most High for them, ^102

**103** whether fathers for children, or children for parents, or kindred for kindred, or kinsfolk for their next of kin, or friends for those who are most dear.” ^103

**104** He answered me, “Since you have found favor in my sight, I will show you this also. The day of judgment is a day of decision, and displays to all the seal of truth. Even as now a father doesn’t send his son, or a son his father, or a master his slave, or a friend him that is most dear, that in his place he may understand, or sleep, or eat, or be healed, ^104

**105** so no one will ever pray for another in that day, neither will one lay a burden on another, for then everyone will each bear his own righteousness or unrighteousness.” ^105

**106** I answered, “How do we now find that first Abraham prayed for the people of Sodom, and Moses for the ancestors who sinned in the wilderness, ^106

**107** and Joshua after him for Israel in the days of Achan, ^107

**108** and Samuel in the days of Saul, and David for the plague, and Solomon for those who would worship in the sanctuary, ^108

**109** and Elijah for those that received rain, and for the dead, that he might live, ^109

**110** and Hezekiah for the people in the days of Sennacherib, and many others prayed for many? ^110

**111** If therefore now, when corruption has grown and unrighteousness increased, the righteous have prayed for the ungodly, why will it not be so then also?” ^111

**112** He answered me, “This present world is not the end. The full glory doesn’t remain in it. Therefore those who were able prayed for the weak. ^112

**113** But the day of judgment will be the end of this age, and the beginning of the immortality to come, in which corruption has passed away, ^113

**114** intemperance is at an end, infidelity is cut off, but righteousness has grown, and truth has sprung up. ^114

**115** Then no one will be able to have mercy on him who is condemned in judgment, nor to harm someone who is victorious.” ^115

**116** I answered then, “This is my first and last saying, that it would have been better if the earth had not produced Adam, or else, when it had produced him, to have restrained him from sinning. ^116

**117** For what profit is it for all who are in this present time to live in heaviness, and after death to look for punishment? ^117

**118** O Adam, what have you done? For though it was you who sinned, the evil hasn’t fallen on you alone, but on all of us who come from you. ^118

**119** For what profit is it to us, if an immortal time is promised to us, but we have done deeds that bring death? ^119

**120** And that there is promised us an everlasting hope, but we have most miserably failed? ^120

**121** And that there are reserved habitations of health and safety, but we have lived wickedly? ^121

**122** And that the glory of the Most High will defend those who have led a pure life, but we have walked in the most wicked ways of all? ^122

**123** And that a paradise will be revealed, whose fruit endures without decay, in which is abundance and healing, but we won’t enter into it, ^123

**124** for we have lived in perverse ways? ^124

**125** And that the faces of those who have practiced self-control will shine more than the stars, but our faces will be blacker than darkness? ^125

**126** For while we lived and committed iniquity, we didn’t consider what we would have to suffer after death.” ^126

**127** Then he answered, “This is the significance of the battle which humans born on the earth will fight: ^127

**128** if they are overcome, they will suffer as you have said, but if they get the victory, they will receive the thing that I say. ^128

**129** For this is the way that Moses spoke to the people while he lived, saying, ‘Choose life, that you may live!’ ^129

**130** Nevertheless they didn’t believe him or the prophets after him, not even me, who have spoken to them. ^130

**131** Therefore there won’t be such heaviness in their destruction, as there will be joy over those who are assured of salvation.” ^131

**132** Then I answered, “I know, Lord, that the Most High is now called merciful, in that he has mercy upon those who have not yet come into the world; ^132

**133** and compassionate, in that he has compassion upon those who turn to his law; ^133

**134** and patient, in that he is patient with those who have sinned, since they are his creatures; ^134

**135** and bountiful, in that he is ready to give rather than to take away; ^135

**136** and very merciful, in that he multiplies more and more mercies to those who are present, and who are past, and also to those who are to come— ^136

**137** for if he wasn’t merciful, the world wouldn’t continue with those who dwell in it— ^137

**138** and one who forgives, for if he didn’t forgive out of his goodness, that those who have committed iniquities might be relieved of them, not even one ten thousandth part of mankind would remain living; ^138

**139** and a judge, for if he didn’t pardon those who were created by his word, and blot out the multitude of sins, ^139

**140** there would perhaps be very few left of an innumerable multitude.” ^140

← [[2 Esdras 6 - WEBU]] | [[2 Esdras 8 - WEBU]] →
