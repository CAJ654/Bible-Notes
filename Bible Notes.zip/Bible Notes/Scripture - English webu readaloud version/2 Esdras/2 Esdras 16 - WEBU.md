---
book: 2 Esdras
chapter: 16
version: WEBU
---
# 2 Esdras 16 (WEBU)

← [[2 Esdras 15 - WEBU]]

**1** Woe to you, Babylon, and Asia! Woe to you, Egypt and Syria! ^1

**2** Put on sackcloth and garments of goats’ hair, wail for your children and lament; for your destruction is at hand. ^2

**3** A sword has been sent upon you, and who is there to turn it back? ^3

**4** A fire has been sent upon you, and who is there to quench it? ^4

**5** Calamities are sent upon you, and who is there to drive them away? ^5

**6** Can one drive away a hungry lion in the forest? Can one quench a fire in stubble, once it has begun to burn? ^6

**7** Can one turn back an arrow that is shot by a strong archer? ^7

**8** The Lord God sends the calamities, and who will drive them away? ^8

**9** A fire will go out from his wrath, and who may quench it? ^9

**10** He will flash lightning, and who will not fear? He will thunder, and who wouldn’t tremble? ^10

**11** The Lord will threaten, and who will not be utterly broken in pieces at his presence? ^11

**12** The earth and its foundations quake. The sea rises up with waves from the deep, and its waves will be troubled, along with the fish in them, at the presence of the Lord, and before the glory of his power. ^12

**13** For his right hand that bends the bow is strong, his arrows that he shoots are sharp, and will not miss when they begin to be shot into the ends of the world. ^13

**14** Behold, the calamities are sent out, and will not return again until they come upon the earth. ^14

**15** The fire is kindled and will not be put out until it consumes the foundations of the earth. ^15

**16** Just as an arrow which is shot by a mighty archer doesn’t return backward, even so the calamities that are sent out upon earth won’t return again. ^16

**17** Woe is me! Woe is me! Who will deliver me in those days? ^17

**18** The beginning of sorrows, when there will be great mourning; the beginning of famine, and many will perish; the beginning of wars, and the powers will stand in fear; the beginning of calamities, and all will tremble! What will they do when the calamities come? ^18

**19** Behold, famine and plague, suffering and anguish! They are sent as scourges for correction. ^19

**20** But for all these things they will not turn them from their wickedness, nor be always mindful of the scourges. ^20

**21** Behold, food will be so cheap on earth that they will think themselves to be in good condition, and even then calamities will grow on earth: sword, famine, and great confusion. ^21

**22** For many of those who dwell on earth will perish of famine; and others who escape the famine, the sword will destroy. ^22

**23** The dead will be cast out like dung, and there will be no one to comfort them; for the earth will be left desolate, and its cities will be cast down. ^23

**24** There will be no farmer left to cultivate the earth or to sow it. ^24

**25** The trees will give fruit, but who will gather it? ^25

**26** The grapes will ripen, but who will tread them? For in all places there will be a great solitude; ^26

**27** for one man will desire to see another, or to hear his voice. ^27

**28** For of a city there will be ten left, and two of the field, who have hidden themselves in the thick groves, and in the clefts of the rocks. ^28

**29** As in an orchard of olives upon every tree there may be left three or four olives, ^29

**30** or as when a vineyard is gathered, there are some clusters left by those who diligently search through the vineyard, ^30

**31** even so in those days, there will be three or four left by those who search their houses with the sword. ^31

**32** The earth will be left desolate, and its fields will be for briers, and its roads and all her paths will grow thorns, because no sheep will pass along them. ^32

**33** The virgins will mourn, having no bridegrooms. The women will mourn, having no husbands. Their daughters will mourn, having no helpers. ^33

**34** Their bridegrooms will be destroyed in the wars, and their husbands will perish of famine. ^34

**35** Hear now these things, and understand them, you servants of the Lord. ^35

**36** Behold, the Lord’s word: receive it. Don’t doubt the things about which the Lord speaks. ^36

**37** Behold, the calamities draw near, and are not delayed. ^37

**38** Just as a woman with child in the ninth month, when the hour of her delivery draws near, within two or three hours great pains surround her womb, and when the child comes out from the womb, there will be no waiting for a moment, ^38

**39** even so the calamities won’t delay coming upon the earth. The world will groan, and sorrows will seize it on every side. ^39

**40** “O my people, hear my word: prepare for battle, and in those calamities be like strangers on the earth. ^40

**41** He who sells, let him be as he who flees away, and he who buys, as one who will lose. ^41

**42** Let he who does business be as he who has no profit by it, and he who builds, as he who won’t dwell in it, ^42

**43** and he who sows, as if he wouldn’t reap, so also he who prunes the vines, as he who won’t gather the grapes, ^43

**44** those who marry, as those who will have no children, and those who don’t marry, as the widowed. ^44

**45** Because of this, those who labor, labor in vain; ^45

**46** for foreigners will reap their fruits, plunder their goods, overthrow their houses, and take their children captive, for in captivity and famine they will conceive their children. ^46

**47** Those who conduct business, do so only to be plundered. The more they adorn their cities, their houses, their possessions, and their own persons, ^47

**48** the more I will hate them for their sins,” says the Lord. ^48

**49** Just as a respectable and virtuous woman hates a prostitute, ^49

**50** so will righteousness hate iniquity when she adorns herself, and will accuse her to her face when he comes who will defend him who diligently searches out every sin on earth. ^50

**51** Therefore don’t be like her or her works. ^51

**52** For yet a little while, and iniquity will be taken away out of the earth, and righteousness will reign over us. ^52

**53** Don’t let the sinner say that he has not sinned; for God will burn coals of fire on the head of one who says “I haven’t sinned before God and his glory.” ^53

**54** Behold, the Lord knows all the works of men, their imaginations, their thoughts, and their hearts. ^54

**55** He said, “Let the earth be made,” and it was made, “Let the sky be made,” and it was made. ^55

**56** At his word, the stars were established, and he knows the number of the stars. ^56

**57** He searches the deep and its treasures. He has measured the sea and what it contains. ^57

**58** He has shut the sea in the midst of the waters, and with his word, he hung the earth over the waters. ^58

**59** He has spread out the sky like a vault. He has founded it over the waters. ^59

**60** He has made springs of water in the desert and pools on the tops of the mountains to send out rivers from the heights to water the earth. ^60

**61** He formed man, and put a heart in the midst of the body, and gave him breath, life, and understanding, ^61

**62** yes, the spirit of God Almighty. He who made all things and searches out hidden things in hidden places, ^62

**63** surely he knows your imagination, and what you think in your hearts. Woe to those who sin, and try to hide their sin! ^63

**64** Because the Lord will exactly investigate all your works, and he will put you all to shame. ^64

**65** When your sins are brought out before men, you will be ashamed, and your own iniquities will stand as your accusers in that day. ^65

**66** What will you do? Or how will you hide your sins before God and his angels? ^66

**67** Behold, God is the judge. Fear him! Stop sinning, and forget your iniquities, to never again commit them. So will God lead you out, and deliver you from all suffering. ^67

**68** For, behold, the burning wrath of a great multitude is kindled over you, and they will take away some of you, and feed you with that which is sacrificed to idols. ^68

**69** Those who consent to them will be held in derision and in contempt, and be trodden under foot. ^69

**70** For there will be in various places, and in the next cities, a great insurrection against those who fear the Lord. ^70

**71** They will be like mad men, sparing none, but spoiling and destroying those who still fear the Lord. ^71

**72** For they will destroy and plunder their goods, and throw them out of their houses. ^72

**73** Then the trial of my elect will be made known, even as the gold that is tried in the fire. ^73

**74** Hear, my elect ones, says the Lord: “Behold, the days of suffering are at hand, and I will deliver you from them. ^74

**75** Don’t be afraid, and don’t doubt, for God is your guide. ^75

**76** You who keep my commandments and precepts,” says the Lord God, “don’t let your sins weigh you down, and don’t let your iniquities lift themselves up.” ^76

**77** Woe to those who are choked with their sins and covered with their iniquities, like a field is choked with bushes, and its path covered with thorns, that no one may travel through! ^77

**78** It is shut off and given up to be consumed by fire. ^78

← [[2 Esdras 15 - WEBU]]
