---
book: 2 Esdras
chapter: 9
version: WEBU
---
# 2 Esdras 9 (WEBU)

← [[2 Esdras 8 - WEBU]] | [[2 Esdras 10 - WEBU]] →

**1** He answered me, “Measure diligently within yourself. When you see that a certain part of the signs are past, which have been told you beforehand, ^1

**2** then will you understand that it is the very time in which the Most High will visit the world which was made by him. ^2

**3** When earthquakes, tumult of peoples, plans of nations, wavering of leaders, and confusion of princes are seen in the world, ^3

**4** then will you understand that the Most High spoke of these things from the days that were of old, from the beginning. ^4

**5** For just as with everything that is made in the world, the beginning is evident and the end manifest, ^5

**6** so also are the times of the Most High: the beginnings are manifest in wonders and mighty works, and the end in effects and signs. ^6

**7** Everyone who will be saved, and will be able to escape by his works, or by faith by which they have believed, ^7

**8** will be preserved from the said perils, and will see my salvation in my land and within my borders, which I have sanctified for myself from the beginning. ^8

**9** Then those who now have abused my ways will be amazed. Those who have cast them away despitefully will live in torments. ^9

**10** For as many as in their life have received benefits, and yet have not known me, ^10

**11** and as many as have scorned my law, while they still had liberty and when an opportunity to repent was open to them, didn’t understand, but despised it, ^11

**12** must know it in torment after death. ^12

**13** Therefore don’t be curious any longer how the ungodly will be punished, but inquire how the righteous will be saved, those who the world belongs to, and for whom the world was created.” ^13

**14** I answered, ^14

**15** “I have said before, and now speak, and will say it again hereafter, that there are more of those who perish than of those who will be saved, ^15

**16** like a wave is greater than a drop.” ^16

**17** He answered me, “Just as the field is, so also the seed. As the flowers are, so are the colors. As the work is, so also is the judgment on it. As is the farmer, so also is his threshing floor. For there was a time in the world ^17

**18** when I was preparing for those who now live, before the world was made for them to dwell in. Then no one spoke against me, ^18

**19** for no one existed. But now those who are created in this world that is prepared, both with a table that doesn’t fail and a law which is unsearchable, are corrupted in their ways. ^19

**20** So I considered my world, and behold, it was destroyed, and my earth, and behold, it was in peril, because of the plans that had come into it. ^20

**21** I saw and spared them, but not greatly, and saved myself a grape out of a cluster, and a plant out of a great forest. ^21

**22** Let the multitude perish then, which were born in vain. Let my grape be saved, and my plant, for I have made them perfect with great labor. ^22

**23** Nevertheless, if you will wait seven more days—however don’t fast in them, ^23

**24** but go into a field of flowers, where no house is built, and eat only of the flowers of the field, and you shall taste no flesh, and shall drink no wine, but shall eat flowers only— ^24

**25** and pray to the Most High continually, then I will come and talk with you.” ^25

**26** So I went my way, just as he commanded me, into the field which is called Ardat. There I sat among the flowers, and ate of the herbs of the field, and this food satisfied me. ^26

**27** It came to pass after seven days that I lay on the grass, and my heart was troubled again, like before. ^27

**28** My mouth was opened, and I began to speak before the Lord Most High, and said, ^28

**29** “O Lord, you showed yourself among us, to our fathers in the wilderness, when they went out of Egypt, and when they came into the wilderness, where no man treads and that bears no fruit. ^29

**30** You said, ‘Hear me, O Israel. Heed my words, O seed of Jacob. ^30

**31** For behold, I sow my law in you, and it will bring forth fruit in you, and you will be glorified in it forever.’ ^31

**32** But our fathers, who received the law, didn’t keep it, and didn’t observe the statutes. The fruit of the law didn’t perish, for it couldn’t, because it was yours. ^32

**33** Yet those who received it perished, because they didn’t keep the thing that was sown in them. ^33

**34** Behold, it is a custom that when the ground has received seed, or the sea a ship, or any vessel food or drink, and when it comes to pass that that which is sown, or that which is launched, ^34

**35** or the things which have been received, should come to an end, these come to an end, but the receptacles remain. Yet with us, it doesn’t happen that way. ^35

**36** For we who have received the law will perish by sin, along with our heart which received it. ^36

**37** Notwithstanding the law doesn’t perish, but remains in its honor.” ^37

**38** When I spoke these things in my heart, I looked around me with my eyes, and on my right side I saw a woman, and behold, she mourned and wept with a loud voice, and was much grieved in mind. Her clothes were torn, and she had ashes on her head. ^38

**39** Then let I my thoughts go in which I was occupied, and turned myself to her, ^39

**40** and said to her, “Why are you weeping? Why are you grieved in your mind?” ^40

**41** She said to me, “Leave me alone, my Lord, that I may weep for myself and add to my sorrow, for I am very troubled in my mind, and brought very low.” ^41

**42** I said to her, “What ails you? Tell me.” ^42

**43** She said to me, “I, your servant, was barren and had no child, though I had a husband thirty years. ^43

**44** Every hour and every day these thirty years I made my prayer to the Most High day and night. ^44

**45** It came to pass after thirty years that God heard me, your handmaid, and saw my low estate, and considered my trouble, and gave me a son. I rejoiced in him greatly, I and my husband, and all my neighbors. We gave great honor to the Mighty One. ^45

**46** I nourished him with great care. ^46

**47** So when he grew up, and I came to take him a wife, I made him a feast day. ^47

← [[2 Esdras 8 - WEBU]] | [[2 Esdras 10 - WEBU]] →
