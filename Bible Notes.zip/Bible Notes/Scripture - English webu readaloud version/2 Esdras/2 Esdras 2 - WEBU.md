---
book: 2 Esdras
chapter: 2
version: WEBU
---
# 2 Esdras 2 (WEBU)

← [[2 Esdras 1 - WEBU]] | [[2 Esdras 3 - WEBU]] →

**1** The Lord says, “I brought this people out of bondage. I gave them my commandments by my servants the prophets, whom they would not listen to, but made my counsels void. ^1

**2** The mother who bore them says to them, ‘Go your way, my children, for I am a widow and forsaken. ^2

**3** I brought you up with gladness, and I have lost you with sorrow and heaviness, for you have sinned before the Lord God, and done that which is evil before me. ^3

**4** But now what can I do for you? For I am a widow and forsaken. Go your way, my children, and ask for mercy from the Lord.’ ^4

**5** As for me, O father, I call upon you for a witness in addition to the mother of these children, because they would not keep my covenant, ^5

**6** that you may bring them to confusion, and their mother to ruin, that they may have no offspring. ^6

**7** Let them be scattered abroad among the heathen. Let their names be blotted out of the earth, for they have despised my covenant. ^7

**8** Woe to you, Assur, you who hide the unrighteous with you! You wicked nation, remember what I did to Sodom and Gomorrah, ^8

**9** whose land lies in lumps of pitch and heaps of ashes. That is what I will also do to those who have not listened to me,” says the Lord Almighty. ^9

**10** The Lord says to Esdras, “Tell my people that I will give them the kingdom of Jerusalem, which I would have given to Israel. ^10

**11** I will also take their glory back to myself, and give these the everlasting tabernacles which I had prepared for them. ^11

**12** They will have the tree of life for fragrant perfume. They will neither labor nor be weary. ^12

**13** Ask, and you will receive. Pray that your days may be few, that they may be shortened. The kingdom is already prepared for you. Watch! ^13

**14** Call heaven and earth to witness. Call them to witness, for I have left out evil, and created the good, for I live, says the Lord. ^14

**15** “Mother, embrace your children. I will bring them out with gladness like a dove does. Establish their feet, for I have chosen you, says the Lord. ^15

**16** I will raise those who are dead up again from their places, and bring them out from their tombs, for I recognize my name in them. ^16

**17** Don’t be afraid, you mother of children, for I have chosen you, says the Lord. ^17

**18** For your help, I will send my servants Esaias and Jeremy, after whose counsel I have sanctified and prepared for you twelve trees laden with various fruits, ^18

**19** and as many springs flowing with milk and honey, and seven mighty mountains, on which roses and lilies grow, with which I will fill your children with joy. ^19

**20** Do right to the widow. Secure justice for the fatherless. Give to the poor. Defend the orphan. Clothe the naked. ^20

**21** Heal the broken and the weak. Don’t laugh a lame man to scorn. Defend the maimed. Let the blind man have a vision of my glory. ^21

**22** Protect the old and young within your walls. ^22

**23** Wherever you find the dead, set a sign upon them and commit them to the grave, and I will give you the first place in my resurrection. ^23

**24** Stay still, my people, and take your rest, for your rest will come. ^24

**25** Nourish your children, good nurse, and establish their feet. ^25

**26** As for the servants whom I have given you, not one of them will perish, for I will require them from among your number. ^26

**27** Don’t be anxious, for when the day of suffering and anguish comes, others will weep and be sorrowful, but you will rejoice and have abundance. ^27

**28** The nations will envy you, but they will be able to do nothing against you, says the Lord. ^28

**29** My hands will cover you, so that your children don’t see Gehenna. ^29

**30** Be joyful, mother, with your children, for I will deliver you, says the Lord. ^30

**31** Remember your children who sleep, for I will bring them out of the secret places of the earth and show mercy to them, for I am merciful, says the Lord Almighty. ^31

**32** Embrace your children until I come, and proclaim mercy to them, for my wells run over, and my grace won’t fail.” ^32

**33** I, Esdras, received a command from the Lord on Mount Horeb to go to Israel, but when I came to them, they rejected me and rejected the Lord’s commandment. ^33

**34** Therefore I say to you, O nations that hear and understand, “Look for your shepherd. He will give you everlasting rest, for he is near at hand who will come at the end of the age. ^34

**35** Be ready for the rewards of the kingdom, for the everlasting light will shine on you forevermore. ^35

**36** Flee the shadow of this world, receive the joy of your glory. I call to witness my savior openly. ^36

**37** Receive that which is given to you by the Lord, and be joyful, giving thanks to him who has called you to heavenly kingdoms. ^37

**38** Arise and stand up, and see the number of those who have been sealed at the Lord’s feast. ^38

**39** Those who withdrew themselves from the shadow of the world have received glorious garments from the Lord. ^39

**40** Take again your full number, O Zion, and make up the reckoning of those of yours who are clothed in white, which have fulfilled the law of the Lord. ^40

**41** The number of your children, whom you long for, is fulfilled. Ask the power of the Lord, that your people, which have been called from the beginning, may be made holy.” ^41

**42** I, Esdras, saw upon Mount Zion a great multitude, whom I could not number, and they all praised the Lord with songs. ^42

**43** In the midst of them, there was a young man of a high stature, taller than all the rest, and upon every one of their heads he set crowns, and he was more exalted than they were. I marveled greatly at this. ^43

**44** So I asked the angel, and said, “What are these, my Lord?” ^44

**45** He answered and said to me, “These are those who have put off the mortal clothing, and put on the immortal, and have confessed the name of God. Now they are crowned, and receive palms.” ^45

**46** Then said I to the angel, “Who is the young man who sets crowns on them, and gives them palms in their hands?” ^46

**47** So he answered and said to me, “He is the Son of God, whom they have confessed in the world.” Then I began to praise those who stood so valiantly for the name of the Lord. ^47

**48** Then the angel said to me, “Go your way, and tell my people what kind of things, and how great wonders of the Lord God you have seen.” ^48

← [[2 Esdras 1 - WEBU]] | [[2 Esdras 3 - WEBU]] →
