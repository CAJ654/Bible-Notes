---
book: 2 Esdras
chapter: 13
version: WEBU
---
# 2 Esdras 13 (WEBU)

← [[2 Esdras 12 - WEBU]] | [[2 Esdras 14 - WEBU]] →

**1** It came to pass after seven days, I dreamed a dream by night. ^1

**2** Behold, a wind arose from the sea that moved all its waves. ^2

**3** I saw, and behold, this wind caused to come up from the midst of the sea something like the appearance of a man. I saw, and behold, that man flew with the clouds of heaven. When he turned his face to look, everything that he saw trembled. ^3

**4** Whenever the voice went out of his mouth, all who heard his voice melted, like the wax melts when it feels the fire. ^4

**5** After this I saw, and behold, an innumerable multitude of people was gathered together from the four winds of heaven to make war against the man who came out of the sea. ^5

**6** I saw, and behold, he carved himself a great mountain, and flew up onto it. ^6

**7** I tried to see the region or place from which the mountain was carved, and I couldn’t. ^7

**8** After this I saw, and behold, all those who were gathered together to fight against him were very afraid, and yet they dared to fight. ^8

**9** Behold, as he saw the assault of the multitude that came, he didn’t lift up his hand, or hold a spear or any weapon of war; ^9

**10** but I saw only how he sent out of his mouth something like a flood of fire, and out of his lips a flaming breath, and out of his tongue he shot out a storm of sparks. ^10

**11** These were all mixed together: the flood of fire, the flaming breath, and the great storm, and fell upon the assault of the multitude which was prepared to fight, and burned up every one of them, so that all of a sudden an innumerable multitude was seen to be nothing but the dust of ashes and the smell of smoke. When I saw this, I was amazed. ^11

**12** Afterward, I saw the same man come down from the mountain, and call to himself another multitude which was peaceful. ^12

**13** Many people came to him. Some of them were glad. Some were sorry. Some of them were bound, and some others brought some of those as offerings. Then through great fear I woke up and prayed to the Most High, and said, ^13

**14** “You have shown your servant these wonders from the beginning, and have counted me worthy that you should receive my prayer. ^14

**15** Now show me also the interpretation of this dream. ^15

**16** For as I conceive in my understanding, woe to those who will be left in those days! Much more woe to those who are not left! ^16

**17** For those who were not left will be in heaviness, ^17

**18** understanding the things that are laid up in the latter days, but not attaining to them. ^18

**19** But woe to them also who are left, because they will see great perils and much distress, like these dreams declare. ^19

**20** Yet is it better for one to be in peril and to come into these things, than to pass away as a cloud out of the world, and not to see the things that will happen in the last days.” He answered me, ^20

**21** “I will tell you the interpretation of the vision, and I will also open to you the things about which you mentioned. ^21

**22** You have spoken of those who are left behind. This is the interpretation: ^22

**23** He that will endure the peril in that time will protect those who fall into danger, even those who have works and faith toward the Almighty. ^23

**24** Know therefore that those who are left behind are more blessed than those who are dead. ^24

**25** These are the interpretations of the vision: Whereas you saw a man coming up from the midst of the sea, ^25

**26** this is he whom the Most High has been keeping for many ages, who by his own self will deliver his creation. He will direct those who are left behind. ^26

**27** Whereas you saw that out of his mouth came wind, fire, and storm, ^27

**28** and whereas he held neither spear, nor any weapon of war, but destroyed the assault of that multitude which came to fight against him, this is the interpretation: ^28

**29** Behold, the days come when the Most High will begin to deliver those who are on the earth. ^29

**30** Astonishment of mind will come upon those who dwell on the earth. ^30

**31** One will plan to make war against another, city against city, place against place, people against people, and kingdom against kingdom. ^31

**32** It will be, when these things come to pass, and the signs happen which I showed you before, then my Son will be revealed, whom you saw as a man ascending. ^32

**33** It will be, when all the nations hear his voice, every man will leave his own land and the battle they have against one another. ^33

**34** An innumerable multitude will be gathered together, as you saw, desiring to come and to fight against him. ^34

**35** But he will stand on the top of Mount Zion. ^35

**36** Zion will come, and will be shown to all men, being prepared and built, like you saw the mountain carved without hands. ^36

**37** My Son will rebuke the nations which have come for their wickedness, with plagues that are like a storm, ^37

**38** and will rebuke them to their face with their evil thoughts, and the torments with which they will be tormented, which are like a flame. He will destroy them without labor by the law, which is like fire. ^38

**39** Whereas you saw that he gathered to himself another multitude that was peaceful, ^39

**40** these are the ten tribes which were led away out of their own land in the time of Osea the king, whom Salmananser the king of the Assyrians led away captive, and he carried them beyond the River, and they were taken into another land. ^40

**41** But they made this plan among themselves, that they would leave the multitude of the heathen, and go out into a more distant region, where mankind had never lived, ^41

**42** that there they might keep their statutes which they had not kept in their own land. ^42

**43** They entered by the narrow passages of the river Euphrates. ^43

**44** For the Most High then did signs for them, and stopped the springs of the River until they had passed over. ^44

**45** For through that country there was a long way to go, namely, of a year and a half. The same region is called Arzareth. ^45

**46** Then they lived there until the latter time. Now when they begin to come again, ^46

**47** the Most High stops the springs of the River again, that they may go through. Therefore you saw the multitude gathered together with peace. ^47

**48** But those who are left behind of your people are those who are found within my holy border. ^48

**49** It will be therefore when he will destroy the multitude of the nations that are gathered together, he will defend the people who remain. ^49

**50** Then he will show them very many wonders.” ^50

**51** Then I said, “O sovereign Lord, explain this to me: Why have I seen the man coming up from the midst of the sea?” ^51

**52** He said to me, as no one can explore or know what is in the depths of the sea, even so no man on earth can see my Son, or those who are with him, except in the time of his day. ^52

**53** This is the interpretation of the dream which you saw, and for this only you are enlightened about this, ^53

**54** for you have forsaken your own ways, and applied your diligence to mine, and have searched out my law. ^54

**55** You have ordered your life in wisdom, and have called understanding your mother. ^55

**56** Therefore I have shown you this, for there is a reward laid up with the Most High. It will be, after another three days I will speak other things to you, and declare to you mighty and wondrous things.” ^56

**57** Then I went out and passed into the field, giving praise and thanks greatly to the Most High because of his wonders, which he did from time to time, ^57

**58** and because he governs the time, and such things as happen in their seasons. So I sat there three days. ^58

← [[2 Esdras 12 - WEBU]] | [[2 Esdras 14 - WEBU]] →
