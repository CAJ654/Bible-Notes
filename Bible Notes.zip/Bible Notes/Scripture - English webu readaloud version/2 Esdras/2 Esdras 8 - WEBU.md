---
book: 2 Esdras
chapter: 8
version: WEBU
---
# 2 Esdras 8 (WEBU)

← [[2 Esdras 7 - WEBU]] | [[2 Esdras 9 - WEBU]] →

**1** He answered me, “The Most High has made this world for many, but the world to come for few. ^1

**2** Now I will tell you a parable, Esdras. Just as when you ask the earth, it will say to you that it gives very much clay from which earthen vessels are made, but little dust that gold comes from. Even so is the course of the present world. ^2

**3** Many have been created, but few will be saved.” ^3

**4** I answered, “Drink your fill of understanding then, O my soul, and let my heart devour wisdom. ^4

**5** For you have come here apart from your will, and depart against your will, for you have only been given a short time to live. ^5

**6** O Lord over us, grant to your servant that we may pray before you, and give us seed for our heart and cultivation for our understanding, that fruit may grow from it, by which everyone who is corrupt, who bears the likeness of a man, may live. ^6

**7** For you alone exist, and we all one workmanship of your hands, just as you have said. ^7

**8** Because you give life to the body that is now fashioned in the womb, and give it members, your creature is preserved in fire and water, and your workmanship endures nine months as your creation which is created in it. ^8

**9** But that which keeps and that which is kept will both be kept by your keeping. When the womb gives up again what has grown in it, ^9

**10** you have commanded that out of the parts of the body, that is to say, out of the breasts, be given milk, which is the fruit of the breasts, ^10

**11** that the body that is fashioned may be nourished for a time, and afterwards you guide it in your mercy. ^11

**12** Yes, you have brought it up in your righteousness, nurtured it in your law, and corrected it with your judgment. ^12

**13** You put it to death as your creation, and make it live as your work. ^13

**14** If therefore you lightly and suddenly destroy him which with so great labor was fashioned by your commandment, to what purpose was he made? ^14

**15** Now therefore I will speak. About man in general, you know best, but about your people for whose sake I am sorry, ^15

**16** and for your inheritance, for whose cause I mourn, for Israel, for whom I am heavy, and for the seed of Jacob, for whose sake I am troubled, ^16

**17** therefore I will begin to pray before you for myself and for them; for I see the failings of us who dwell in the land; ^17

**18** but I have heard the swiftness of the judgment which is to come. ^18

**19** Therefore hear my voice, and understand my saying, and I will speak before you.” The beginning of the words of Esdras, before he was taken up. He said, ^19

**20** “O Lord, you who remain forever, whose eyes are exalted, and whose chambers are in the air, ^20

**21** whose throne is beyond measure, whose glory is beyond comprehension, before whom the army of angels stand with trembling, ^21

**22** at whose bidding they are changed to wind and fire, whose word is sure, and sayings constant, whose ordinance is strong, and commandment fearful, ^22

**23** whose look dries up the depths, and whose indignation makes the mountains to melt away, and whose truth bears witness— ^23

**24** hear, O Lord, the prayer of your servant, and give ear to the petition of your handiwork. ^24

**25** Attend to my words, for as long as I live, I will speak, and as long as I have understanding, I will answer. ^25

**26** Don’t look at the sins of your people, but on those who have served you in truth. ^26

**27** Don’t regard the doings of those who act wickedly, but of those who have kept your covenants in affliction. ^27

**28** Don’t think about those who have lived wickedly before you, but remember those who have willingly known your fear. ^28

**29** Let it not be your will to destroy those who have lived like cattle, but look at those who have clearly taught your law. ^29

**30** Don’t be indignant at those who are deemed worse than animals, but love those who have always put their trust in your glory. ^30

**31** For we and our fathers have passed our lives in ways that bring death, but you are called merciful because of us sinners. ^31

**32** For if you have a desire to have mercy upon us who have no works of righteousness, then you will be called merciful. ^32

**33** For the just, which have many good works laid up with you, will be rewarded for their own deeds. ^33

**34** For what is man, that you should take displeasure at him? Or what is a corruptible race, that you should be so bitter toward it? ^34

**35** For in truth, there is no man among those who are born who has not done wickedly, and among those who have lived, there is none which have not done wrong. ^35

**36** For in this, O Lord, your righteousness and your goodness will be declared, if you are merciful to those who have no store of good works.” ^36

**37** Then he answered me, “Some things you have spoken rightly, and it will happen according to your words. ^37

**38** For indeed I will not think about the fashioning of those who have sinned, or about their death, their judgment, or their destruction; ^38

**39** but I will rejoice over the creation of the righteous and their pilgrimage, their salvation, and the reward that they will have. ^39

**40** Therefore as I have spoken, so it will be. ^40

**41** For as the farmer sows many seeds in the ground, and plants many trees, and yet not all that is sown will come up in due season, neither will all that is planted take root, even so those who are sown in the world will not all be saved.” ^41

**42** Then I answered, “If I have found favor, let me speak before you. ^42

**43** If the farmer’s seed doesn’t come up because it hasn’t received your rain in due season, or if it is ruined by too much rain and perishes, ^43

**44** likewise man, who is formed with your hands and is called your own image, because he is made like you, for whose sake you have formed all things, even him you have made like the farmer’s seed. ^44

**45** Don’t be angry with us, but spare your people and have mercy upon your inheritance, for you have mercy upon your own creation.” ^45

**46** Then he answered me, “Things present are for those who live now, and things to come for those who will live hereafter. ^46

**47** For you come far short of being able to love my creature more than I. But you have compared yourself to the unrighteous. Don’t do that! ^47

**48** Yet in this will you be admirable to the Most High, ^48

**49** in that you have humbled yourself, as it becomes you, and have not judged yourself among the righteous, so as to be much glorified. ^49

**50** For many grievous miseries will fall on those who dwell in the world in the last times, because they have walked in great pride. ^50

**51** But understand for yourself, and for those who inquire concerning the glory of those like you, ^51

**52** because paradise is opened to you. The tree of life is planted. The time to come is prepared. Plenteousness is made ready. A city is built. Rest is allowed. Goodness is perfected, and wisdom is perfected beforehand. ^52

**53** The root of evil is sealed up from you. Weakness is done away from you, and death is hidden. Hell and corruption have fled into forgetfulness. ^53

**54** Sorrows have passed away, and in the end, the treasure of immortality is shown. ^54

**55** Therefore ask no more questions concerning the multitude of those who perish. ^55

**56** For when they had received liberty, they despised the Most High, scorned his law, and forsook his ways. ^56

**57** Moreover they have trodden down his righteous, ^57

**58** and said in their heart that there is no God—even knowing that they must die. ^58

**59** For as the things I have said will welcome you, so thirst and pain which are prepared for them. For the Most High didn’t intend that men should be destroyed, ^59

**60** but those who are created have themselves defiled the name of him who made them, and were unthankful to him who prepared life for them. ^60

**61** Therefore my judgment is now at hand, ^61

**62** which I have not shown to all men, but to you, and a few like you.” Then I answered, ^62

**63** “Behold, O Lord, now you have shown me the multitude of the wonders which you will do in the last times, but you haven’t shown me when.” ^63

← [[2 Esdras 7 - WEBU]] | [[2 Esdras 9 - WEBU]] →
