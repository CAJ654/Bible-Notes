---
book: 2 Esdras
chapter: 12
version: WEBU
---
# 2 Esdras 12 (WEBU)

← [[2 Esdras 11 - WEBU]] | [[2 Esdras 13 - WEBU]] →

**1** It came to pass, while the lion spoke these words to the eagle, I saw, ^1

**2** and behold, the head that remained disappeared, and the two wings which went over to it arose and set themselves up to reign; and their kingdom was brief and full of uproar. ^2

**3** I saw, and behold, they disappeared, and the whole body of the eagle was burned, so that the earth was in great fear. Then I woke up because of great perplexity of mind and great fear, and said to my spirit, ^3

**4** “Behold, you have done this to me, because you search out the ways of the Most High. ^4

**5** Behold, I am still weary in my mind, and very weak in my spirit. There isn’t even a little strength in me, because of the great fear with which I was frightened tonight. ^5

**6** Therefore I will now ask the Most High that he would strengthen me to the end.” ^6

**7** Then I said, “O sovereign Lord, if I have found favor in your sight, and if I am justified with you more than many others, and if my prayer has indeed come up before your face, ^7

**8** strengthen me then, and show me, your servant, the interpretation and plain meaning of this fearful vision, that you may fully comfort my soul. ^8

**9** For you have judged me worthy to show me the end of time and the last events of the times.” ^9

**10** He said to me, “This is the interpretation of this vision which you saw: ^10

**11** The eagle, whom you saw come up from the sea, is the fourth kingdom which appeared in a vision to your brother Daniel. ^11

**12** But it was not explained to him, as I now explain it to you or have explained it. ^12

**13** Behold, the days come that a kingdom will rise up on earth, and it will be feared more than all the kingdoms that were before it. ^13

**14** Twelve kings will reign in it, one after another. ^14

**15** Of those, the second will begin to reign, and will reign a longer time than others of the twelve. ^15

**16** This is the interpretation of the twelve wings which you saw. ^16

**17** As for when you heard a voice which spoke, not going out from the heads, but from the midst of its body, this is the interpretation: ^17

**18** That after the time of that kingdom, there will arise no small contentions, and it will stand in peril of falling. Nevertheless, it won’t fall then, but will be restored again to its former power. ^18

**19** You saw the eight under wings sticking to her wings. This is the interpretation: ^19

**20** That in it eight kings will arise, whose times will be short and their years swift. ^20

**21** Two of them will perish when the middle time approaches. Four will be kept for a while until the time of the ending of it will approach; but two will be kept to the end. ^21

**22** You saw three heads resting. This is the interpretation: ^22

**23** In its last days, the Most High will raise up three kingdoms and renew many things in them. They will rule over the earth, ^23

**24** and over those who dwell in it, with much oppression, more than all those who were before them. Therefore they are called the heads of the eagle. ^24

**25** For these are those who will accomplish her wickedness, and who will finish her last actions. ^25

**26** You saw that the great head disappeared. It signifies that one of them will die on his bed, and yet with pain. ^26

**27** But for the two that remained, the sword will devour them. ^27

**28** For the sword of the one will devour him that was with him, but he will also fall by the sword in the last days. ^28

**29** You saw two under wings passing over to the head that is on the right side. ^29

**30** This is the interpretation: These are they whom the Most High has kept to his end. This is the brief reign that was full of trouble, as you saw. ^30

**31** “The lion, whom you saw rising up out of the forest, roaring, speaking to the eagle, and rebuking her for her unrighteousness, and all her words which you have heard, ^31

**32** this is the anointed one, whom the Most High has kept to the end of days, who will spring up out of the seed of David, and he will come and speak to them and reprove them for their wickedness and unrighteousness, and willheap up before them their contemptuous dealings. ^32

**33** For at first he will set them alive in his judgment, and when he has reproved them, he will destroy them. ^33

**34** For he will deliver the rest of my people with mercy, those who have been preserved throughout my borders, and he will make them joyful until the coming of the end, even the day of judgment, about which I have spoken to you from the beginning. ^34

**35** This is the dream that you saw, and this is its interpretation. ^35

**36** Only you have been worthy to know the secret of the Most High. ^36

**37** Therefore write all these things that you have seen in a book, and put it in a secret place. ^37

**38** You shall teach them to the wise of your people, whose hearts you know are able to comprehend and keep these secrets. ^38

**39** But wait here yourself seven more days, that you may be shown whatever it pleases the Most High to show you.” Then he departed from me. ^39

**40** It came to pass, when all the people saw that the seven days were past, and I had not come again into the city, they all gathered together, from the least to the greatest, and came to me, and spoke to me, saying, ^40

**41** “How have we offended you? What evil have we done against you, that you have utterly forsaken us, and sit in this place? ^41

**42** For of all the prophets, only you are left to us, like a cluster of the vintage, and like a lamp in a dark place, and like a harbor for a ship saved from the tempest. ^42

**43** Aren’t the evils which have come to us sufficient? ^43

**44** If you will forsake us, how much better had it been for us if we also had been consumed in the burning of Zion! ^44

**45** For we are not better than those who died there.” Then they wept with a loud voice. I answered them, ^45

**46** “Take courage, O Israel! Don’t be sorrowful, you house of Jacob; ^46

**47** for the Most High remembers you. The Mighty has not forgotten you forever. ^47

**48** As for me, I have not forsaken you. I haven’t departed from you; but I have come into this place to pray for the desolation of Zion, and that I might seek mercy for the humiliation of your sanctuary. ^48

**49** Now go your way, every man to his own house, and after these days I will come to you.” ^49

**50** So the people went their way into the city, as I told them to do. ^50

**51** But I sat in the field seven days, as the angel commanded me. In those days, I ate only of the flowers of the field, and my food was from plants. ^51

← [[2 Esdras 11 - WEBU]] | [[2 Esdras 13 - WEBU]] →
