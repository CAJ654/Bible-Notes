---
book: 2 Esdras
chapter: 4
version: WEBU
---
# 2 Esdras 4 (WEBU)

← [[2 Esdras 3 - WEBU]] | [[2 Esdras 5 - WEBU]] →

**1** The angel who was sent to me, whose name was Uriel, gave me an answer, ^1

**2** and said to me, “Your understanding has utterly failed you regarding this world. Do you think you can comprehend the way of the Most High?” ^2

**3** Then I said, “Yes, my Lord.” He answered me, “I have been sent to show you three ways, and to set before you three problems. ^3

**4** If you can solve one for me, I also will show you the way that you desire to see, and I will teach you why the heart is wicked.” ^4

**5** I said, “Say on, my Lord.” Then said he to me, “Go, weigh for me the weight of a fire, or measure for me a blast of wind, or call back for me the day that is past.” ^5

**6** Then answered I and said, “Who of the sons of men is able to do this, that you should ask me about such things?” ^6

**7** He said to me, “If I had asked you, ‘How many dwellings are there in the heart of the sea? Or how many springs are there at the fountain head of the deep? Or how many streams are above the firmament? Or which are the exits of hell? Or which are the entrances of paradise?’ ^7

**8** perhaps you would say to me, ‘I never went down into the deep, or as yet into hell, neither did I ever climb up into heaven.’ ^8

**9** Nevertheless now I have only asked you about the fire, wind, and the day, things which you have experienced, and from which you can’t be separated, and yet you have given me no answer about them.” ^9

**10** He said moreover to me, “You can’t understand your own things that you grew up with. ^10

**11** How then can your mind comprehend the way of the Most High? How can he who is already worn out with the corrupted world understand incorruption?” When I heard these things, I fell on my face ^11

**12** and said to him, “It would have been better if we weren’t here at all, than that we should come here and live in the midst of ungodliness, and suffer, and not know why.” ^12

**13** He answered me, and said, “A forest of the trees of the field went out, and took counsel together, ^13

**14** and said, ‘Come! Let’s go and make war against the sea, that it may depart away before us, and that we may make ourselves more forests.’ ^14

**15** The waves of the sea also in like manner took counsel together, and said, ‘Come! Let’s go up and subdue the forest of the plain, that there also we may gain more territory.’ ^15

**16** The counsel of the wood was in vain, for the fire came and consumed it. ^16

**17** Likewise also the counsel of the waves of the sea, for the sand stood up and stopped them. ^17

**18** If you were judge now between these two, which would you justify, or which would you condemn?” ^18

**19** I answered and said, “It is a foolish counsel that they both have taken, for the ground is given to the wood, and the place of the sea is given to bear its waves.” ^19

**20** Then answered he me, and said, “You have given a right judgment. Why don’t you judge your own case? ^20

**21** For just as the ground is given to the wood, and the sea to its waves, even so those who dwell upon the earth may understand nothing but what is upon the earth. Only he who dwells above the heavens understands the things that are above the height of the heavens.” ^21

**22** Then answered I and said, “I beg you, O Lord, why has the power of understanding been given to me? ^22

**23** For it was not in my mind to be curious of the ways above, but of such things as pass by us daily, because Israel is given up as a reproach to the heathen. The people whom you have loved have been given over to ungodly nations. The law of our forefathers is made of no effect, and the written covenants are nowhere regarded. ^23

**24** We pass away out of the world like locusts. Our life is like a vapor, and we aren’t worthy to obtain mercy. ^24

**25** What will he then do for his name by which we are called? I have asked about these things.” ^25

**26** Then he answered me, and said, “If you are alive you will see, and if you live long, you will marvel, for the world hastens quickly to pass away. ^26

**27** For it is not able to bear the things that are promised to the righteous in the times to come; for this world is full of sadness and infirmities. ^27

**28** For the evil about which you asked me has been sown, but its harvest hasn’t yet come. ^28

**29** If therefore that which is sown isn’t reaped, and if the place where the evil is sown doesn’t pass away, the field where the good is sown won’t come. ^29

**30** For a grain of evil seed was sown in the heart of Adam from the beginning, and how much wickedness it has produced to this time! How much more it will yet produce until the time of threshing comes! ^30

**31** Ponder now by yourself, how much fruit of wickedness a grain of evil seed has produced. ^31

**32** When the grains which are without number are sown, how great a threshing floor they will fill!” ^32

**33** Then I answered and said, “How long? When will these things come to pass? Why are our years few and evil?” ^33

**34** He answered me, and said, “Don’t hurry faster than the Most High; for your haste is for your own self, but he who is above hurries on behalf of many. ^34

**35** Didn’t the souls of the righteous ask about these things in their chambers, saying, ‘How long will we be here? When does the fruit of the threshing floor come?’ ^35

**36** To them, Jeremiel the archangel answered, ‘When the number is fulfilled of those who are like you. For he has weighed the world in the balance. ^36

**37** By measure, he has measured the times. By number, he has counted the seasons. He won’t move or stir them until that measure is fulfilled.’” ^37

**38** Then I answered, “O sovereign Lord, all of us are full of ungodliness. ^38

**39** Perhaps it is for our sakes that the threshing time of the righteous is kept back—because of the sins of those who dwell on the earth.” ^39

**40** So he answered me, “Go your way to a woman with child, and ask of her when she has fulfilled her nine months, if her womb may keep the baby any longer within her.” ^40

**41** Then I said, “No, Lord, that can it not.” He said to me, “In Hades, the chambers of souls are like the womb. ^41

**42** For just like a woman in labor hurries to escape the anguish of the labor pains, even so these places hurry to deliver those things that are committed to them from the beginning. ^42

**43** Then you will be shown those things which you desire to see.” ^43

**44** Then I answered, “If I have found favor in your sight, and if it is possible, and if I am worthy, ^44

**45** show me this also, whether there is more to come than is past, or whether the greater part has gone over us. ^45

**46** For what is gone I know, but I don’t know what is to come.” ^46

**47** He said to me, “Stand up on my right side, and I will explain the parable to you.” ^47

**48** So I stood, looked, and saw a hot burning oven passed by before me. It happened that when the flame had gone by I looked, and saw that the smoke remained. ^48

**49** After this, a watery cloud passed in front of me, and sent down much rain with a storm. When the stormy rain was past, the drops still remained in it.” ^49

**50** Then said he to me, “Consider with yourself; as the rain is more than the drops, and the fire is greater than the smoke, so the quantity which is past was far greater; but the drops and the smoke still remained.” ^50

**51** Then I prayed, and said, “Do you think that I will live until that time? Or who will be alive in those days?” ^51

**52** He answered me, “As for the signs you asked me about, I may tell you of them in part; but I wasn’t sent to tell you about your life, for I don’t know. ^52

← [[2 Esdras 3 - WEBU]] | [[2 Esdras 5 - WEBU]] →
