---
book: 2 Esdras
chapter: 1
version: WEBU
---
# 2 Esdras 1 (WEBU)

[[2 Esdras 2 - WEBU]] →

**1** The second book of the prophet Esdras, the son of Saraias, the son of Azaraias, the son of Helkias, the son of Salemas, the son of Sadoc, the son of Ahitob, ^1

**2** the son of Achias, the son of Phinees, the son of Heli, the son of Amarias, the son of Aziei, the son of Marimoth, the son of Arna, the son of Ozias, the son of Borith, the son of Abissei, the son of Phinees, the son of Eleazar, ^2

**3** the son of Aaron, of the tribe of Levi, who was captive in the land of the Medes, in the reign of Artaxerxes king of the Persians. ^3

**4** The Lord’s word came to me, saying, ^4

**5** “Go your way and show my people their sinful deeds, and their children their wickedness which they have done against me, that they may tell their children’s children, ^5

**6** because the sins of their fathers have increased in them, for they have forgotten me, and have offered sacrifices to foreign gods. ^6

**7** Didn’t I bring them out of the land of Egypt, out of the house of bondage? But they have provoked me to wrath and have despised my counsels. ^7

**8** So pull out the hair of your head and cast all evils upon them, for they have not been obedient to my law, but they are a rebellious people. ^8

**9** How long shall I endure them, to whom I have done so much good? ^9

**10** I have overthrown many kings for their sakes. I have struck down Pharoah with his servants and all his army. ^10

**11** I have destroyed all the nations before them. In the east, I have scattered the people of two provinces, even of Tyre and Sidon, and have slain all their adversaries. ^11

**12** Speak therefore to them, saying: ^12

**13** “The Lord says, truly I brought you through the sea, and where there was no path I made highways for you. I gave you Moses for a leader and Aaron for a priest. ^13

**14** I gave you light in a pillar of fire. I have done great wonders among you, yet you have forgotten me, says the Lord. ^14

**15** “The Lord Almighty says: The quails were for a token to you. I gave you a camp for your protection, but you complained there. ^15

**16** You didn’t celebrate in my name for the destruction of your enemies, but even to this day you still complain. ^16

**17** Where are the benefits that I have given you? When you were hungry and thirsty in the wilderness, didn’t you cry to me, ^17

**18** saying, ‘Why have you brought us into this wilderness to kill us? It would have been better for us to have served the Egyptians than to die in this wilderness.’ ^18

**19** I had pity on your mourning and gave you manna for food. You ate angels’ bread. ^19

**20** When you were thirsty, didn’t I split the rock, and water flowed out in abundance? Because of the heat, I covered you with the leaves of the trees. ^20

**21** I divided fruitful lands among you. I drove out the Canaanites, the Pherezites, and the Philistines before you. What more shall I do for you?” says the Lord. ^21

**22** The Lord Almighty says, “When you were in the wilderness, at the bitter stream, being thirsty and blaspheming my name, ^22

**23** I gave you not fire for your blasphemies, but threw a tree in the water, and made the river sweet. ^23

**24** What shall I do to you, O Jacob? You, Judah, would not obey me. I will turn myself to other nations, and I will give my name to them, that they may keep my statutes. ^24

**25** Since you have forsaken me, I also will forsake you. When you ask me to be merciful to you, I will have no mercy upon you. ^25

**26** Whenever you call upon me, I will not hear you, for you have defiled your hands with blood, and your feet are swift to commit murder. ^26

**27** It is not as though you have forsaken me, but your own selves,” says the Lord. ^27

**28** The Lord Almighty says, “Haven’t I asked you as a father his sons, as a mother her daughters, and a nurse her young babies, ^28

**29** that you would be my people, and I would be your God, that you would be my children, and I would be your father? ^29

**30** I gathered you together, as a hen gathers her chicks under her wings. But now, what should I do to you? I will cast you out from my presence. ^30

**31** When you offer burnt sacrifices to me, I will turn my face from you, for I have rejected your solemn feast days, your new moons, and your circumcisions of the flesh. ^31

**32** I sent to you my servants the prophets, whom you have taken and slain, and torn their bodies in pieces, whose blood I will require from you,” says the Lord. ^32

**33** The Lord Almighty says, “Your house is desolate. I will cast you out as the wind blows stubble. ^33

**34** Your children won’t be fruitful, for they have neglected my commandment to you, and done that which is evil before me. ^34

**35** I will give your houses to a people that will come, which not having heard of me yet believe me. Those to whom I have shown no signs will do what I have commanded. ^35

**36** They have seen no prophets, yet they will remember their former condition. ^36

**37** I call to witness the gratitude of the people who will come, whose little ones rejoice with gladness. Although they see me not with bodily eyes, yet in spirit they will believe what I say.” ^37

**38** And now, father, behold with glory, and see the people that come from the east: ^38

**39** to whom I will give for leaders, Abraham, Isaac, and Jacob, Oseas, Amos, and Micheas, Joel, Abdias, and Jonas, ^39

**40** Nahum, and Abacuc, Sophonias, Aggaeus, Zachary, and Malachy, who is also called the Lord’s messenger. ^40

[[2 Esdras 2 - WEBU]] →
