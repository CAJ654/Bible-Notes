---
book: 1 Timothy
chapter: 6
version: WEBU
---
# 1 Timothy 6 (WEBU)

← [[1 Timothy 5 - WEBU]]

**1** Let as many as are bondservants under the yoke count their own masters worthy of all honor, that the name of God and the doctrine not be blasphemed. ^1

**2** Those who have believing masters, let them not despise them because they are brothers, but rather let them serve them, because those who partake of the benefit are believing and beloved. Teach and exhort these things. ^2

**3** If anyone teaches a different doctrine and doesn’t consent to sound words, the words of our Lord Jesus Christ, and to the doctrine which is according to godliness, ^3

**4** he is conceited, knowing nothing, but obsessed with arguments, disputes, and word battles, from which come envy, strife, insulting, evil suspicions, ^4

**5** constant friction of people of corrupt minds and destitute of the truth, who suppose that godliness is a means of gain. Withdraw yourself from such. ^5

**6** But godliness with contentment is great gain. ^6

**7** For we brought nothing into the world, and we certainly can’t carry anything out. ^7

**8** But having food and clothing, we will be content with that. ^8

**9** But those who are determined to be rich fall into a temptation, a snare, and many foolish and harmful lusts, such as drown men in ruin and destruction. ^9

**10** For the love of money is a root of all kinds of evil. Some have been led astray from the faith in their greed, and have pierced themselves through with many sorrows. ^10

**11** But you, man of God, flee these things, and follow after righteousness, godliness, faith, love, perseverance, and gentleness. ^11

**12** Fight the good fight of faith. Take hold of the eternal life to which you were called, and you confessed the good confession in the sight of many witnesses. ^12

**13** I command you before God who gives life to all things, and before Christ Jesus who before Pontius Pilate testified the good confession, ^13

**14** that you keep the commandment without spot, blameless until the appearing of our Lord Jesus Christ, ^14

**15** which at the right time he will show, who is the blessed and only Ruler, the King of kings and Lord of lords. ^15

**16** He alone has immortality, dwelling in unapproachable light, whom no man has seen nor can see, to whom be honor and eternal power. Amen. ^16

**17** Charge those who are rich in this present age that they not be arrogant, nor have their hope set on the uncertainty of riches, but on the living God, who richly provides us with everything to enjoy; ^17

**18** that they do good, that they be rich in good works, that they be ready to distribute, willing to share; ^18

**19** laying up in store for themselves a good foundation against the time to come, that they may lay hold of eternal life. ^19

**20** Timothy, guard that which is committed to you, turning away from the empty chatter and oppositions of what is falsely called knowledge, ^20

**21** which some profess, and thus have wandered from the faith. Grace be with you. Amen. ^21

← [[1 Timothy 5 - WEBU]]
