---
book: 1 Timothy
chapter: 5
version: WEBU
---
# 1 Timothy 5 (WEBU)

← [[1 Timothy 4 - WEBU]] | [[1 Timothy 6 - WEBU]] →

**1** Don’t rebuke an older man, but exhort him as a father; the younger men as brothers; ^1

**2** the elder women as mothers; the younger as sisters, in all purity. ^2

**3** Honor widows who are widows indeed. ^3

**4** But if any widow has children or grandchildren, let them learn first to show piety toward their own family and to repay their parents, for this is acceptable in the sight of God. ^4

**5** Now she who is a widow indeed and desolate, has her hope set on God and continues in petitions and prayers night and day. ^5

**6** But she who gives herself to pleasure is dead while she lives. ^6

**7** Also command these things, that they may be without reproach. ^7

**8** But if anyone doesn’t provide for his own, and especially his own household, he has denied the faith and is worse than an unbeliever. ^8

**9** Let no one be enrolled as a widow under sixty years old, having been the wife of one man, ^9

**10** being approved by good works, if she has brought up children, if she has been hospitable to strangers, if she has washed the saints’ feet, if she has relieved the afflicted, and if she has diligently followed every good work. ^10

**11** But refuse younger widows, for when they have grown wanton against Christ, they desire to marry, ^11

**12** having condemnation, because they have rejected their first pledge. ^12

**13** Besides, they also learn to be idle, going about from house to house. Not only idle, but also gossips and busybodies, saying things which they ought not. ^13

**14** I desire therefore that the younger widows marry, bear children, rule the household, and give no occasion to the adversary for insulting. ^14

**15** For already some have turned away after Satan. ^15

**16** If any man or woman who believes has widows, let them relieve them, and don’t let the assembly be burdened, that it might relieve those who are widows indeed. ^16

**17** Let the elders who rule well be counted worthy of double honor, especially those who labor in the word and in teaching. ^17

**18** For the Scripture says, “You shall not muzzle the ox when it treads out the grain.” And, “The laborer is worthy of his wages.” ^18

**19** Don’t receive an accusation against an elder except at the word of two or three witnesses. ^19

**20** Those who sin, reprove in the sight of all, that the rest also may be in fear. ^20

**21** I command you in the sight of God, and the Lord Jesus Christ, and the chosen angels, that you observe these things without prejudice, doing nothing by partiality. ^21

**22** Lay hands hastily on no one. Don’t be a participant in other people’s sins. Keep yourself pure. ^22

**23** Be no longer a drinker of water only, but use a little wine for your stomach’s sake and your frequent infirmities. ^23

**24** Some men’s sins are evident, preceding them to judgment, and some also follow later. ^24

**25** In the same way also there are good works that are obvious, and those that are otherwise can’t be hidden. ^25

← [[1 Timothy 4 - WEBU]] | [[1 Timothy 6 - WEBU]] →
