---
book: 1 Timothy
chapter: 1
version: WEBU
---
# 1 Timothy 1 (WEBU)

[[1 Timothy 2 - WEBU]] →

**1** Paul, an apostle of Jesus Christ according to the commandment of God our Savior and the Lord Jesus Christ our hope, ^1

**2** to Timothy, my true child in faith: Grace, mercy, and peace from God our Father and Christ Jesus our Lord. ^2

**3** As I urged you when I was going into Macedonia, stay at Ephesus that you might command certain men not to teach a different doctrine, ^3

**4** and not to pay attention to myths and endless genealogies, which cause disputes rather than God’s stewardship, which is in faith. ^4

**5** But the goal of this command is love from a pure heart, a good conscience, and sincere faith, ^5

**6** from which things some, having missed the mark, have turned away to vain talking, ^6

**7** desiring to be teachers of the law, though they understand neither what they say nor about what they strongly affirm. ^7

**8** But we know that the law is good if a person uses it lawfully, ^8

**9** as knowing this, that law is not made for a righteous person, but for the lawless and insubordinate, for the ungodly and sinners, for the unholy and profane, for murderers of fathers and murderers of mothers, for manslayers, ^9

**10** for the sexually immoral, for homosexuals, for slave-traders, for liars, for perjurers, and for any other thing contrary to the sound doctrine, ^10

**11** according to the Good News of the glory of the blessed God, which was committed to my trust. ^11

**12** I thank him who enabled me, Christ Jesus our Lord, because he counted me faithful, appointing me to service, ^12

**13** although I used to be a blasphemer, a persecutor, and insolent. However, I obtained mercy because I did it ignorantly in unbelief. ^13

**14** The grace of our Lord abounded exceedingly with faith and love which is in Christ Jesus. ^14

**15** The saying is faithful and worthy of all acceptance, that Christ Jesus came into the world to save sinners, of whom I am chief. ^15

**16** However, for this cause I obtained mercy, that in me first, Jesus Christ might display all his patience for an example of those who were going to believe in him for eternal life. ^16

**17** Now to the King eternal, immortal, invisible, to God who alone is wise, be honor and glory forever and ever. Amen. ^17

**18** I commit this instruction to you, my child Timothy, according to the prophecies which were given to you before, that by them you may wage the good warfare, ^18

**19** holding faith and a good conscience, which some having thrust away made a shipwreck concerning the faith, ^19

**20** of whom are Hymenaeus and Alexander, whom I delivered to Satan that they might be taught not to blaspheme. ^20

[[1 Timothy 2 - WEBU]] →
