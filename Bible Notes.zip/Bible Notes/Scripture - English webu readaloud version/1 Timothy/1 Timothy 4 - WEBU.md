---
book: 1 Timothy
chapter: 4
version: WEBU
---
# 1 Timothy 4 (WEBU)

← [[1 Timothy 3 - WEBU]] | [[1 Timothy 5 - WEBU]] →

**1** But the Spirit says expressly that in later times some will fall away from the faith, paying attention to seducing spirits and doctrines of demons, ^1

**2** through the hypocrisy of men who speak lies, branded in their own conscience as with a hot iron, ^2

**3** forbidding marriage and commanding to abstain from foods which God created to be received with thanksgiving by those who believe and know the truth. ^3

**4** For every creature of God is good, and nothing is to be rejected if it is received with thanksgiving. ^4

**5** For it is sanctified through the word of God and prayer. ^5

**6** If you instruct the brothers of these things, you will be a good servant of Christ Jesus, nourished in the words of the faith and of the good doctrine which you have followed. ^6

**7** But refuse profane and old wives’ fables. Exercise yourself toward godliness. ^7

**8** For bodily exercise has some value, but godliness has value in all things, having the promise of the life which is now and of that which is to come. ^8

**9** This saying is faithful and worthy of all acceptance. ^9

**10** For to this end we both labor and suffer reproach, because we have set our trust in the living God, who is the Savior of all men, especially of those who believe. ^10

**11** Command and teach these things. ^11

**12** Let no man despise your youth; but be an example to those who believe, in word, in your way of life, in love, in spirit, in faith, and in purity. ^12

**13** Until I come, pay attention to reading, to exhortation, and to teaching. ^13

**14** Don’t neglect the gift that is in you, which was given to you by prophecy with the laying on of the hands of the elders. ^14

**15** Be diligent in these things. Give yourself wholly to them, that your progress may be revealed to all. ^15

**16** Pay attention to yourself and to your teaching. Continue in these things, for in doing this you will save both yourself and those who hear you. ^16

← [[1 Timothy 3 - WEBU]] | [[1 Timothy 5 - WEBU]] →
