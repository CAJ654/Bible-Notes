---
book: 1 John
chapter: 5
version: WEBU
---
# 1 John 5 (WEBU)

← [[1 John 4 - WEBU]]

**1** Whoever believes that Jesus is the Christ has been born of God. Whoever loves the Father also loves the child who is born of him. ^1

**2** By this we know that we love the children of God, when we love God and keep his commandments. ^2

**3** For this is loving God, that we keep his commandments. His commandments are not grievous. ^3

**4** For whatever is born of God overcomes the world. This is the victory that has overcome the world: your faith. ^4

**5** Who is he who overcomes the world, but he who believes that Jesus is the Son of God? ^5

**6** This is he who came by water and blood, Jesus Christ; not with the water only, but with the water and the blood. It is the Spirit who testifies, because the Spirit is the truth. ^6

**7** For there are three who testify: ^7

**8** the Spirit, the water, and the blood; and the three agree as one. ^8

**9** If we receive the witness of men, the witness of God is greater; for this is God’s testimony which he has testified concerning his Son. ^9

**10** He who believes in the Son of God has the testimony in himself. He who doesn’t believe God has made him a liar, because he has not believed in the testimony that God has given concerning his Son. ^10

**11** The testimony is this: that God gave to us eternal life, and this life is in his Son. ^11

**12** He who has the Son has the life. He who doesn’t have God’s Son doesn’t have the life. ^12

**13** These things I have written to you who believe in the name of the Son of God, that you may know that you have eternal life, and that you may continue to believe in the name of the Son of God. ^13

**14** This is the boldness which we have toward him, that if we ask anything according to his will, he listens to us. ^14

**15** And if we know that he listens to us, whatever we ask, we know that we have the petitions which we have asked of him. ^15

**16** If anyone sees his brother sinning a sin not leading to death, he shall ask, and God will give him life for those who sin not leading to death. There is sin leading to death. I don’t say that he should make a request concerning this. ^16

**17** All unrighteousness is sin, and there is sin not leading to death. ^17

**18** We know that whoever is born of God doesn’t sin, but he who was born of God keeps himself, and the evil one doesn’t touch him. ^18

**19** We know that we are of God, and the whole world lies in the power of the evil one. ^19

**20** We know that the Son of God has come and has given us an understanding, that we know him who is true; and we are in him who is true, in his Son Jesus Christ. This is the true God and eternal life. ^20

**21** Little children, keep yourselves from idols. ^21

← [[1 John 4 - WEBU]]
