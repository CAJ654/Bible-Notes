---
book: 1 John
chapter: 1
version: WEBU
---
# 1 John 1 (WEBU)

[[1 John 2 - WEBU]] →

**1** That which was from the beginning, that which we have heard, that which we have seen with our eyes, that which we saw, and our hands touched, concerning the Word of life ^1

**2** (and the life was revealed, and we have seen, and testify, and declare to you the life, the eternal life, which was with the Father, and was revealed to us); ^2

**3** that which we have seen and heard we declare to you, that you also may have fellowship with us. Yes, and our fellowship is with the Father and with his Son, Jesus Christ. ^3

**4** And we write these things to you, that our joy may be fulfilled. ^4

**5** This is the message which we have heard from him and announce to you, that God is light, and in him is no darkness at all. ^5

**6** If we say that we have fellowship with him and walk in the darkness, we lie and don’t tell the truth. ^6

**7** But if we walk in the light as he is in the light, we have fellowship with one another, and the blood of Jesus Christ his Son cleanses us from all sin. ^7

**8** If we say that we have no sin, we deceive ourselves, and the truth is not in us. ^8

**9** If we confess our sins, he is faithful and righteous to forgive us the sins and to cleanse us from all unrighteousness. ^9

**10** If we say that we haven’t sinned, we make him a liar, and his word is not in us. ^10

[[1 John 2 - WEBU]] →
