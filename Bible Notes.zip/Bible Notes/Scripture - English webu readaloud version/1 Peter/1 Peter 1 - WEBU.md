---
book: 1 Peter
chapter: 1
version: WEBU
---
# 1 Peter 1 (WEBU)

[[1 Peter 2 - WEBU]] →

**1** Peter, an apostle of Jesus Christ, to the chosen ones who are living as foreigners in the Dispersion in Pontus, Galatia, Cappadocia, Asia, and Bithynia, ^1

**2** according to the foreknowledge of God the Father, in sanctification of the Spirit, that you may obey Jesus Christ and be sprinkled with his blood: Grace to you and peace be multiplied. ^2

**3** Blessed be the God and Father of our Lord Jesus Christ, who according to his great mercy caused us to be born again to a living hope through the resurrection of Jesus Christ from the dead, ^3

**4** to an incorruptible and undefiled inheritance that doesn’t fade away, reserved in Heaven for you, ^4

**5** who by the power of God are guarded through faith for a salvation ready to be revealed in the last time. ^5

**6** In this you greatly rejoice, though now for a little while, if need be, you have been grieved in various trials, ^6

**7** that the proof of your faith, which is more precious than gold that perishes, even though it is tested by fire, may be found to result in praise, glory, and honor at the revelation of Jesus Christ— ^7

**8** whom, not having known, you love. In him, though now you don’t see him, yet believing, you rejoice greatly with joy that is unspeakable and full of glory, ^8

**9** receiving the result of your faith, the salvation of your souls. ^9

**10** Concerning this salvation, the prophets sought and searched diligently. They prophesied of the grace that would come to you, ^10

**11** searching for who or what kind of time the Spirit of Christ which was in them pointed to when he predicted the sufferings of Christ and the glories that would follow them. ^11

**12** To them it was revealed that they served not themselves, but you, in these things, which now have been announced to you through those who preached the Good News to you by the Holy Spirit sent out from heaven; which things angels desire to look into. ^12

**13** Therefore prepare your minds for action. Be sober, and set your hope fully on the grace that will be brought to you at the revelation of Jesus Christ— ^13

**14** as children of obedience, not conforming yourselves according to your former lusts as in your ignorance, ^14

**15** but just as he who called you is holy, you yourselves also be holy in all of your behavior, ^15

**16** because it is written, “You shall be holy, for I am holy.” ^16

**17** If you call on him as Father, who without respect of persons judges according to each man’s work, pass the time of your living as foreigners here in reverent fear, ^17

**18** knowing that you were redeemed, not with corruptible things like silver or gold, from the useless way of life handed down from your fathers, ^18

**19** but with precious blood, as of a lamb without blemish or spot, the blood of Christ, ^19

**20** who was foreknown indeed before the foundation of the world, but was revealed in this last age for your sake, ^20

**21** who through him are believers in God, who raised him from the dead and gave him glory, so that your faith and hope might be in God. ^21

**22** Seeing you have purified your souls in your obedience to the truth through the Spirit in sincere brotherly affection, love one another from the heart fervently, ^22

**23** having been born again, not of corruptible seed, but of incorruptible, through the word of God, which lives and remains forever. ^23

**24** For, “All flesh is like grass, and all of man’s glory like the flower in the grass. The grass withers, and its flower falls; ^24

**25** but the Lord’s word endures forever.” This is the word of Good News which was preached to you. ^25

[[1 Peter 2 - WEBU]] →
