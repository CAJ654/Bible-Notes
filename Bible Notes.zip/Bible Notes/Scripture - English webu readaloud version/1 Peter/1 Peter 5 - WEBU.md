---
book: 1 Peter
chapter: 5
version: WEBU
---
# 1 Peter 5 (WEBU)

← [[1 Peter 4 - WEBU]]

**1** Therefore I exhort the elders among you, as a fellow elder and a witness of the sufferings of Christ, and who will also share in the glory that will be revealed: ^1

**2** shepherd the flock of God which is among you, exercising the oversight, not under compulsion, but voluntarily; not for dishonest gain, but willingly; ^2

**3** not as lording it over those entrusted to you, but making yourselves examples to the flock. ^3

**4** When the chief Shepherd is revealed, you will receive the crown of glory that doesn’t fade away. ^4

**5** Likewise, you younger ones, be subject to the elder. Yes, all of you clothe yourselves with humility and subject yourselves to one another; for “God resists the proud, but gives grace to the humble.” ^5

**6** Humble yourselves therefore under the mighty hand of God, that he may exalt you in due time, ^6

**7** casting all your worries on him, because he cares for you. ^7

**8** Be sober and self-controlled. Be watchful. Your adversary, the devil, walks around like a roaring lion, seeking whom he may devour. ^8

**9** Withstand him steadfast in your faith, knowing that your brothers who are in the world are undergoing the same sufferings. ^9

**10** But may the God of all grace, who called you to his eternal glory by Christ Jesus, after you have suffered a little while, perfect, establish, strengthen, and settle you. ^10

**11** To him be the glory and the power forever and ever. Amen. ^11

**12** Through Silvanus, our faithful brother, as I consider him, I have written to you briefly, exhorting and testifying that this is the true grace of God in which you stand. ^12

**13** She who is in Babylon, chosen together with you, greets you. So does Mark, my son. ^13

**14** Greet one another with a kiss of love. Peace be to all of you who are in Christ Jesus. Amen. ^14

← [[1 Peter 4 - WEBU]]
