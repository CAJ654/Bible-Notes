---
book: 1 Peter
chapter: 4
version: WEBU
---
# 1 Peter 4 (WEBU)

← [[1 Peter 3 - WEBU]] | [[1 Peter 5 - WEBU]] →

**1** Therefore, since Christ suffered for us in the flesh, arm yourselves also with the same mind; for he who has suffered in the flesh has ceased from sin, ^1

**2** that you no longer should live the rest of your time in the flesh for the lusts of men, but for the will of God. ^2

**3** For we have spent enough of our past time doing the desire of the Gentiles, and having walked in lewdness, lusts, drunken binges, orgies, carousings, and abominable idolatries. ^3

**4** They think it is strange that you don’t run with them into the same excess of riot, speaking evil of you. ^4

**5** They will give account to him who is ready to judge the living and the dead. ^5

**6** For to this end the Good News was preached even to the dead, that they might be judged indeed as men in the flesh, but live as to God in the spirit. ^6

**7** But the end of all things is near. Therefore be of sound mind, self-controlled, and sober in prayer. ^7

**8** And above all things be earnest in your love among yourselves, for love covers a multitude of sins. ^8

**9** Be hospitable to one another without grumbling. ^9

**10** As each has received a gift, employ it in serving one another, as good managers of the grace of God in its various forms. ^10

**11** If anyone speaks, let it be as it were the very words of God. If anyone serves, let it be as of the strength which God supplies, that in all things God may be glorified through Jesus Christ, to whom belong the glory and the dominion forever and ever. Amen. ^11

**12** Beloved, don’t be astonished at the fiery trial which has come upon you to test you, as though a strange thing happened to you. ^12

**13** But because you are partakers of Christ’s sufferings, rejoice, that at the revelation of his glory you also may rejoice with exceeding joy. ^13

**14** If you are insulted for the name of Christ, you are blessed, because the Spirit of glory and of God rests on you. On their part he is blasphemed, but on your part he is glorified. ^14

**15** But let none of you suffer as a murderer, or a thief, or an evil doer, or a meddler in other men’s matters. ^15

**16** But if one of you suffers for being a Christian, let him not be ashamed; but let him glorify God in this matter. ^16

**17** For the time has come for judgment to begin with the household of God. If it begins first with us, what will happen to those who don’t obey the Good News of God? ^17

**18** “If it is hard for the righteous to be saved, what will happen to the ungodly and the sinner?” ^18

**19** Therefore let them also who suffer according to the will of God in doing good entrust their souls to him, as to a faithful Creator. ^19

← [[1 Peter 3 - WEBU]] | [[1 Peter 5 - WEBU]] →
