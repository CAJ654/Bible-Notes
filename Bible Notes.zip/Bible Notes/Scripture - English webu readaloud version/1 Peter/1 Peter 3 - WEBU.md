---
book: 1 Peter
chapter: 3
version: WEBU
---
# 1 Peter 3 (WEBU)

← [[1 Peter 2 - WEBU]] | [[1 Peter 4 - WEBU]] →

**1** In the same way, wives, be in subjection to your own husbands, so that, even if any don’t obey the Word, they may be won by the behavior of their wives without a word, ^1

**2** seeing your pure behavior in fear. ^2

**3** Let your beauty come not from the outward adorning of braiding your hair, and of wearing gold ornaments or of putting on fine clothing, ^3

**4** but from the hidden person of the heart, in the incorruptible adornment of a gentle and quiet spirit, which is very precious in God’s sight. ^4

**5** For this is how in the past the holy women who hoped in God also adorned themselves, being in subjection to their own husbands. ^5

**6** So Sarah obeyed Abraham, calling him lord, whose children you now are if you do well and are not put in fear by any terror. ^6

**7** You husbands, in the same way, live with your wives according to knowledge, giving honor to the woman as to the weaker vessel, as also being joint heirs of the grace of life, that your prayers may not be hindered. ^7

**8** Finally, all of you be like-minded, compassionate, loving as brothers, tenderhearted, courteous, ^8

**9** not rendering evil for evil or insult for insult; but instead blessing, knowing that you were called to this, that you may inherit a blessing. ^9

**10** For, “He who would love life and see good days, let him keep his tongue from evil and his lips from speaking deceit. ^10

**11** Let him turn away from evil and do good. Let him seek peace and pursue it. ^11

**12** For the eyes of the Lord are on the righteous, and his ears open to their prayer; but the face of the Lord is against those who do evil.” ^12

**13** Now who will harm you if you become imitators of that which is good? ^13

**14** But even if you should suffer for righteousness’ sake, you are blessed. “Don’t fear what they fear, neither be troubled.” ^14

**15** But sanctify the Lord God in your hearts. Always be ready to give an answer to everyone who asks you a reason concerning the hope that is in you, with humility and fear, ^15

**16** having a good conscience. Thus, while you are spoken against as evildoers, they may be disappointed who curse your good way of life in Christ. ^16

**17** For it is better, if it is God’s will, that you suffer for doing what is right than for doing evil. ^17

**18** Because Christ also suffered for sins once, the righteous for the unrighteous, that he might bring you to God, being put to death in the flesh, but made alive in the Spirit, ^18

**19** in whom he also went and preached to the spirits in prison, ^19

**20** who before were disobedient when God waited patiently in the days of Noah while the ship was being built. In it, few, that is, eight souls, were saved through water. ^20

**21** This is a symbol of baptism, which now saves you—not the putting away of the filth of the flesh, but the answer of a good conscience toward God—through the resurrection of Jesus Christ, ^21

**22** who is at the right hand of God, having gone into heaven, angels and authorities and powers being made subject to him. ^22

← [[1 Peter 2 - WEBU]] | [[1 Peter 4 - WEBU]] →
