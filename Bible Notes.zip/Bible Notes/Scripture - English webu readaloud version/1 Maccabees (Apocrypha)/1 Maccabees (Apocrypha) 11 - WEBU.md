---
book: 1 Maccabees (Apocrypha)
chapter: 11
version: WEBU
---
# 1 Maccabees (Apocrypha) 11 (WEBU)

← [[1 Maccabees (Apocrypha) 10 - WEBU]] | [[1 Maccabees (Apocrypha) 12 - WEBU]] →

**1** Then the king of Egypt gathered together great forces, as the sand which is by the sea shore, and many ships, and sought to make himself master of Alexander’s kingdom by deceit, and to add it to his own kingdom. ^1

**2** He went out into Syria with words of peace, and the people of the cities opened their gates to him and met him; for King Alexander’s command was that they should meet him, because he was his father-in-law. ^2

**3** Now as he entered into the cities of Ptolemais, he set his forces for a garrison in each city. ^3

**4** But when he came near to Azotus, they showed him the temple of Dagon burned with fire, and Azotus and its pasture lands destroyed, and the bodies cast out, and those who had been burned, whom he burned in the war, for they had made heaps of them in his way. ^4

**5** They told the king what Jonathan had done, that they might cast blame on him; but the king kept silent. ^5

**6** Jonathan met the king with pomp at Joppa, and they greeted one another, and they slept there. ^6

**7** Jonathan went with the king as far as the river that is called Eleutherus, then returned to Jerusalem. ^7

**8** But King Ptolemy took control of the cities along the sea coast, to Selucia which is by the sea, and he devised evil plans concerning Alexander. ^8

**9** He sent ambassadors to King Demetrius, saying, “Come! Let’s make a covenant with one another, and I will give you my daughter whom Alexander has, and you shall reign over your father’s kingdom; ^9

**10** for I regret that I gave my daughter to him, for he tried to kill me. ^10

**11** He accused him, because he coveted his kingdom. ^11

**12** Taking his daughter from him, he gave her to Demetrius, and was estranged from Alexander, and their enmity was openly seen. ^12

**13** Ptolemy entered into Antioch, and put on himself the crown of Asia. He put two crowns upon his head, the crown of Egypt and that of Asia. ^13

**14** But King Alexander was in Cilicia at that time, because the people of that region were in revolt. ^14

**15** When Alexander heard of it, he came against him in war. Ptolemy marched out and met him with a strong force, and put him to flight. ^15

**16** Alexander fled into Arabia, that he might be sheltered there; but King Ptolemy was triumphant. ^16

**17** Zabdiel the Arabian took off Alexander’s head, and sent it to Ptolemy. ^17

**18** King Ptolemy died the third day after, and those who were in his strongholds were slain by the inhabitants of the strongholds. ^18

**19** Demetrius became king in the one hundred sixty-seventh year. ^19

**20** In those days Jonathan gathered together the Judeans to take the citadel that was at Jerusalem. He made many engines of war to use against it. ^20

**21** Some lawless men who hated their own nation went to the king and reported to him that Jonathan was besieging the citadel. ^21

**22** He heard, and was angry, but when he heard it, he set out immediately, and came to Ptolemais, and wrote to Jonathan, that he should not besiege it, and that he should meet him and speak with him at Ptolemais with all speed. ^22

**23** But when Jonathan heard this, he gave orders to continue the siege. He chose some of the elders of Israel and of the priests, and put himself in peril ^23

**24** by taking silver, gold, clothing, and various other presents, and went to Ptolemais to the king. Then he found favor in his sight. ^24

**25** Some lawless men of those who were of the nation made complaints against him, ^25

**26** and the king did to him even as his predecessors had done to him, and exalted him in the sight of all his friends, ^26

**27** and confirmed to him the high priesthood, and all the other honors that he had before, and gave him preeminence among his chief friends. ^27

**28** And Jonathan requested of the king that he would make Judea free from tribute, along with the three provinces and the country of Samaria, and promised him three hundred talents. ^28

**29** The king consented, and wrote letters to Jonathan concerning all these things as follows: ^29

**30** “King Demetrius to his brother Jonathan, and to the nation of the Jews, greetings. ^30

**31** The copy of the letter which we wrote to Lasthenes our kinsman concerning you, we have written also to you, that you may see it. ^31

**32** ‘King Demetrius to Lasthenes his father, greetings. ^32

**33** We have determined to do good to the nation of the Jews, who are our friends, and observe what is just toward us, because of their good will toward us. ^33

**34** We have confirmed therefore to them the borders of Judea, and also the three governments of Aphaerema, Lydda, and Ramathaim (these were added to Judea from the country of Samaria), and all their territory to them, for all who do sacrifice in Jerusalem, instead of the king’s dues which the king received of them yearly before from the produce of the earth and the fruits of trees. ^34

**35** As for the other payments to us from henceforth, of the tithes and the taxes that pertain to us, and the salt pits, and the crown taxes due to us, all these we will give back to them. ^35

**36** Not one of these grants shall be annulled from this time forth and forever. ^36

**37** Now therefore be careful to make a copy of these things, and let it be given to Jonathan, and let it be set up on the holy mountain in a suitable and conspicuous place.’” ^37

**38** When King Demetrius saw that the land was quiet before him, and that no resistance was made to him, he sent away all his troops, each man to his own place, except the foreign troops, which he had raised from the islands of the Gentiles. So all the troops of his fathers hated him. ^38

**39** Now Tryphon was one of those who previously had been on Alexander’s side, and he saw that all the forces murmured against Demetrius. So he went to Imalcue the Arabian, who was raising up Antiochus the young child of Alexander, ^39

**40** and urgently insisted to him that he should deliver him to him, that he might reign in his father’s place. He told him all that Demetrius had done, and the hatred with which his forces hated him; and he stayed there many days. ^40

**41** Now Jonathan sent to King Demetrius, that he should remove the troops of the citadel from Jerusalem, and the troops who were in the strongholds; for they fought against Israel continually. ^41

**42** Demetrius sent to Jonathan, saying, “I will not only do this for you and your nation, but I will greatly honor you and your nation, if I find an opportunity. ^42

**43** Now therefore you shall do well if you send me men who will fight for me; for all my forces have revolted.” ^43

**44** So Jonathan sent him three thousand valiant men to Antioch. They came to the king, and the king was glad at their coming. ^44

**45** The people of the city gathered themselves together into the midst of the city, to the number of one hundred and twenty thousand men, and they wanted to kill the king. ^45

**46** The king fled into the court of the palace, and the people of the city seized the main streets of the city and began to fight. ^46

**47** The king called the Jews to help him, and they were gathered together to him all at once, and they dispersed themselves in the city, and killed that day about one hundred thousand. ^47

**48** They set the city on fire, and seized many spoils that day, and saved the king. ^48

**49** The people of the city saw that the Jews had taken control of the city as they pleased, and they became faint in their hearts, and they cried out to the king with supplication, saying, ^49

**50** “Give us your right hand, and let the Jews cease from fighting against us and the city.” ^50

**51** They threw away their weapons and made peace. The Jews were glorified in the sight of the king, and before all who were in his kingdom. Then they returned to Jerusalem, having much plunder. ^51

**52** So King Demetrius sat on the throne of his kingdom, and the land was quiet before him. ^52

**53** He lied in all that he spoke, and estranged himself from Jonathan, and didn’t repay him according to the benefits with which he had repaid him, and treated him very harshly. ^53

**54** Now after this, Tryphon returned, and with him the young child Antiochus, who reigned and put on a crown. ^54

**55** All the forces which Demetrius had sent away with disgrace were gathered to him, and they fought against him, and he fled and was routed. ^55

**56** Tryphon took the elephants, and took control of Antioch. ^56

**57** The young Antiochus wrote to Jonathan, saying, “I confirm to you the high priesthood, and appoint you over the four districts, and to be one of the king’s friends.” ^57

**58** He sent to him golden vessels and furniture for the table, and gave him permission to drink in golden vessels, and to be clothed in purple, and to have a golden buckle. ^58

**59** He made his brother Simon governor from the Ladder of Tyre to the borders of Egypt. ^59

**60** Jonathan went out and took his journey beyond the river and through the cities. All the forces of Syria gathered themselves to him to be his allies. He came to Ascalon, and the people of the city met him honorably. ^60

**61** He departed from there to Gaza, and the people of Gaza shut him out. So he besieged it and burned its pasture lands with fire, and plundered them. ^61

**62** The people of Gaza pleaded with Jonathan, and he gave them his right hand, and took the sons of their princes for hostages, and sent them away to Jerusalem. Then he passed through the country as far as Damascus. ^62

**63** Then Jonathan heard that Demetrius’ princes had come to Kedesh, which is in Galilee, with a great army, intending to remove him from his office. ^63

**64** He went to meet them, but he left Simon his brother in the country. ^64

**65** Simon encamped against Bethsura, and fought against it many days, and hemmed it in. ^65

**66** They asked him to give them his right hand, and he gave it to them. He removed them from there, took possession of the city, and set a garrison over it. ^66

**67** Jonathan and his army encamped at the water of Gennesareth, and early in the morning they marched to the plain of Hazor. ^67

**68** Behold, an army of foreigners met him in the plain. They laid an ambush for him in the mountains, but they themselves met him face to face. ^68

**69** But those who lay in ambush rose out of their places and joined battle. All those who were on Jonathan’s side fled. ^69

**70** Not one of them was left, except Mattathias the son of Absalom, and Judas the son of Chalphi, captains of the forces. ^70

**71** Jonathan tore his clothes, put dirt on his head, and prayed. ^71

**72** He turned again to them in battle, and routed them, and they fled. ^72

**73** When the men on his side who had fled saw this, they returned to him and pursued with him to Kedesh to their camp, and they encamped there. ^73

**74** About three thousand men of the foreigners fell on that day. Then Jonathan returned to Jerusalem. ^74

← [[1 Maccabees (Apocrypha) 10 - WEBU]] | [[1 Maccabees (Apocrypha) 12 - WEBU]] →
