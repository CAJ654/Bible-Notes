---
book: 1 Maccabees (Apocrypha)
chapter: 14
version: WEBU
---
# 1 Maccabees (Apocrypha) 14 (WEBU)

← [[1 Maccabees (Apocrypha) 13 - WEBU]] | [[1 Maccabees (Apocrypha) 15 - WEBU]] →

**1** In the one hundred seventy-second year, King Demetrius gathered his forces together, and went into Media to get help, that he might fight against Tryphon. ^1

**2** When Arsaces, the king of Persia and Media, heard that Demetrius had come into his borders, he sent one of his princes to take him alive. ^2

**3** He went and struck the army of Demetrius, and seized him and brought him to Arsaces, who put him under guard. ^3

**4** The land had rest all the days of Simon. He sought the good of his nation. His authority and his honor was pleasing to them all his days. ^4

**5** Amid all his honors, he took Joppa for a harbor, and made it an entrance for the islands of the sea. ^5

**6** He enlarged the borders of his nation and took possession of the country. ^6

**7** He gathered together a great number of captives, and took control of Gazara, Bethsura, and the citadel, and he removed its uncleannesses from it. There was no one who resisted him. ^7

**8** They tilled their land in peace, and the land gave her increase, and the trees of the plains gave their fruit. ^8

**9** The old men sat in the streets; they all conversed together about good things. The young men put on glorious and warlike apparel. ^9

**10** He provided food for the cities and furnished them with means of defense, until the glory of his name was known to the end of the earth. ^10

**11** He made peace in the land, and Israel rejoiced with great joy. ^11

**12** Each man sat under his vine and his fig tree, and there was no one to make them afraid. ^12

**13** No one was left in the land who fought against them. The kings were defeated in those days. ^13

**14** He strengthened all those of his people who were humble. He searched out the law, and every lawless and wicked person he took away. ^14

**15** He glorified the sanctuary, and added to the vessels of the temple. ^15

**16** It was heard at Rome that Jonathan was dead, and even in Sparta, and they were exceedingly grieved. ^16

**17** But as soon as they heard that his brother Simon was made high priest in his place, and ruled the country and the cities in it, ^17

**18** they wrote to him on brass tablets to renew with him the friendship and the alliance which they had confirmed with his brothers Judas and Jonathan. ^18

**19** These were read before the congregation at Jerusalem. ^19

**20** This is the copy of the letter which the Spartans sent: “The rulers and the city of the Spartans, to Simon the high priest, to the elders, the priests, and the rest of the people of the Jews, our kindred, greetings. ^20

**21** The ambassadors who were sent to our people reported to us about your glory and honor. We were glad for their coming, ^21

**22** and we registered the things that were spoken by them in the public records as follows: ‘Numenius son of Antiochus, and Antipater son of Jason, the Jews’ ambassadors, came to us to renew the friendship they had with us. ^22

**23** It pleased the people to entertain the men honorably, and to put the copy of their words in the public records, to the end that the people of the Spartans might have a record of them. Moreover they wrote a copy of these things to Simon the high priest.’” ^23

**24** After this, Simon sent Numenius to Rome with a great shield of gold weighing one thousand minas, in order to confirm the alliance with them. ^24

**25** But when the people heard these things, they said, “What thanks shall we give to Simon and his sons? ^25

**26** For he and his brothers and the house of his father have made themselves strong, and have fought and chased away Israel’s enemies, and confirmed liberty to Israel.” ^26

**27** So they wrote on tablets of brass, and set them on pillars on mount Zion. This is the copy of the writing: “On the eighteenth day of Elul, in the one hundred seventy-second year, which is the third year of Simon the high priest, ^27

**28** in Asaramel, in a great congregation of priests and people and princes of the nation, and of the elders of the country, it was proclaimed to us: ^28

**29** ‘Since wars often occurred in the country, Simon the son of Mattathias, the son of the sons of Joarib, and his brothers, put themselves in jeopardy and withstood the enemies of their nation, that their sanctuary and the law might be established, and glorified their nation with great glory. ^29

**30** Jonathan rallied the nation, became their high priest, and was gathered to his people. ^30

**31** Their enemies planned to invade their country, that they might destroy their country utterly, and stretch out their hands against their sanctuary. ^31

**32** Then Simon rose up and fought for his nation. He spent much of his own money to arm the valiant men of his nation and give them wages. ^32

**33** He fortified the cities of Judea and Bethsura that lies on the borders of Judea, where the weapons of the enemies had been stored, and there he placed a garrison of Jews. ^33

**34** He fortified Joppa which is upon the sea, and Gazara which is upon the borders of Azotus, where the enemies used to live, and placed Jews there, and set in there all things necessary for their restoration. ^34

**35** The people saw Simon’s faith, and the glory which he resolved to bring to his nation, and they made him their leader and high priest, because he had done all these things, and for the justice and the faith which he kept to his nation, and because he sought by all means to exalt his people. ^35

**36** In his days, things prospered in his hands, so that the Gentiles were taken away out of their country, and they also who were in the city of David, those who were in Jerusalem, who had made themselves a citadel, out of which they used to go, and polluted everything around the sanctuary, and did great damage to its purity. ^36

**37** He placed Jews in it and fortified it for the safety of the country and the city, and made high the walls of Jerusalem. ^37

**38** King Demetrius confirmed to him the high priesthood according to these things, ^38

**39** and made him one of his friends, and honored him with great honor; ^39

**40** for he had heard that the Jews had been called by the Romans friends, allies, and kindred, and that they had met the ambassadors of Simon honorably; ^40

**41** and that the Jews and the priests were well pleased that Simon should be their leader and high priest forever, until there should arise a faithful prophet; ^41

**42** and that he should be governor over them, and should take charge of the sanctuary, to set them over their works, and over the country, and over the weapons, and over the strongholds; and that he should take charge of the sanctuary, ^42

**43** and that he should be obeyed by all, and that all contracts in the country should be written in his name, and that he should be clothed in purple, and wear gold; ^43

**44** and that it should not be lawful for any of the people or of the priests to nullify any of these things, or to oppose the words that he should speak, or to gather an assembly in the country without him, or to be clothed in purple, or wear a buckle of gold; ^44

**45** but whoever should do otherwise, or nullify any of these things, he will be liable to punishment.’” ^45

**46** All the people consented to ordain for Simon that he should do according to these words. ^46

**47** So Simon accepted this, and consented to be high priest, and to be captain and governor of the Jews and of the priests, and to be protector of all. ^47

**48** They commanded to put this writing on tablets of brass, and to set them up within the precinct of the sanctuary in a conspicuous place, ^48

**49** and moreover to put copies of them in the treasury, so that Simon and his sons might have them. ^49

← [[1 Maccabees (Apocrypha) 13 - WEBU]] | [[1 Maccabees (Apocrypha) 15 - WEBU]] →
