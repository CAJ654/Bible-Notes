---
book: 1 Maccabees (Apocrypha)
chapter: 1
version: WEBU
---
# 1 Maccabees (Apocrypha) 1 (WEBU)

[[1 Maccabees (Apocrypha) 2 - WEBU]] →

**1** After Alexander the Macedonian, the son of Philip, who came out of the land of Chittim, and struck Darius king of the Persians and Medes, it came to pass, after he had struck him, that he reigned in his place, in former time, over Greece. ^1

**2** He fought many battles, won many strongholds, killed the kings of the earth, ^2

**3** went through to the ends of the earth, and took spoils of a multitude of nations. The earth was quiet before him. He was exalted. His heart was lifted up. ^3

**4** He gathered together an exceedingly strong army and ruled over countries, nations, and principalities, and they paid him tribute. ^4

**5** After these things he fell sick, and perceived that he was going to die. ^5

**6** He called his honorable servants, which had been brought up with him from his youth, and he divided to them his kingdom while he was still alive. ^6

**7** Alexander reigned twelve years, then he died. ^7

**8** Then his servants ruled, each one in his place. ^8

**9** They all put crowns upon themselves after he was dead, and so did their sons after them many years; and they multiplied evils on the earth. ^9

**10** There came out of them a sinful root, Antiochus Epiphanes, son of Antiochus the king, who had been a hostage at Rome, and he reigned in the one hundred thirty seventh year of the kingdom of the Greeks. ^10

**11** In those days transgressors of the law came out of Israel and persuaded many, saying, “Let’s go make a covenant with the Gentiles around us; for since we were separated from them many evils have befallen us.” ^11

**12** That proposal was good in their eyes. ^12

**13** Some of the people eagerly went to the king, and he authorized them to observe the ordinances of the Gentiles. ^13

**14** So they built a gymnasium in Jerusalem according to the laws of the Gentiles. ^14

**15** They made themselves uncircumcised, forsook the holy covenant, joined themselves to the Gentiles, and sold themselves to do evil. ^15

**16** The kingdom was established in the sight of Antiochus, and he planned to reign over Egypt, that he might reign over both kingdoms. ^16

**17** He entered into Egypt with a great multitude, with chariots, with elephants, with cavalry, and with a great navy. ^17

**18** He made war against Ptolemy king of Egypt. Ptolemy was put to shame before him, and fled; and many fell wounded to death. ^18

**19** They took possession of the strong cities in the land of Egypt, and he took the spoils of Egypt. ^19

**20** Antiochus, after he had defeated Egypt, returned in the one hundred forty third year, and went up against Israel and Jerusalem with a great multitude, ^20

**21** and entered presumptuously into the sanctuary, and took the golden altar, the lampstand for the light, and all its utensils. ^21

**22** He took the table of the show bread, the cups for the drink offerings, the bowls, the golden censers, the veil, the crowns, and the gold decoration on the front of the temple. He peeled it all off. ^22

**23** He took the silver, the gold, and the precious vessels. He took the hidden treasures which he found. ^23

**24** When he had taken all of these, he went away into his own land. He made a great slaughter, and spoke very arrogantly. ^24

**25** Great mourning came upon Israel, in every place where they were. ^25

**26** The rulers and elders groaned. The virgins and young men were made feeble. The beauty of the women was changed. ^26

**27** Every bridegroom took up lamentation. She who sat in the marriage chamber was mourning. ^27

**28** The land was moved for its inhabitants, and all the house of Jacob was clothed with shame. ^28

**29** After two full years, the king sent a chief collector of tribute to the cities of Judah, and he came to Jerusalem with a great multitude. ^29

**30** He spoke words of peace to them in subtlety, and they believed him. Then he fell upon the city suddenly, struck it very severely, and destroyed many people of Israel. ^30

**31** He took the spoils of the city, set it on fire, and pulled down its houses and its walls on every side. ^31

**32** They led captive the women and the children, and seized the livestock. ^32

**33** Then they fortified the city of David with a large, strong wall and with strong towers, and it became their citadel. ^33

**34** They put a sinful nation, transgressors of the law, there, and they strengthened themselves in it. ^34

**35** They stored up weapons and food, and gathering together the spoils of Jerusalem, they stored them there, and they became a great menace. ^35

**36** It became a place to lie in wait against the sanctuary, and an evil adversary to Israel continually. ^36

**37** They shed innocent blood on every side of the sanctuary, and defiled the sanctuary. ^37

**38** The inhabitants of Jerusalem fled because of them. She became a habitation of foreigners. She became foreign to those who were born in her, and her children forsook her. ^38

**39** Her sanctuary was laid waste like a wilderness, her feasts were turned into mourning, her Sabbaths into reproach, and her honor into contempt. ^39

**40** According to her glory, so was her dishonor multiplied, and her exaltation was turned into mourning. ^40

**41** King Antiochus wrote to his whole kingdom that all should be one people, ^41

**42** and that each should forsake his own laws. All the nations agreed according to the word of the king. ^42

**43** Many of Israel consented to his worship, sacrificed to the idols, and profaned the Sabbath. ^43

**44** The king sent letters by the hand of messengers to Jerusalem and the cities of Judah, that they should follow laws strange to the land, ^44

**45** and should forbid whole burnt offerings and sacrifice and drink offerings in the sanctuary; and should profane the Sabbaths and feasts, ^45

**46** and pollute the sanctuary and those who were holy; ^46

**47** that they should build altars, and temples, and shrines for idols, and should sacrifice swine’s flesh and unclean animals; ^47

**48** and that they should leave their sons uncircumcised, that they should make their souls abominable with all manner of uncleanness and profanation; ^48

**49** so that they might forget the law, and change all the ordinances. ^49

**50** Whoever doesn’t do according to the word of the king, he shall die. ^50

**51** He wrote according to all these words to his whole kingdom. He appointed overseers over all the people, and he commanded the cities of Judah to sacrifice, city by city. ^51

**52** From the people were gathered together to them many, everyone who had forsaken the law; and they did evil things in the land. ^52

**53** They made Israel hide themselves in every place of refuge which they had. ^53

**54** On the fifteenth day of Chislev, in the one hundred forty fifth year, they built an abomination of desolation upon the altar, and in the cities of Judah on every side they built idol altars. ^54

**55** At the doors of the houses and in the streets they burned incense. ^55

**56** They tore up the books of the law which they found and set them on fire. ^56

**57** Anyone who was found with any book of the covenant, and if any consented to the law, the king’s sentence delivered him to death. ^57

**58** Thus did they in their might to Israel, to those who were found month by month in the cities. ^58

**59** On the twenty-fifth day of the month they sacrificed upon the idol altar that was on top of the altar of burnt offering. ^59

**60** They put to death women who had circumcised their children, according to the commandment. ^60

**61** They hung their babies around their necks, and their houses, and those who had circumcised them. ^61

**62** Many in Israel were fully resolved and confirmed in themselves not to eat unclean things. ^62

**63** They chose to die, that they might not be defiled with the food, and that they might not profane the holy covenant; and they died. ^63

**64** Exceedingly great wrath came upon Israel. ^64

[[1 Maccabees (Apocrypha) 2 - WEBU]] →
