---
book: 1 Maccabees (Apocrypha)
chapter: 3
version: WEBU
---
# 1 Maccabees (Apocrypha) 3 (WEBU)

← [[1 Maccabees (Apocrypha) 2 - WEBU]] | [[1 Maccabees (Apocrypha) 4 - WEBU]] →

**1** His son Judas, who was called Maccabaeus, rose up in his place. ^1

**2** All his kindred helped him, and so did all those who joined with his father, and they fought with gladness the battle of Israel. ^2

**3** He got his people great glory, and put on a breastplate like a giant, and bound his warlike harness around him, and set battles in array, protecting the army with his sword. ^3

**4** He was like a lion in his deeds, and like a lion’s cub roaring for prey. ^4

**5** He hunted and pursued the lawless, and he burned up those who troubled his people. ^5

**6** The lawless shrunk back for fear of him, and all the workers of lawlessness were very troubled, and deliverance prospered in his hand. ^6

**7** He angered many kings and made Jacob glad with his acts. His memory is blessed forever. ^7

**8** He went through the cities of Judah, destroyed the ungodly out of the land, and turned away wrath from Israel. ^8

**9** He was renowned to the utmost part of the earth. He gathered together those who were ready to perish. ^9

**10** Apollonius gathered the Gentiles together with a great army from Samaria to fight against Israel. ^10

**11** Judas learned of it, and he went out to meet him, struck him, and killed him. Many fell wounded to death, and the rest fled. ^11

**12** They took their spoils, and Judas took Apollonius’ sword, and he fought with it all his days. ^12

**13** Seron, the commander of the army of Syria, heard that Judas had gathered a large company, including a body of faithful men who stayed with him, went out to war. ^13

**14** He said, “I will make myself a name and get myself glory in the kingdom. I will fight against Judas and those who are with him, who despise the king’s command. ^14

**15** A mighty army of the ungodly went up with him to help him, to take vengeance on the children of Israel. ^15

**16** He came near to the ascent of Bethhoron, and Judas went out to meet him with a small company. ^16

**17** But when they saw the army coming to meet them, they said to Judas, “What? Shall we be able, being a small company, to fight against so great and strong a multitude? We for our part are faint, having tasted no food this day.” ^17

**18** Judas said, “It is an easy thing for many to be hemmed in by the hands of a few. With heaven it is all one, to save by many or by few; ^18

**19** for victory in battle stands not in the multitude of an army, but strength is from heaven. ^19

**20** They come to us in fullness of insolence and lawlessness, to destroy us and our wives and our children, and to plunder us, ^20

**21** but we fight for our lives and our laws. ^21

**22** He himself will crush them before our face; but as for you, don’t be afraid of them. ^22

**23** Now when he had finished speaking, he rushed suddenly against Seron and his army, and they were defeated before him. ^23

**24** They pursued them down the descent of Bethhoron to the plain, and about eight hundred men of them fell; but the rest fled into the land of the Philistines. ^24

**25** The fear of Judas and his kindred, and the dread of them, began to fall on the nations around them. ^25

**26** His fame reached the king, and every nation told of the battles of Judas. ^26

**27** But when King Antiochus heard these words, he was full of indignation; and he sent and gathered together all the forces of his realm, an exceedingly strong army. ^27

**28** He opened his treasury and gave his forces pay for a year, and commanded them to be ready for every need. ^28

**29** He saw that the money was gone from his treasures, and that the tributes of the country were small, because of the dissension and disaster which he had brought upon the land, to the end that he might take away the laws which had been from the first days. ^29

**30** He was afraid that he wouldn’t have enough as at other times for the charges and the gifts which he used to give with a liberal hand, more abundantly than the kings who were before him. ^30

**31** And he was exceedingly perplexed in his mind, and he determined to go into Persia, and to take the tributes of those countries, and to gather much money. ^31

**32** He left Lysias, an honorable man, and one of royal lineage, to be over the affairs of the king from the river Euphrates to the borders of Egypt, ^32

**33** and to bring up his son Antiochus, until he came again. ^33

**34** He delivered to Lysias half of his forces and the elephants, and gave him charge of all the things that he would have done, and concerning those who lived in Judea and in Jerusalem, ^34

**35** that he should send an army against them to root out and destroy the strength of Israel and the remnant of Jerusalem, and to take away their memory from the place, ^35

**36** and that he should make foreigners live in all their territory, and should divide their land to them by lot. ^36

**37** The king took the half that remained of the forces, and left Antioch, his royal city, in the one hundred forty seventh year; and he passed over the river Euphrates, and went through the upper countries. ^37

**38** Lysias chose Ptolemy the son of Dorymenes, Nicanor, and Gorgias, mighty men of the king’s friends; ^38

**39** and with them, he sent forty thousand infantry and seven thousand cavalry to go into the land of Judah and to destroy it, according to the word of the king. ^39

**40** They set out with all their army, and came and encamped near Emmaus in the plain country. ^40

**41** The merchants of the country heard of their fame, and took silver and gold in large quantities, and fetters, and came into the camp to take the children of Israel for slaves. Forces of Syria and of the land of the Philistines joined with them. ^41

**42** Judas and his kindred saw that evils were multiplied, and that the forces were encamping in their borders. They learned about the king’s words which he had commanded, to destroy the people and make an end of them. ^42

**43** Then they each said to his neighbor, “Let’s repair the ruins of our people. Let’s fight for our people and the holy place.” ^43

**44** The congregation was gathered together, that they might be ready for battle, and that they might pray and ask for mercy and compassion. ^44

**45** Jerusalem was without inhabitant like a wilderness. There was none of her offspring who went in or went out. The sanctuary was trampled down. Children of foreigners were in the citadel. The Gentiles lived there. Joy was taken away from Jacob, and the pipe and the harp ceased. ^45

**46** They gathered themselves together, and came to Mizpeh, near Jerusalem; for in Mizpeh there used to be a place of prayer for Israel. ^46

**47** They fasted that day, put on sackcloth, put ashes on their heads, tore their clothes, ^47

**48** and opened the book of the law, to learn about the things for which the Gentiles consulted the images of their idols. ^48

**49** They brought the priests’ garments, the first fruits, and the tithes. They stirred up the Nazarites, who had accomplished their days. ^49

**50** They cried aloud toward heaven, saying, “What should we do with these men? Where should we carry them away? ^50

**51** Your holy place is trampled down and profaned. Your priests mourn in humiliation. ^51

**52** Behold, the Gentiles are assembled together against us to destroy us. You know what things they imagine against us. ^52

**53** How will we be able to stand against them, unless you help us?” ^53

**54** They sounded with the trumpets, and gave a loud shout. ^54

**55** And after this Judas appointed leaders of the people: captains of thousands, captains of hundreds, captains of fifties, and captains of tens. ^55

**56** He said to those who were building houses, were betrothing wives, were planting vineyards, and were fearful, that they should return, each man to his own house, according to the law. ^56

**57** The army marched out and encamped upon the south side of Emmaus. ^57

**58** Judas said, “Arm yourselves and be valiant men! Be ready in the morning to fight with these Gentiles who are assembled together against us to destroy us and our holy place. ^58

**59** For it is better for us to die in battle than to see the calamities of our nation and the holy place. ^59

**60** Nevertheless, as may be the will in heaven, so shall he do. ^60

← [[1 Maccabees (Apocrypha) 2 - WEBU]] | [[1 Maccabees (Apocrypha) 4 - WEBU]] →
