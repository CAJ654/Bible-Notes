---
book: 1 Maccabees (Apocrypha)
chapter: 7
version: WEBU
---
# 1 Maccabees (Apocrypha) 7 (WEBU)

← [[1 Maccabees (Apocrypha) 6 - WEBU]] | [[1 Maccabees (Apocrypha) 8 - WEBU]] →

**1** In the one hundred fifty first year, Demetrius the son of Seleucus came out of Rome, and went up with a few men to a city by the sea, and reigned there. ^1

**2** It came to pass, when he would go into the house of the kingdom of his fathers, that the army laid hands on Antiochus and Lysias, to bring them to him. ^2

**3** The thing became known to him, and he said, “Don’t show me their faces!” ^3

**4** So the army killed them. Then Demetrius sat upon the throne of his kingdom. ^4

**5** All the lawless and ungodly men of Israel came to him. Alcimus was their leader, desiring to be high priest. ^5

**6** They accused the people to the king, saying, “Judas and his kindred have destroyed all your friends, and have scattered us from our own land. ^6

**7** Now therefore send a man whom you trust, and let him go and see all the destruction which he has brought on us and the king’s country, and how he has punished them and all who helped them.” ^7

**8** So the king chose Bacchides, one of the king’s friends, who was ruler in the country beyond the river, and was a great man in the kingdom, and faithful to the king. ^8

**9** He sent him and that ungodly Alcimus, whom he made the high priest; and he commanded him to take vengeance upon the children of Israel. ^9

**10** They marched away and came with a great army into the land of Judah. He sent messengers to Judas and his kindred with words of peace deceitfully. ^10

**11** They paid no attention to their words; for they saw that they had come with a great army. ^11

**12** A group of scribes gathered together to Alcimus and Bacchides to seek just terms. ^12

**13** The Hasidaeans were the first among the children of Israel who sought peace from them, ^13

**14** for they said, “One who is a priest of the seed of Aaron has come with the army, and he will do us no wrong.” ^14

**15** He spoke with them words of peace, and swore to them, saying, “We won’t seek to harm you or your friends.” ^15

**16** They trusted him. Then he seized sixty men of them, and killed them in one day, according to the word which was written, ^16

**17** The flesh of your saints and their blood was shed all around Jerusalem, and there was no one to bury them. ^17

**18** The fear and the dread of them fell upon all the people, for they said, “There is neither truth nor justice in them; for they have broken the covenant and the oath which they swore.” ^18

**19** Bacchides withdrew from Jerusalem, and encamped in Bezeth. He sent and seized many of the deserters who were with him, and some of the people, and he killed them, throwing them into a large pit. ^19

**20** He placed Alcimus in charge of the country and left with him a force to aid him. Then Bacchides went away to the king. ^20

**21** Alcimus struggled to maintain his high priesthood. ^21

**22** All those who troubled their people joined him, and they took control of the land of Judah, and did great damage in Israel. ^22

**23** Judas saw all the wrongs that Alcimus and his company had done among the children of Israel, even more than the Gentiles. ^23

**24** He went out into all the borders of Judea and took vengeance on the men who had deserted from him, and they were restrained from going out into the country. ^24

**25** But when Alcimus saw that Judas and his company had grown strong, and knew that he was not able to withstand them, he returned to the king, and brought evil accusations against them. ^25

**26** Then the king sent Nicanor, one of his honorable princes, a man who hated Israel and was their enemy, and commanded him to destroy the people. ^26

**27** Nicanor came to Jerusalem with a great army. He sent to Judas and his kindred deceitfully with words of peace, saying, ^27

**28** “Let there be no battle between me and you; I will come with a few men, that I may see your faces in peace.” ^28

**29** He came to Judas, and they saluted one another peaceably. The enemies were ready to seize Judas by violence. ^29

**30** This was known to Judas, that he came to him with deceit, and he was very afraid of him, and would see his face no more. ^30

**31** Nicanor found out that his plan was disclosed; and he went out to meet Judas in battle beside Capharsalama. ^31

**32** About five hundred men of Nicanor’s army fell, and the rest fled into the city of David. ^32

**33** After these things, Nicanor went up to mount Zion. Some of the priests came out of the sanctuary, with some of the elders of the people, to salute him peaceably, and to show him the whole burned sacrifice that was being offered for the king. ^33

**34** He mocked them, laughed at them, derided them shamefully, spoke arrogantly, ^34

**35** and swore in a rage, saying, “Unless Judas and his army are now delivered into my hands, it shall be that, if I return safely, I will burn up this house!” And he went out in a great rage. ^35

**36** The priests entered in, and stood before the altar and the temple; and they wept, and said, ^36

**37** “You chose this house to be called by your name, to be a house of prayer and supplication for your people. ^37

**38** Take vengeance on this man and his army, and let them fall by the sword. Remember their blasphemies, and don’t allow them to live any longer.” ^38

**39** Then Nicanor went out from Jerusalem and encamped in Bethhoron, and there the Syrian army met him. ^39

**40** Judas encamped in Adasa with three thousand men. Judas prayed and said, ^40

**41** “When those who came from the king blasphemed, your angel went out, and struck among them one hundred eighty-five thousand. ^41

**42** Even so, crush this army before us today, and let all the rest know that he has spoken wickedly against your sanctuary. Judge him according to his wickedness.” ^42

**43** On the thirteenth day of the month Adar, the armies met in battle. Nicanor’s army was defeated, and he himself was the first to fall in the battle. ^43

**44** Now when his army saw that Nicanor had fallen, they threw away their weapons and fled. ^44

**45** They pursued them a day’s journey from Adasa until you come to Gazara, and they sounded an alarm after them with the signal trumpets. ^45

**46** Men came out of all the surrounding villages of Judea, and outflanked them. These turned them back on those, and they all fell by the sword. There wasn’t one of them left. ^46

**47** The Jews took the spoils and the booty, and they cut off Nicanor’s head and his right hand, which he had stretched out so arrogantly, and brought them, and hung them up beside Jerusalem. ^47

**48** The people were exceedingly glad, and they kept that day as a day of great gladness. ^48

**49** They ordained to keep this day year by year on the thirteenth day of Adar. ^49

**50** So the land of Judah had rest a few days. ^50

← [[1 Maccabees (Apocrypha) 6 - WEBU]] | [[1 Maccabees (Apocrypha) 8 - WEBU]] →
