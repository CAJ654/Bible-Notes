---
book: 1 Maccabees (Apocrypha)
chapter: 5
version: WEBU
---
# 1 Maccabees (Apocrypha) 5 (WEBU)

← [[1 Maccabees (Apocrypha) 4 - WEBU]] | [[1 Maccabees (Apocrypha) 6 - WEBU]] →

**1** It came to pass, when the Gentiles all around heard that the altar had been rebuilt and the sanctuary dedicated as before, they were exceedingly angry. ^1

**2** They took counsel to destroy the race of Jacob that was in the midst of them, and they began to kill and destroy among the people. ^2

**3** Judas fought against the children of Esau in Idumaea at Akrabattine, because they besieged Israel. He struck them with a great slaughter, humbled them, and took their spoils. ^3

**4** He remembered the wickedness of the children of Baean, who were a snare and a stumbling block to the people, lying in wait for them on the highways. ^4

**5** They were shut up by him in the towers. He encamped against them, and destroyed them utterly, and burned with fire the towers of the place with all who were in them. ^5

**6** He passed over to the children of Ammon, and found a mighty band and many people, with Timotheus for their leader. ^6

**7** He fought many battles with them, and they were defeated before his face. He struck them, ^7

**8** and took possession of Jazer and its villages, and returned again into Judea. ^8

**9** The Gentiles who were in Gilead gathered themselves together against the Israelites who were on their borders, to destroy them. They fled to the stronghold of Dathema, ^9

**10** and sent letters to Judas and his kindred, saying, “The Gentiles who are around us are gathered together against us to destroy us. ^10

**11** They are preparing to come and get possession of the stronghold where we fled for refuge, and Timotheus is the leader of their army. ^11

**12** Now therefore come and deliver us from their hand, for many of us have fallen. ^12

**13** All our kindred who were in the land of Tubias have been put to death. They have carried their wives, their children, and their stuff into captivity. They destroyed about a thousand men there.” ^13

**14** While the letters were still being read, behold, other messengers came from Galilee with their clothes torn, bringing a similar report, ^14

**15** saying, “People of Ptolemais, of Tyre, of Sidon, and all Galilee of the Gentiles have gathered together to destroy us.” ^15

**16** Now when Judas and the people heard these words, a great congregation assembled together to determine what they should do for their kindred who were in distress and under attack. ^16

**17** Judas said to Simon his brother, “Choose men and go deliver your kindred who are in Galilee, but Jonathan my brother and I will go into the land of Gilead.” ^17

**18** He left Joseph the son of Zacharias, and Azarias, as leaders of the people, with the remnant of the army, in Judea, to guard it. ^18

**19** He commanded them, saying, “Take charge of this people, and fight no battle with the Gentiles until we return.” ^19

**20** Then three thousand men were assigned to go into Galilee with Simon, but eight thousand men were assigned to Judas to go into the land of Gilead. ^20

**21** Simon went into Galilee and fought many battles with the Gentiles, and the Gentiles were defeated before him. ^21

**22** He pursued them to the gate of Ptolemais. About three thousand men of the Gentiles fell, and he took their spoils. ^22

**23** They took to them those who were in Galilee and in Arbatta, with their wives, their children, and all that they had, and brought them into Judea with great gladness. ^23

**24** Judas Maccabaeus and his brother Jonathan passed over the Jordan, and went three days’ journey in the wilderness. ^24

**25** They met with the Nabathaeans, and these met them in a peaceful manner and told them all things that had happened to their kindred in the land of Gilead, ^25

**26** and how many of them were shut up in Bosora, Bosor, Alema, Casphor, Maked, and Carnaim—all these cities are strong and large— ^26

**27** and how they were shut up in the rest of the cities of the land of Gilead, and that tomorrow they planned to encamp against the strongholds, and to take them, and to destroy all these men in one day. ^27

**28** Judas and his army turned suddenly by the way of the wilderness to Bosora; and he took the city, and killed all the males with the edge of the sword, took all their spoils, and burned the city with fire. ^28

**29** He left there at night, and went until he came to the stronghold. ^29

**30** When the morning came, they lifted up their eyes and saw many people who couldn’t be counted, bearing ladders and engines of war, to take the stronghold; and they were fighting against them. ^30

**31** Judas saw that the battle had begun, and that the cry of the city went up to heaven, with trumpets and a great sound, ^31

**32** and he said to the men of his army, “Fight today for your kindred!” ^32

**33** Then he went out behind them in three companies. They sounded with their trumpets and cried out in prayer. ^33

**34** And the army of Timotheus perceived that it was Maccabaeus, and they fled from before him. He struck them with a great slaughter. About eight thousand men of them fell on that day. ^34

**35** He turned away to Mizpeh and fought against it, took it, killed all its males, took its spoils, and burned it with fire. ^35

**36** From there he marched and took Casphor, Maked, Bosor, and the other cities of the land of Gilead. ^36

**37** Now after these things, Timotheus gathered another army and encamped near Raphon beyond the brook. ^37

**38** Judas sent men to spy on the army; and they brought him word, saying, “All the Gentiles who are around us are gathered together to them, an exceedingly great army. ^38

**39** They have hired Arabians to help them, and are encamped beyond the brook, ready to come against you to battle.” So Judas went to meet them. ^39

**40** Timotheus said to the captains of his army when Judas and his army drew near to the brook of water, “If he crosses over to us first, we won’t be able to withstand him, for he will certainly defeat us; ^40

**41** but if he is afraid, and encamps beyond the river, we will cross over to him, and defeat him.” ^41

**42** Now when Judas came near to the water brook, he caused the scribes of the people to remain by the brook, and commanded them, saying, “Allow no man to encamp, but let all come to the battle.” ^42

**43** Then he crossed over against them first, and all the people after him; and all the Gentiles were defeated before his face, and threw away their weapons, and fled to the temple at Carnaim. ^43

**44** They took the city and burned the temple with fire, together with all who were in it. Carnaim was subdued. They couldn’t stand any longer before the face of Judas. ^44

**45** Judas gathered together all Israel, those who were in the land of Gilead, from the least to the greatest, with their wives, their children, and their stuff, an exceedingly great army, that they might come into the land of Judah. ^45

**46** They came as far as Ephron, and this same city was large and very strong. It was on the road where they were going. They couldn’t turn away from it on the right hand or on the left, but needed to pass through the middle of it. ^46

**47** The people of the city shut them out and blocked the gates with stones. ^47

**48** Judas sent to them with words of peace, saying, “We will pass through your land to go into our own land, and no one will harm you. We will only pass by on our feet.” But they wouldn’t open to him. ^48

**49** Then Judas commanded proclamation to be made in the army, that each man should encamp in the place where he was. ^49

**50** So the men of the army encamped, and fought against the city all that day and all that night, and the city was delivered into his hands. ^50

**51** He destroyed all the males with the edge of the sword, razed the city, took its plunder, and passed through the city over those who were slain. ^51

**52** They went over the Jordan into the great plain near Bethshan. ^52

**53** And Judas gathered together those who lagged behind and encouraged the people all the way through, until he came into the land of Judah. ^53

**54** They went up to mount Zion with gladness and joy, and offered whole burnt offerings, because not so much as one of them was slain until they returned in peace. ^54

**55** In the days when Judas and Jonathan were in the land of Gilead, and Simon his brother in Galilee before Ptolemais, ^55

**56** Joseph the son of Zacharias, and Azarias, rulers of the army, heard of their exploits and of the war, and what things they had done. ^56

**57** They said, “Let’s also get us a name, and let’s go fight against the Gentiles who are around us.” ^57

**58** So they gave orders to the men of the army that was with them, and went toward Jamnia. ^58

**59** Gorgias and his men came out of the city to meet them in battle. ^59

**60** Joseph and Azarias were put to flight, and were pursued to the borders of Judea. About two thousand men of Israel fell on that day. ^60

**61** There was a great overthrow among the people, because they didn’t listen to Judas and his kindred, thinking to do some exploit. ^61

**62** But they were not of the family of those men by whose hand deliverance was given to Israel. ^62

**63** The man Judas and his kindred were glorified exceedingly in the sight of all Israel, and of all the Gentiles, wherever their name was heard of. ^63

**64** Men gathered together to them, acclaiming them. ^64

**65** Judas and his kindred went out and fought against the children of Esau in the land toward the south. He struck Hebron and its villages, pulled down its strongholds, and burned its towers all around. ^65

**66** He marched to go into the land of the Philistines, and he went through Samaria. ^66

**67** In that day certain priests, desiring to do exploits there, were slain in battle, when they went out to battle unadvisedly. ^67

**68** But Judas turned toward Azotus, to the land of the Philistines, pulled down their altars, burned the carved images of their gods with fire, took the plunder of their cities, and returned into the land of Judah. ^68

← [[1 Maccabees (Apocrypha) 4 - WEBU]] | [[1 Maccabees (Apocrypha) 6 - WEBU]] →
