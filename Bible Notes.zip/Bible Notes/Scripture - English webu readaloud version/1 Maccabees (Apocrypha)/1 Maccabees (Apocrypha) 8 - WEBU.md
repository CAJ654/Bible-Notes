---
book: 1 Maccabees (Apocrypha)
chapter: 8
version: WEBU
---
# 1 Maccabees (Apocrypha) 8 (WEBU)

← [[1 Maccabees (Apocrypha) 7 - WEBU]] | [[1 Maccabees (Apocrypha) 9 - WEBU]] →

**1** Judas heard of the fame of the Romans, that they are valiant men, and have pleasure in all who join themselves to them, and make friends with all who come to them, ^1

**2** and that they are valiant men. They told him of their wars and exploits which they do among the Gauls, and how they conquered them, and forced them to pay tribute; ^2

**3** and what things they did in the land of Spain, that they might take control of the silver and gold mines which were there; ^3

**4** and how by their policy and persistence they conquered all the place (and the place was exceedingly far from them), and the kings who came against them from the uttermost part of the earth, until they had defeated them, and struck them severely; and how the rest give them tribute year by year. ^4

**5** Philip, and Perseus, king of Chittim, and those who lifted up themselves against them, they defeated in battle, and conquered them. ^5

**6** Antiochus also, the great king of Asia, came against them to battle, having one hundred twenty elephants, with cavalry, chariots, and an exceedingly great army, and he was defeated by them. ^6

**7** They took him alive, and decreed that both he and those who reigned after him should give them a great tribute, and should give hostages, and a parcel of land from the best of their provinces: ^7

**8** the countries of India, Media, and Lydia. They took them from him, and gave them to King Eumenes. ^8

**9** Judas heard how the Greeks planned to come and destroy them, ^9

**10** but this became known to them, and they sent against them a general who fought against them, and many of them fell down wounded to death, and they made captive their wives and their children, and plundered them, and conquered their land, and pulled down their strongholds, and plundered them, and brought them into bondage to this day. ^10

**11** The remaining kingdoms and islands, as many as rose up against them at any time, they destroyed and made them to be their servants; ^11

**12** but with their friends and those who relied on them they stayed friends. They conquered the kingdoms that were near and those that were far off, and all that heard of their fame were afraid of them. ^12

**13** Moreover, whoever they desired to help and to make kings, these they make kings; and whoever they desired, they depose. They are exalted exceedingly. ^13

**14** For all this, none of them ever put on a crown, neither did they clothe themselves with purple, as a display of grandeur. ^14

**15** Judas heard how they had made for themselves a senate house, and day by day, three hundred twenty men sat in council, consulting always for the people, to the end they might be well governed, ^15

**16** and how they commit their government to one man year by year, that he should rule over them, and control all their country, and all are obedient to that one, and there is neither envy nor emulation among them. ^16

**17** So Judas chose Eupolemus the son of John, the son of Accos, and Jason the son of Eleazar, and sent them to Rome, to establish friendship and alliance with them, ^17

**18** and that they should free the yoke from themselves; for they saw that the kingdom of the Greeks kept Israel in bondage. ^18

**19** Then they went to Rome, a very long journey, and they entered into the senate house, and said, ^19

**20** “Judas, who is also called Maccabaeus, and his kindred, and the people of the Jews, have sent us to you, to make an alliance and peace with you, and that we might be registered as your allies and friends.” ^20

**21** This thing was pleasing to them. ^21

**22** This is the copy of the writing which they wrote back again on tables of brass, and sent to Jerusalem, that it might be with them there for a memorial of peace and alliance: ^22

**23** “Good success be to the Romans, and to the nation of the Jews, by sea and by land forever. May the sword and the enemy be far from them. ^23

**24** But if war arises for Rome first, or any of their allies in all their dominion, ^24

**25** the nation of the Jews shall help them as allies, as the occasion shall indicate to them, with all their heart. ^25

**26** To those who make war upon them, they shall not give supplies, food, weapons, money, or ships, as it has seemed good to Rome, and they shall keep their ordinances without taking anything in return. ^26

**27** In the same way, moreover, if war comes first upon the nation of the Jews, the Romans shall willingly help them as allies, as the occasion shall indicate to them; ^27

**28** and to those who are fighting with them, there shall not be given food, weapons, money, or ships, as it has seemed good to Rome. They shall keep these ordinances, and that without deceit. ^28

**29** According to these terms, the Romans made a treaty with the Jewish people. ^29

**30** But if hereafter the one party and the other shall determine to add or diminish anything, they shall do it at their pleasure, and whatever they add or take away shall be ratified. ^30

**31** Concerning the evils which King Demetrius is doing to them, we have written to him, saying, ‘Why have you made your yoke heavy on our friends and allies the Jews? ^31

**32** If therefore they plead any more against you, we will do them justice, and fight with you on sea and on land.’” ^32

← [[1 Maccabees (Apocrypha) 7 - WEBU]] | [[1 Maccabees (Apocrypha) 9 - WEBU]] →
