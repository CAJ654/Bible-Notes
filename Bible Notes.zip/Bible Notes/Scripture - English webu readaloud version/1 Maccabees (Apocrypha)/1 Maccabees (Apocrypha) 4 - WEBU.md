---
book: 1 Maccabees (Apocrypha)
chapter: 4
version: WEBU
---
# 1 Maccabees (Apocrypha) 4 (WEBU)

← [[1 Maccabees (Apocrypha) 3 - WEBU]] | [[1 Maccabees (Apocrypha) 5 - WEBU]] →

**1** Gorgias took five thousand infantry, a thousand chosen cavalry, and the army moved out at night, ^1

**2** that it might fall upon the army of the Jews and strike them suddenly. The men of the citadel were his guides. ^2

**3** Judas heard of this, and he and the valiant men moved, that he might strike the king’s army which was at Emmaus ^3

**4** while the forces were still dispersed from the camp. ^4

**5** Gorgias came into the camp of Judas at night and found no man. He sought them in the mountains; for he said, “These men are running away from us.” ^5

**6** As soon as it was day, Judas appeared in the plain with three thousand men. However they didn’t have the armor and swords they desired. ^6

**7** They saw the camp of the Gentiles strong and fortified, with cavalry all around it; and these were expert in war. ^7

**8** Judas said to the men who were with him, “Don’t be afraid of their numbers, or when they charge. ^8

**9** Remember how our fathers were saved in the Red sea, when Pharaoh pursued them with an army. ^9

**10** Now let’s cry to heaven, if he will have us, and will remember the covenant of our fathers, and destroy this army before our face today. ^10

**11** Then all the Gentiles will know that there is one who redeems and saves Israel. ^11

**12** The foreigners lifted up their eyes, and saw them coming near them. ^12

**13** They went out of the camp to battle. Those who were with Judas sounded their trumpets ^13

**14** and joined battle. The Gentiles were defeated, and fled into the plain. ^14

**15** But all those in the rear fell by the sword. They pursued them to Gazara, and to the plains of Idumaea, Azotus, and Jamnia. About three thousand of those men fell. ^15

**16** Then Judas and his army returned from pursuing them; ^16

**17** and he said to the people, “Don’t be greedy for the spoils, because there is a battle before us. ^17

**18** Gorgias and his army are near us on the mountain. But stand now against our enemies and fight against them, and afterwards take the spoils with boldness.” ^18

**19** While Judas was finishing this speech, a part of them appeared looking out from the mountain. ^19

**20** They saw that their army had been put to flight, and that the Jews were burning the camp; for the smoke that was seen declared what was done. ^20

**21** But when they perceived these things, they were very afraid. Perceiving also the army of Judas in the plain ready for battle, ^21

**22** they all fled into the land of the Philistines. ^22

**23** Judas returned to plunder the camp, and they took much gold, silver, blue, sea purple, and great riches. ^23

**24** Then they returned home, and sang a song of thanksgiving, and gave praise to heaven, because he is good, because his mercy endures forever. ^24

**25** Israel had a great deliverance that day. ^25

**26** The foreigners who had escaped came and told Lysias all the things that had happened. ^26

**27** When he heard of it, he was confounded and discouraged, because the things he desired had not been done to Israel, nor had such things happened as the king commanded him. ^27

**28** In the next year, he gathered together sixty thousand chosen infantry and five thousand cavalry, that he might subdue them. ^28

**29** They came into Idumaea and encamped at Bethsura. Judas met them with ten thousand men. ^29

**30** He saw that the army was strong, and he prayed and said, “Blessed are you, O Savior of Israel, who defeated the attack of the mighty warrior by the hand of your servant David, and delivered the army of the Philistines into the hands of Jonathan the son of Saul, and of his armor bearer. ^30

**31** Hem in this army in the hand of your people Israel, and let them be ashamed for their army and their cavalry. ^31

**32** Give them faintness of heart. Cause the boldness of their strength to melt away, and let them quake at their destruction. ^32

**33** Strike them down with the sword of those who love you, and let all who know your name praise you with thanksgiving.” ^33

**34** They joined in battle; and about five thousand men of Lysias’ army fell. They fell down near them. ^34

**35** But when Lysias saw that his troops were put to flight, and the boldness that had come upon those who were with Judas, and how they were ready either to live or to die nobly, he withdrew to Antioch, and gathered together hired soldiers, that he might come again into Judea with an even greater army. ^35

**36** But Judas and his kindred said, “Behold, our enemies are defeated. Let’s go up to cleanse the holy place and to rededicate it.” ^36

**37** All the army was gathered together, and they went up to mount Zion. ^37

**38** They saw the sanctuary laid desolate, the altar profaned, the gates burned up, shrubs growing in the courts as in a forest or as on one of the mountains, and the priests’ chambers pulled down; ^38

**39** and they tore their clothes, made great lamentation, put ashes upon their heads, ^39

**40** fell on their faces to the ground, blew with the solemn trumpets,and cried toward heaven. ^40

**41** Then Judas appointed certain men to fight against those who were in the citadel until he had cleansed the holy place. ^41

**42** He chose blameless priests who were devoted to the law; ^42

**43** and they cleansed the holy place and carried the defiled stones out to an unclean place. ^43

**44** They deliberated what to do with the altar of burnt offerings, which had been profaned. ^44

**45** A good plan came into their mind, that they should pull it down, lest it would be a reproach to them, because the Gentiles had defiled it. So they pulled down the altar ^45

**46** and laid up the stones on the temple hill in a convenient place, until a prophet would come to give an answer concerning them. ^46

**47** They took whole stones according to the law, and built a new altar like the former. ^47

**48** They built the holy place and the inner parts of the house; and they consecrated the courts. ^48

**49** They made new holy vessels, and they brought the lampstand, the altar of incense, and the table into the temple. ^49

**50** They burned incense on the altar, and they lit the lamps that were upon the lampstand, and they gave light in the temple. ^50

**51** They set loaves upon the table, hung up the curtains, and finished all the work which they had done. ^51

**52** They rose up early in the morning, on the twenty-fifth day of the ninth month, which is the month Chislev, in the one hundred forty eighth year, ^52

**53** and offered sacrifice according to the law on the new altar of burnt offerings which they had made. ^53

**54** At the time and day the Gentiles had profaned it, even then it was dedicated with songs, harps, lutes, and with cymbals. ^54

**55** All the people fell on their faces, worshiped, and gave praise toward heaven, which had given them good success. ^55

**56** They celebrated the dedication of the altar eight days, and offered burnt offerings with gladness, and sacrificed a sacrifice of deliverance and praise. ^56

**57** They decorated the front of the temple with crowns of gold and small shields. They dedicated the gates and the priests’ chambers, and made doors for them. ^57

**58** There was exceedingly great gladness among the people, and the reproach of the Gentiles was turned away. ^58

**59** Judas and his kindred and the whole congregation of Israel ordained that the days of the dedication of the altar should be kept in their seasons from year to year for eight days, from the twenty-fifth day of the month Chislev, with gladness and joy. ^59

**60** At that time, they fortified mount Zion with high walls and strong towers around it, lest perhaps the Gentiles might come and trample them down, as they had done before. ^60

**61** Judas stationed a garrison to guard it. They fortified Bethsura to keep it, that the people might have a stronghold near Idumaea. ^61

← [[1 Maccabees (Apocrypha) 3 - WEBU]] | [[1 Maccabees (Apocrypha) 5 - WEBU]] →
