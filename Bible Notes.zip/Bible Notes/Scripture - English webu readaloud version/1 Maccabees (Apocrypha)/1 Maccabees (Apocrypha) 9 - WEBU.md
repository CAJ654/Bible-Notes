---
book: 1 Maccabees (Apocrypha)
chapter: 9
version: WEBU
---
# 1 Maccabees (Apocrypha) 9 (WEBU)

← [[1 Maccabees (Apocrypha) 8 - WEBU]] | [[1 Maccabees (Apocrypha) 10 - WEBU]] →

**1** Demetrius heard that Nicanor had fallen with his forces in battle, and he sent Bacchides and Alcimus again into the land of Judah a second time, and the right wing of his army with them. ^1

**2** They went by the way that leads to Gilgal, and encamped against Mesaloth, which is in Arbela, and took possession of it, and killed many people. ^2

**3** The first month of the one hundred fifty-second year, they encamped against Jerusalem. ^3

**4** Then they marched away and went to Berea with twenty thousand infantry and two thousand cavalry. ^4

**5** Judas was encamped at Elasa with three thousand chosen men. ^5

**6** They saw the multitude of the forces, that they were many, and they were terrified. Many slipped away out of the army. There were not left of them more than eight hundred men. ^6

**7** Judas saw that his army slipped away and that the battle pressed upon him, and he was very troubled in spirit, because he had no time to gather them together, and he became faint. ^7

**8** He said to those who were left, “Let’s arise and go up against our adversaries, if perhaps we may be able to fight with them.” ^8

**9** They tried to dissuade him, saying, “There is no way we are able; but let’s rather save our lives now. Let’s return again with our kindred, and fight against them; but we are too few.” ^9

**10** Judas said, “Let it not be so that I should do this thing, to flee from them. If our time has come, let’s die in a manly way for our kindred’s sake, and not leave a cause of reproach against our honor.” ^10

**11** The army marched out from the camp, and stood to encounter them. The cavalry was divided into two companies, and the slingers and the archers went before the army, and all the mighty men that fought in the front of the battle. ^11

**12** Bacchides was in the right wing. The phalanx advanced on the two parts, and they blew with their trumpets. ^12

**13** The men by Judas’ side sounded with their trumpets, and the earth shook with the shout of the armies, and the battle was joined, and continued from morning until evening. ^13

**14** Judas saw that Bacchides and the strength of his army were on the right side, and all that were brave in heart went with him, ^14

**15** and the right wing was defeated by them, and he pursued after them to the mount Azotus. ^15

**16** Those who were on the left wing saw that the right wing was defeated, and they turned and followed in the footsteps of Judas and of those who were with him. ^16

**17** The battle became desperate, and many on both sides fell wounded to death. ^17

**18** Judas fell, and the rest fled. ^18

**19** Jonathan and Simon took Judas their brother, and buried him in the tomb of his ancestors at Modin. ^19

**20** They wept for him. All Israel made great lamentation for him, and mourned many days, and said, ^20

**21** “How the mighty has fallen, the savior of Israel!” ^21

**22** The rest of the acts of Judas, and his wars, and the valiant deeds which he did, and his greatness, are not written; for they were exceedingly many. ^22

**23** It came to pass after the death of Judas, that the lawless emerged within all the borders of Israel. All those who did iniquity rose up. ^23

**24** In those days there was an exceedingly great famine, and the country went over to their side. ^24

**25** Bacchides chose the ungodly men and made them rulers of the country. ^25

**26** They inquired and searched for the friends of Judas, and brought them to Bacchides, and he took vengeance on them and used them spitefully. ^26

**27** There was great suffering in Israel, such as was not since the time prophets stopped appearing to them. ^27

**28** All the friends of Judas were gathered together, and they said to Jonathan, ^28

**29** “Since your brother Judas has died, we have no man like him to go out against our enemies and Bacchides, and among those of our nation who hate us. ^29

**30** Now therefore we have chosen you this day to be our prince and leader in his place, that you may fight our battles.” ^30

**31** So Jonathan took the governance upon him at that time, and rose up in the place of his brother Judas. ^31

**32** When Bacchides found out, he tried to kill him. ^32

**33** Jonathan, and Simon his brother, and all who were with him, knew it; and they fled into the wilderness of Tekoah, and encamped by the water of the pool of Asphar. ^33

**34** Bacchides found this out on the Sabbath day, and came—he and all his army—over the Jordan. ^34

**35** Jonathan sent his brother, a leader of the multitude, and implored his friends the Nabathaeans, that they might store their baggage, which was much, with them. ^35

**36** The children of Jambri came out of Medaba, and seized John and all that he had, and went their way with it. ^36

**37** But after these things, they brought word to Jonathan and Simon his brother that the children of Jambri were celebrating a great wedding, and were bringing the bride, a daughter of one of the great nobles of Canaan, from Nadabath with a large escort. ^37

**38** They remembered John their brother, and went up, and hid themselves under the cover of the mountain. ^38

**39** They lifted up their eyes and looked, and saw a great procession with much baggage. The bridegroom came out with his friends and his kindred to meet them with timbrels, musicians, and many weapons. ^39

**40** They rose up against them from their ambush and killed them, and many fell wounded to death. The remnant fled into the mountain, and the Jews took all their spoils. ^40

**41** So the wedding was turned into mourning, and the voice of their musicians into lamentation. ^41

**42** They avenged fully the blood of their brother, and turned back to the marshes of the Jordan. ^42

**43** Bacchides heard it, and he came on the Sabbath day to the banks of the Jordan with a great army. ^43

**44** Jonathan said to his company, “Let’s stand up now and fight for our lives, for things are different today than they were yesterday and the day before. ^44

**45** For, behold, the battle is before us and behind us. Moreover the water of the Jordan is on this side and on that side, and marsh and thicket. There is no place to escape. ^45

**46** Now therefore cry to heaven, that you may be delivered out of the hand of your enemies.” ^46

**47** So the battle was joined, and Jonathan stretched out his hand to strike Bacchides, and he turned away back from him. ^47

**48** Jonathan and those who were with him leapt into the Jordan, and swam over to the other side. The enemy didn’t pass over the Jordan against them. ^48

**49** About a thousand men of Bacchides’ company fell that day; ^49

**50** and he returned to Jerusalem. They built strong cities in Judea, the stronghold that was in Jericho, and Emmaus, Bethhoron, Bethel, Timnath, Pharathon, and Tephon, with high walls and gates and bars. ^50

**51** He set garrisons in them to harass Israel. ^51

**52** He fortified the city Bethsura, Gazara, and the citadel, and put troops and stores of food in them. ^52

**53** He took the sons of the chief men of the country for hostages, and put them under guard in the citadel at Jerusalem. ^53

**54** And in the one hundred fifty-third year, in the second month, Alcimus gave orders to pull down the wall of the inner court of the sanctuary. He also pulled down the works of the prophets. ^54

**55** He began to pull down. At that time was Alcimus stricken, and his works were hindered; and his mouth was stopped, and he was taken with a palsy, and he could no more speak anything and give orders concerning his house. ^55

**56** Alcimus died at that time with great torment. ^56

**57** Bacchides saw that Alcimus was dead, and he returned to the king. Then the land of Judah had rest for two years. ^57

**58** Then all the lawless men took counsel, saying, “Behold, Jonathan and his men are dwelling at ease and in security. Now therefore we will bring Bacchides, and he will capture them all in one night. ^58

**59** They went and consulted with him. ^59

**60** He marched out and came with a great army, and sent letters secretly to all his allies who were in Judea, that they should seize Jonathan and those who were with him; but they couldn’t, because their plan was known to them. ^60

**61** Jonathan’s men seized about fifty of the men of the country who were authors of the wickedness, and he killed them. ^61

**62** Jonathan, Simon, and those who were with him, went away to Bethbasi, which is in the wilderness, and he built up that which had been pulled down, and they made it strong. ^62

**63** Bacchides found out about it, and he gathered together all his multitude, and sent orders to those who were of Judea. ^63

**64** He went and encamped against Bethbasi and fought against it many days, and made engines of war. ^64

**65** Jonathan left his brother Simon in the city, and went out into the country, and he went with a few men. ^65

**66** He struck Odomera and his kindred, and the children of Phasiron in their tents. ^66

**67** They began to strike them, and to go up with their forces. Then Simon and those who were with him went out of the city, and set the engines of war on fire, ^67

**68** and fought against Bacchides, and he was defeated by them. They afflicted him severely; for his counsel and expedition was in vain. ^68

**69** They were very angry with the lawless men who gave him counsel to come into the country, and they killed many of them. Then he decided to depart into his own land. ^69

**70** Jonathan learned of this and sent ambassadors to him, to the end that they should make peace with him, and that he should restore to them the captives. ^70

**71** He accepted the thing, and did according to his words, and swore to him that he would not seek his harm all the days of his life. ^71

**72** He restored to him the captives which he had taken before out of the land of Judah, and he returned and departed into his own land, and didn’t come any more into their borders. ^72

**73** Thus the sword ceased from Israel. Jonathan lived at Michmash. Jonathan began to judge the people; and he destroyed the ungodly out of Israel. ^73

← [[1 Maccabees (Apocrypha) 8 - WEBU]] | [[1 Maccabees (Apocrypha) 10 - WEBU]] →
