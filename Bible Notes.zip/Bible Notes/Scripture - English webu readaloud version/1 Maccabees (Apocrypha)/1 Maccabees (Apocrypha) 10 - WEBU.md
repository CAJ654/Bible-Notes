---
book: 1 Maccabees (Apocrypha)
chapter: 10
version: WEBU
---
# 1 Maccabees (Apocrypha) 10 (WEBU)

← [[1 Maccabees (Apocrypha) 9 - WEBU]] | [[1 Maccabees (Apocrypha) 11 - WEBU]] →

**1** In the one hundred sixtieth year, Alexander Epiphanes, the son of Antiochus, went up and took possession of Ptolemais. They received him, and he reigned there. ^1

**2** King Demetrius heard about this, and he gathered together exceedingly great forces, and went out to meet him in battle. ^2

**3** Demetrius sent a letter to Jonathan with words of peace, so as to honor him. ^3

**4** For he said, “Let’s go beforehand to make peace with them, before he makes peace with Alexander against us; ^4

**5** for he will remember all the evils that we have done against him, and to his kindred and to his nation.” ^5

**6** So he gave him authority to gather together forces, and to provide weapons, and that he should be his ally. He also commanded that they should release the hostages that were in the citadel to him. ^6

**7** Jonathan came to Jerusalem, and read the letter in the hearing of all the people, and of those who were in the citadel. ^7

**8** They were very afraid when they heard that the king had given him authority to gather together an army. ^8

**9** Those in the citadel released the hostages to Jonathan, and he restored them to their parents. ^9

**10** Jonathan lived in Jerusalem and began to build and renew the city. ^10

**11** He commanded those who did the work to build the walls and encircle Mount Zion with square stones for defense; and they did so. ^11

**12** The foreigners who were in the strongholds which Bacchides had built fled away. ^12

**13** Each man left his place and departed into his own land. ^13

**14** Only at Bethsura, there were left some of those who had forsaken the law and the commandments, for it was a place of refuge to them. ^14

**15** King Alexander heard all the promises which Demetrius had sent to Jonathan. They told him of the battles and the valiant deeds which he and his kindred had done, and of the troubles which they had endured. ^15

**16** So he said, “Could we find another man like him? Now we will make him our friend and ally.” ^16

**17** He wrote a letter and sent it to him, in these words, saying, ^17

**18** “King Alexander to his brother Jonathan, greetings. ^18

**19** We have heard of you, that you are a mighty man of valour, and worthy to be our friend. ^19

**20** Now we have appointed you this day to be high priest of your nation, and to be called the king’s friend, and to take our side, and to keep friendship with us.” He also sent to him a purple robe and a golden crown. ^20

**21** And Jonathan put on the holy garments in the seventh month of the one hundred sixtieth year, at the feast of tabernacles; and he gathered together forces and provided weapons in abundance. ^21

**22** When Demetrius heard these things, he was grieved and said, ^22

**23** “What is this that we have done, that Alexander has gotten ahead of us in establishing friendship with the Jews to strengthen himself? ^23

**24** I also will write to them words of encouragement and of honor and of gifts, that they may be with me to aid me.” ^24

**25** So he sent to them this message: “King Demetrius to the nation of the Jews, greetings. ^25

**26** Since as you have kept your covenants with us, and continued in our friendship, and have not joined yourselves to our enemies, we have heard of this, and are glad. ^26

**27** Now continue still to keep faith with us, and we will repay you with good in return for your dealings with us. ^27

**28** We will grant you many immunities and give you gifts. ^28

**29** “Now I free you and release all the Jews from the tributes, from the salt tax, and from the crown levies. ^29

**30** Instead of the third part of the seed, and instead of half of the fruit of the trees, which falls to me to receive, I release it from this day and henceforth, so that I will not take it from the land of Judah, and from the three districts which are added to it from the country of Samaria and Galilee, from this day forth and for all time. ^30

**31** Let Jerusalem be holy and free, with her borders, tithes, and taxes. ^31

**32** I yield up also my authority over the citadel which is at Jerusalem, and give it to the high priest, that he may appoint in it men whom he chooses to keep it. ^32

**33** Every soul of the Jews who has been carried captive from the land of Judah into any part of my kingdom, I set at liberty without payment. Let all officials also cancel the taxes on their livestock. ^33

**34** “All the feasts, the Sabbaths, new moons, appointed days, three days before a feast, and three days after a feast, let them all be days of immunity and release for all the Jews who are in my kingdom. ^34

**35** No man shall have authority to exact anything from any of them, or to trouble them concerning any matter. ^35

**36** “Let there be enrolled among the king’s forces about thirty thousand men of the Jews, and pay shall be given to them, as is due to all the king’s forces. ^36

**37** Of them, some shall be placed in the king’s great strongholds, and some of them shall be placed over the affairs of the kingdom, which are positions of trust. Let those who are over them and their rulers be of themselves, and let them walk after their own laws, even as the king has commanded in the land of Judah. ^37

**38** “The three districts that have been added to Judea from the country of Samaria, let them be annexed to Judea, that they may be reckoned to be under one ruler, that they may not obey any other authority than the high priest’s. ^38

**39** As for Ptolemais and its land, I have given it as a gift to the sanctuary that is at Jerusalem, for the expenses of the sanctuary. ^39

**40** I also give every year fifteen thousand shekels of silver from the king’s revenues from the places that are appropriate. ^40

**41** And all the additional funds which those who manage the king’s affairs didn’t pay as in the first years, they shall give from now on toward the works of the temple. ^41

**42** Besides this, the five thousand shekels of silver which they received from the uses of the sanctuary from the revenue year by year is also released, because it belongs to the priests who minister there. ^42

**43** Whoever flees to the temple that is at Jerusalem, and within all of its borders, whether owing money to the king, or any other matter, let them go free, along with all that they have in my kingdom. ^43

**44** For the building and renewing of the structures of the sanctuary, the expense shall also be given out of the king’s revenue. ^44

**45** For the building of the walls of Jerusalem and fortifying it all around, the expense shall also be given out of the king’s revenue, also for the building of the walls in Judea.” ^45

**46** Now when Jonathan and the people heard these words, they gave no credence to them, and didn’t accept them, because they remembered the great evil which he had done in Israel, and that he had afflicted them very severely. ^46

**47** They were well pleased with Alexander, because he was the first who spoke words of peace to them, and they were allies with him always. ^47

**48** King Alexander gathered together great forces and encamped near Demetrius. ^48

**49** The two kings joined battle, and the army of Alexander fled; and Demetrius followed after him, and prevailed against them. ^49

**50** He strengthened the battle exceedingly until the sun went down; and Demetrius fell that day. ^50

**51** Alexander sent ambassadors to Ptolemy king of Egypt with this message: ^51

**52** “Since I have returned to my kingdom, and am seated on the throne of my fathers, and have established my dominion, and have overthrown Demetrius, and have taken possession of our country— ^52

**53** yes, I joined the battle with him, and he and his army were defeated by us, and we sat on the throne of his kingdom— ^53

**54** now also let’s make friends with one another. Give me now your daughter as my wife. I will be joined with you, and will give both you and her gifts worthy of you.” ^54

**55** Ptolemy the king answered, saying, “Happy is the day you returned to the land of your ancestors and sat on the throne of their kingdom. ^55

**56** Now I will do to you as you have written, but meet me at Ptolemais, that we may see one another; and I will join with you, even as you have said.” ^56

**57** So Ptolemy went out of Egypt, himself and Cleopatra his daughter, and came to Ptolemais in the one hundred sixty-second year. ^57

**58** King Alexander met him, and he gave him his daughter Cleopatra, and celebrated her wedding at Ptolemais with great pomp, as kings do. ^58

**59** King Alexander wrote to Jonathan, that he should come to meet him. ^59

**60** He went with pomp to Ptolemais, and met the two kings. He gave them and their friends silver and gold, and many gifts, and found favor in their sight. ^60

**61** Some malcontents out of Israel, men who were transgressors of the law, gathered together against him to complain against him; but the king paid no attention to them. ^61

**62** The king commanded that they take off Jonathan’s garments and clothe him in purple, and they did so. ^62

**63** The king made him sit with him, and said to his princes, “Go out with him into the midst of the city, and proclaim that no man may complain against him of any matter, and let no man trouble him for any reason.” ^63

**64** It came to pass, when those who complained against him saw his honor according to the proclamation, and saw him clothed in purple, they all fled away. ^64

**65** The king gave him honor, and enrolled him among his chief friends, and made him a captain and governor of a province. ^65

**66** Then Jonathan returned to Jerusalem with peace and gladness. ^66

**67** In the one hundred sixty-fifth year, Demetrius, son of Demetrius, came out of Crete into the land of his ancestors. ^67

**68** When King Alexander heard of it, he grieved exceedingly and returned to Antioch. ^68

**69** Demetrius appointed Apollonius, who was over Coelesyria, and he gathered together a great army, and encamped against Jamnia, and sent to Jonathan the high priest, saying, ^69

**70** “You alone lift up yourself against us, but I am ridiculed and in reproach because of you. Why do you assume authority against us in the mountains? ^70

**71** Now therefore, if you trust in your forces, come down to us into the plain, and let’s match strength with each other there; for the power of the cities is with me. ^71

**72** Ask and learn who I am, and the rest who help us. They say, ‘Your foot can’t stand before our face; for your ancestors have been put to flight twice in their own land.’ ^72

**73** Now you won’t be able to withstand the cavalry and such an army as this in the plain, where there is no stone or pebble, or place to flee.” ^73

**74** Now when Jonathan heard the words of Apollonius, he was moved in his mind, and he chose ten thousand men, and went out from Jerusalem; and Simon his brother met him to help him. ^74

**75** Then he encamped against Joppa. The people of the city shut him out, because Apollonius had a garrison in Joppa. ^75

**76** So they fought against it. The people of the city were afraid, and opened to him; and Jonathan became master of Joppa. ^76

**77** Apollonius heard about that, and he gathered an army of three thousand cavalry, and a great army, and went to Azotus as though he were on a journey, and at the same time advanced onward into the plain, because he had a multitude of cavalry which he trusted. ^77

**78** He pursued him to Azotus, and the armies joined battle. ^78

**79** Apollonius had secretly left a thousand cavalry behind them. ^79

**80** Jonathan learned that there was an ambush behind him. They surrounded his army, and shot their arrows at the people, from morning until evening; ^80

**81** but the people stood fast, as Jonathan commanded them; and the enemy’s horses grew tired. ^81

**82** Then Simon brought forward his army and joined battle with the phalanx (for the cavalry were exhausted), and they were defeated by him and fled. ^82

**83** The cavalry were scattered in the plain. They fled to Azotus and entered into Beth-dagon, their idol’s temple, to save themselves. ^83

**84** Jonathan burned Azotus and the cities around it and took their spoils. He burned the temple of Dagon and those who fled into it with fire. ^84

**85** Those who had fallen by the sword plus those who were burned were about eight thousand men. ^85

**86** From there, Jonathan left and encamped against Ascalon. The people of the city came out to meet him with great pomp. ^86

**87** Jonathan, with those who were on his side, returned to Jerusalem, having many spoils. ^87

**88** It came to pass, when King Alexander heard these things, he honored Jonathan even more. ^88

**89** He sent him a gold buckle, as the custom is to give to the king’s kindred. He gave him Ekron and all its land for a possession. ^89

← [[1 Maccabees (Apocrypha) 9 - WEBU]] | [[1 Maccabees (Apocrypha) 11 - WEBU]] →
