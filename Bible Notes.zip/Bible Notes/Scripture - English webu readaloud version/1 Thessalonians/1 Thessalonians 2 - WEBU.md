---
book: 1 Thessalonians
chapter: 2
version: WEBU
---
# 1 Thessalonians 2 (WEBU)

← [[1 Thessalonians 1 - WEBU]] | [[1 Thessalonians 3 - WEBU]] →

**1** For you yourselves know, brothers, our visit to you wasn’t in vain, ^1

**2** but having suffered before and been shamefully treated, as you know, at Philippi, we grew bold in our God to tell you the Good News of God in much conflict. ^2

**3** For our exhortation is not of error, nor of uncleanness, nor in deception. ^3

**4** But even as we have been approved by God to be entrusted with the Good News, so we speak—not as pleasing men, but God, who tests our hearts. ^4

**5** For neither were we at any time found using words of flattery, as you know, nor a cloak of covetousness (God is witness), ^5

**6** nor seeking glory from men (neither from you nor from others), when we might have claimed authority as apostles of Christ. ^6

**7** But we were gentle among you, like a nursing mother cherishes her own children. ^7

**8** Even so, affectionately longing for you, we were well pleased to impart to you not the Good News of God only, but also our own souls, because you had become very dear to us. ^8

**9** For you remember, brothers, our labor and travail; for working night and day, that we might not burden any of you, we preached to you the Good News of God. ^9

**10** You are witnesses with God how holy, righteously, and blamelessly we behaved ourselves toward you who believe. ^10

**11** As you know, we exhorted, comforted, and implored every one of you, as a father does his own children, ^11

**12** to the end that you should walk worthily of God, who calls you into his own Kingdom and glory. ^12

**13** For this cause we also thank God without ceasing that when you received from us the word of the message of God, you accepted it not as the word of men, but as it is in truth, God’s word, which also works in you who believe. ^13

**14** For you, brothers, became imitators of the assemblies of God which are in Judea in Christ Jesus; for you also suffered the same things from your own countrymen, even as they did from the Jews ^14

**15** who killed both the Lord Jesus and their own prophets, and drove us out, and don’t please God, and are contrary to all men, ^15

**16** forbidding us to speak to the Gentiles that they may be saved, to fill up their sins always. But wrath has come on them to the uttermost. ^16

**17** But we, brothers, being bereaved of you for a short season in presence, not in heart, tried even harder to see your face with great desire, ^17

**18** because we wanted to come to you—indeed, I, Paul, once and again—but Satan hindered us. ^18

**19** For what is our hope, or joy, or crown of rejoicing? Isn’t it even you, before our Lord Jesus at his coming? ^19

**20** For you are our glory and our joy. ^20

← [[1 Thessalonians 1 - WEBU]] | [[1 Thessalonians 3 - WEBU]] →
