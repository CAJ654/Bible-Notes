---
book: 1 Thessalonians
chapter: 3
version: WEBU
---
# 1 Thessalonians 3 (WEBU)

← [[1 Thessalonians 2 - WEBU]] | [[1 Thessalonians 4 - WEBU]] →

**1** Therefore when we couldn’t stand it any longer, we thought it good to be left behind at Athens alone, ^1

**2** and sent Timothy, our brother and God’s servant in the Good News of Christ, to establish you and to comfort you concerning your faith, ^2

**3** that no one would be moved by these afflictions. For you know that we are appointed to this task. ^3

**4** For most certainly, when we were with you, we told you beforehand that we are to suffer affliction, even as it happened, and you know. ^4

**5** For this cause I also, when I couldn’t stand it any longer, sent that I might know your faith, for fear that by any means the tempter had tempted you, and our labor would have been in vain. ^5

**6** But Timothy has just now come to us from you, and brought us glad news of your faith and love, and that you have good memories of us always, longing to see us, even as we also long to see you. ^6

**7** For this cause, brothers, we were comforted over you in all our distress and affliction through your faith. ^7

**8** For now we live, if you stand fast in the Lord. ^8

**9** For what thanksgiving can we give again to God for you, for all the joy with which we rejoice for your sakes before our God, ^9

**10** night and day praying exceedingly that we may see your face and may perfect that which is lacking in your faith? ^10

**11** Now may our God and Father himself, and our Lord Jesus Christ, direct our way to you. ^11

**12** May the Lord make you to increase and abound in love toward one another and toward all men, even as we also do toward you, ^12

**13** to the end he may establish your hearts blameless in holiness before our God and Father at the coming of our Lord Jesus with all his saints. ^13

← [[1 Thessalonians 2 - WEBU]] | [[1 Thessalonians 4 - WEBU]] →
