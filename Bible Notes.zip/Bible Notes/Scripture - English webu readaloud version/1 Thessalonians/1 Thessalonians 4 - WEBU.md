---
book: 1 Thessalonians
chapter: 4
version: WEBU
---
# 1 Thessalonians 4 (WEBU)

← [[1 Thessalonians 3 - WEBU]] | [[1 Thessalonians 5 - WEBU]] →

**1** Finally then, brothers, we beg and exhort you in the Lord Jesus, that as you received from us how you ought to walk and to please God, that you abound more and more. ^1

**2** For you know what instructions we gave you through the Lord Jesus. ^2

**3** For this is the will of God: your sanctification, that you abstain from sexual immorality, ^3

**4** that each one of you know how to control his own body in sanctification and honor, ^4

**5** not in the passion of lust, even as the Gentiles who don’t know God, ^5

**6** that no one should take advantage of and wrong a brother or sister in this matter; because the Lord is an avenger in all these things, as also we forewarned you and testified. ^6

**7** For God called us not for uncleanness, but in sanctification. ^7

**8** Therefore he who rejects this doesn’t reject man, but God, who has also given his Holy Spirit to you. ^8

**9** But concerning brotherly love, you have no need that one write to you. For you yourselves are taught by God to love one another, ^9

**10** for indeed you do it toward all the brothers who are in all Macedonia. But we exhort you, brothers, that you abound more and more; ^10

**11** and that you make it your ambition to lead a quiet life, and to do your own business, and to work with your own hands, even as we instructed you, ^11

**12** that you may walk properly toward those who are outside, and may have need of nothing. ^12

**13** But we don’t want you to be ignorant, brothers, concerning those who have fallen asleep, so that you don’t grieve like the rest, who have no hope. ^13

**14** For if we believe that Jesus died and rose again, even so God will bring with him those who have fallen asleep in Jesus. ^14

**15** For this we tell you by the word of the Lord, that we who are alive, who are left until the coming of the Lord, will in no way precede those who have fallen asleep. ^15

**16** For the Lord himself will descend from heaven with a shout, with the voice of the archangel and with God’s trumpet. The dead in Christ will rise first, ^16

**17** then we who are alive, who are left, will be caught up together with them in the clouds to meet the Lord in the air. So we will be with the Lord forever. ^17

**18** Therefore comfort one another with these words. ^18

← [[1 Thessalonians 3 - WEBU]] | [[1 Thessalonians 5 - WEBU]] →
