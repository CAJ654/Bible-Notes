---
book: 1 Thessalonians
chapter: 1
version: WEBU
---
# 1 Thessalonians 1 (WEBU)

[[1 Thessalonians 2 - WEBU]] →

**1** Paul, Silvanus, and Timothy, to the assembly of the Thessalonians in God the Father and the Lord Jesus Christ: Grace to you and peace from God our Father and the Lord Jesus Christ. ^1

**2** We always give thanks to God for all of you, mentioning you in our prayers, ^2

**3** remembering without ceasing your work of faith and labor of love and perseverance of hope in our Lord Jesus Christ, before our God and Father. ^3

**4** We know, brothers loved by God, that you are chosen, ^4

**5** and that our Good News came to you not in word only, but also in power, and in the Holy Spirit and with much assurance. You know what kind of men we showed ourselves to be among you for your sake. ^5

**6** You became imitators of us and of the Lord, having received the word in much affliction, with joy of the Holy Spirit, ^6

**7** so that you became an example to all who believe in Macedonia and in Achaia. ^7

**8** For from you the word of the Lord has been declared, not only in Macedonia and Achaia, but also in every place your faith toward God has gone out, so that we need not say anything. ^8

**9** For they themselves report concerning us what kind of a reception we had from you, and how you turned to God from idols to serve a living and true God, ^9

**10** and to wait for his Son from heaven, whom he raised from the dead: Jesus, who delivers us from the wrath to come. ^10

[[1 Thessalonians 2 - WEBU]] →
