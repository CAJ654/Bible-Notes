---
book: 1 Esdras
chapter: 3
version: WEBU
---
# 1 Esdras 3 (WEBU)

← [[1 Esdras 2 - WEBU]] | [[1 Esdras 4 - WEBU]] →

**1** Now King Darius made a great feast for all his subjects, for all who were born in his house, for all the princes of Media and of Persia, ^1

**2** and for all the local governors and captains and governors who were under him, from India to Ethiopia, in the one hundred twenty seven provinces. ^2

**3** They ate and drank, and when they were satisfied went home. Then King Darius went into his bedchamber and slept, but awakened out of his sleep. ^3

**4** Then the three young men of the bodyguard, who guarded the king, spoke one to another: ^4

**5** “Let every one of us state what one thing is strongest. King Darius will give him whose statement seems wiser than the others great gifts and great honors in token of victory. ^5

**6** He shall be clothed in purple, drink from gold cups, sleep on a gold bed, and have a chariot with bridles of gold, a fine linen turban, and a chain around his neck. ^6

**7** He shall sit next to Darius because of his wisdom, and shall be called cousin of Darius.” ^7

**8** Then they each wrote his sentence, sealed them, and laid them under King Darius’ pillow, ^8

**9** and said, “When the king wakes up, someone will give him the writing. Whoever the king and the three princes of Persia judge that his sentence is the wisest, to him shall the victory be given, as it is written.” ^9

**10** The first wrote, “Wine is the strongest.” ^10

**11** The second wrote, “The king is strongest.” ^11

**12** The third wrote, “Women are strongest, but above all things Truth is the victor.” ^12

**13** Now when the king woke up, they took the writing and gave it to him, so he read it. ^13

**14** Sending out, he called all the princes of Persia and of Media, the local governors, the captains, the governors, and the chief officers ^14

**15** and sat himself down in the royal seat of judgment; and the writing was read before them. ^15

**16** He said, “Call the young men, and they shall explain their own sentences. So they were called and came in. ^16

**17** They said to them, “Explain what you have written.” Then the first, who had spoken of the strength of wine, began ^17

**18** and said this: “O sirs, how exceedingly strong wine is! It causes all men who drink it to go astray. ^18

**19** It makes the mind of the king and of the fatherless child to be the same, likewise of the bondman and of the freeman, of the poor man and of the rich. ^19

**20** It also turns every thought into cheer and mirth, so that a man remembers neither sorrow nor debt. ^20

**21** It makes every heart rich, so that a man remembers neither king nor local governor. It makes people say things in large amounts. ^21

**22** When they are in their cups, they forget their love both to friends and kindred, and before long draw their swords. ^22

**23** But when they awake from their wine, they don’t remember what they have done. ^23

**24** O sirs, isn’t wine the strongest, seeing that it forces people to do this?” And when he had said this, he stopped speaking. ^24

← [[1 Esdras 2 - WEBU]] | [[1 Esdras 4 - WEBU]] →
