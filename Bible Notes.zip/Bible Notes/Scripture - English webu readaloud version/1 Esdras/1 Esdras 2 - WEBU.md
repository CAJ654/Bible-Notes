---
book: 1 Esdras
chapter: 2
version: WEBU
---
# 1 Esdras 2 (WEBU)

← [[1 Esdras 1 - WEBU]] | [[1 Esdras 3 - WEBU]] →

**1** In the first year of King Cyrus of the Persians, that the word of the Lord by the mouth of Jeremy might be accomplished, ^1

**2** the Lord stirred up the spirit of King Cyrus of the Persians, and he made a proclamation throughout all his kingdom, and also by writing, ^2

**3** saying, “Cyrus king of the Persians says: The Lord of Israel, the Most High Lord, has made me king of the whole world, ^3

**4** and commanded me to build him a house at Jerusalem that is in Judea. ^4

**5** If therefore there are any of you that are of his people, let the Lord, even his Lord, be with him, and let him go up to Jerusalem that is in Judea, and build the house of the Lord of Israel. He is the Lord who dwells in Jerusalem. ^5

**6** Therefore, of those who dwell in various places, let those who are in his own place each help with gold, with silver, ^6

**7** with gifts, with horses, and cattle, beside the other things which have been added by vow for the temple of the Lord which is in Jerusalem. ^7

**8** Then the chief of the families of Judah and of the tribe of Benjamin stood up, with the priests, the Levites, and all whose spirit the Lord had stirred to go up, to build the house for the Lord which is in Jerusalem. ^8

**9** Those who lived around them helped them in all things with silver and gold, with horses and cattle, and with very many gifts that were vowed by a great number whose minds were so moved. ^9

**10** King Cyrus also brought out the holy vessels of the Lord, which Nabuchodonosor had carried away from Jerusalem and had stored in his temple of idols. ^10

**11** Now when King Cyrus of the Persians had brought them out, he delivered them to Mithradates his treasurer, ^11

**12** and by him they were delivered to Sanabassar the governor of Judea. ^12

**13** This was the number of them: one thousand gold cups, one thousand silver cups, twenty-nine silver censers, thirty gold bowls, two thousand four hundred ten silver bowls, and one thousand other vessels. ^13

**14** So all the vessels of gold and of silver were brought up, even five thousand four hundred seventy-nine, ^14

**15** and were carried back by Sanabassar, together with the returning exiles, from Babylon to Jerusalem. ^15

**16** In the time of King Artaxerxes of the Persians, Belemus, Mithradates, Tabellius, Rathumus, Beeltethmus, and Samellius the scribe, with their other associates, dwelling in Samaria and other places, wrote to him against those who lived in Judea and Jerusalem the following letter: ^16

**17** “To King Artaxerxes our Lord, from your servants, Rathumus the recorder, Samellius the scribe, and the rest of their council, and the judges who are in Coelesyria and Phoenicia: ^17

**18** Let it now be known to our lord the king, that the Jews that have come up from you to us, having come to Jerusalem, are building that rebellious and wicked city, and are repairing its marketplaces and walls, and are laying the foundation of a temple. ^18

**19** Now if this city is built and its walls are finished, they will not only refuse to give tribute, but will even stand up against kings. ^19

**20** Since the things pertaining to the temple are now in hand, we think it appropriate not to neglect such a matter, ^20

**21** but to speak to our lord the king, to the intent that, if it is your pleasure, search may be made in the books of your ancestors. ^21

**22** You will find in the chronicles what is written concerning these things, and will understand that that city was rebellious, troubling both kings and cities, ^22

**23** and that the Jews were rebellious, and kept starting wars there in the past. For this cause, this city was laid waste. ^23

**24** Therefore now we do declare to you, O lord the king, that if this city is built again, and its walls set up again, you will from then on have no passage into Coelesyria and Phoenicia.” ^24

**25** Then the king wrote back again to Rathumus the recorder, Beeltethmus, Samellius the scribe, and to the rest of their associates who lived in Samaria, Syria, and Phoenicia, as follows: ^25

**26** “I have read the letter which you have sent to me. Therefore I commanded to make search, and it has been found that that city of old time has fought against kings, ^26

**27** and the men were given to rebellion and war in it, and that mighty and fierce kings were in Jerusalem, who reigned and exacted tribute in Coelesyria and Phoenicia. ^27

**28** Now therefore I have commanded to prevent those men from building the city, and heed to be taken that there be nothing done contrary to this order, ^28

**29** and that those wicked doings proceed no further to the annoyance of kings.” ^29

**30** Then King Artaxerxes, his letters being read, Rathumus, and Samellius the scribe, and the rest of their associates, went in haste to Jerusalem with cavalry and a multitude of people in battle array, and began to hinder the builders. So the building of the temple in Jerusalem ceased until the second year of the reign of King Darius of the Persians. ^30

← [[1 Esdras 1 - WEBU]] | [[1 Esdras 3 - WEBU]] →
