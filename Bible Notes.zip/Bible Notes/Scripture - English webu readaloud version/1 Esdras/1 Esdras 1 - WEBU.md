---
book: 1 Esdras
chapter: 1
version: WEBU
---
# 1 Esdras 1 (WEBU)

[[1 Esdras 2 - WEBU]] →

**1** Josias held the Passover in Jerusalem to his Lord, and offered the Passover the fourteenth day of the first month, ^1

**2** having set the priests according to their daily courses, being arrayed in their vestments, in the Lord’s temple. ^2

**3** He spoke to the Levites, the temple servants of Israel, that they should make themselves holy to the Lord, to set the holy ark of the Lord in the house that King Solomon the son of David had built. ^3

**4** He said, “You no longer need to carry it on your shoulders. Now therefore serve the Lord your God, and minister to his people Israel, and prepare yourselves by your fathers’ houses and kindred, ^4

**5** according to the writing of King David of Israel, and according to the magnificence of Solomon his son. Stand in the holy place according to the divisions of your Levite families who minister in the presence of your kindred the descendants of Israel. ^5

**6** Offer the Passover in order, prepare the sacrifices for your kindred, and keep the Passover according to the Lord’s commandment, which was given to Moses. ^6

**7** To the people which were present, Josias gave thirty thousand lambs and kids, and three thousand calves. These things were given from the king’s possessions, as he promised, to the people and to the priests and Levites. ^7

**8** Helkias, Zacharias, and Esyelus, the rulers of the temple, gave to the priests for the Passover two thousand six hundred sheep, and three hundred calves. ^8

**9** Jeconias, Samaias, Nathanael his brother, Sabias, Ochielus, and Joram, captains over thousands, gave to the Levites for the Passover five thousand sheep and seven hundred calves. ^9

**10** When these things were done, the priests and Levites, having the unleavened bread, stood in proper order according to the kindred, ^10

**11** and according to the several divisions by fathers’ houses, before the people, to offer to the Lord as it is written in the book of Moses. They did this in the morning. ^11

**12** They roasted the Passover lamb with fire, as required. They boiled the sacrifices in the brazen vessels and caldrons with a pleasing smell, ^12

**13** and set them before all the people. Afterward they prepared for themselves and for their kindred the priests, the sons of Aaron. ^13

**14** For the priests offered the fat until night. The Levites prepared for themselves and for their kindred the priests, the sons of Aaron. ^14

**15** The holy singers also, the sons of Asaph, were in their order, according to the appointment of David: Asaph, Zacharias, and Eddinus, who represented the king. ^15

**16** Moreover the gatekeepers were at every gate. No one needed to depart from his daily duties, for their kindred the Levites prepared for them. ^16

**17** So the things that belonged to the Lord’s sacrifices were accomplished in that day, in holding the Passover, ^17

**18** and offering sacrifices on the altar of the Lord, according to the commandment of King Josias. ^18

**19** So the children of Israel which were present at that time held the Passover and the feast of unleavened bread seven days. ^19

**20** Such a Passover had not been held in Israel since the time of the prophet Samuel. ^20

**21** Indeed, none of the kings of Israel held such a Passover as Josias with the priests, the Levites, and the Jews, held with all Israel that were present in their dwelling place at Jerusalem. ^21

**22** This Passover was held in the eighteenth year of the reign of Josias. ^22

**23** The works of Josias were upright before his Lord with a heart full of godliness. ^23

**24** Moreover the things that came to pass in his days have been written in times past, concerning those who sinned and did wickedly against the Lord more than any other people or kingdom, and how they grieved him exceedingly, so that the Lord’s words were confirmed against Israel. ^24

**25** Now after all these acts of Josias, it came to pass that Pharaoh the king of Egypt came to make war at Carchemish on the Euphrates; and Josias went out against him. ^25

**26** But the king of Egypt sent to him, saying, “What do I have to do with you, O king of Judea? ^26

**27** I wasn’t sent out from the Lord God against you, for my war is against the Euphrates. Now the Lord is with me, yes, the Lord is with me hastening me forward. Depart from me, and don’t be against the Lord.” ^27

**28** However, Josias didn’t turn back to his chariot, but tried to fight with him, not regarding the words of the prophet Jeremy from the Lord’s mouth, ^28

**29** but joined battle with him in the plain of Megiddo, and the commanders came down against King Josias. ^29

**30** Then the king said to his servants, “Carry me away out of the battle, for I am very weak!” Immediately his servants carried him away out of the army. ^30

**31** Then he got into his second chariot. After he was brought back to Jerusalem he died, and was buried in the tomb of his ancestors. ^31

**32** All Judea mourned for Josias. Jeremy the prophet lamented for Josias, and the chief men with the women made lamentation for him to this day. This was given out for an ordinance to be done continually in all the nation of Israel. ^32

**33** These things are written in the book of the histories of the kings of Judea, and every one of the acts that Josias did, and his glory, and his understanding in the law of the Lord, and the things that he had done before, and the things now told, are reported in the book of the kings of Israel and Judah. ^33

**34** The people took Joachaz the son of Josias, and made him king instead of Josias his father, when he was twenty-three years old. ^34

**35** He reigned in Judah and Jerusalem for three months. Then the king of Egypt deposed him from reigning in Jerusalem. ^35

**36** He set a tax upon the people of one hundred talents of silver and one talent of gold. ^36

**37** The king of Egypt also made King Joakim his brother king of Judea and Jerusalem. ^37

**38** And Joakim imprisoned the nobles and apprehended his brother Zarakes, and brought him up out of Egypt. ^38

**39** Joakim was twenty-five years old when he began to reign in Judea and Jerusalem. He did that which was evil in the sight of the Lord. ^39

**40** King Nabuchodonosor of Babylon came up against him, bound him with a chain of brass, and carried him to Babylon. ^40

**41** Nabuchodonosor also took some of the Lord’s holy vessels, carried them away, and stored them in his own temple at Babylon. ^41

**42** But those things that are reported of him, and of his uncleanness and impiety, are written in the chronicles of the kings. ^42

**43** Then Joakim his son reigned in his place. When he was made king, he was eighteen years old. ^43

**44** He reigned three months and ten days in Jerusalem. He did that which was evil before the Lord. ^44

**45** So after a year Nabuchodonosor sent and caused him to be brought to Babylon with the holy vessels of the Lord, ^45

**46** and made Sedekias king of Judea and Jerusalem when he was twenty-one years old. He reigned eleven years. ^46

**47** He also did that which was evil in the sight of the Lord, and didn’t heed the words that were spoken by Jeremy the prophet from the Lord’s mouth. ^47

**48** After King Nabuchodonosor had made him to swear by the name of the Lord, he broke his oath and rebelled. Hardening his neck and his heart, he transgressed the laws of the Lord, the God of Israel. ^48

**49** Moreover the governors of the people and of the priests did many things wickedly, exceeding all the defilements of all nations, and defiled the temple of the Lord, which was sanctified in Jerusalem. ^49

**50** The God of their ancestors sent by his messenger to call them back, because he had compassion on them and on his dwelling place. ^50

**51** But they mocked his messengers. In the day when the Lord spoke, they scoffed at his prophets ^51

**52** until he, being angry with his people for their great ungodliness, commanded to bring up the kings of the Chaldeans against them. ^52

**53** They killed their young men with the sword around their holy temple, and spared neither young man or young woman, old man or child; but he delivered all of them into their hands. ^53

**54** They took all the holy vessels of the Lord, both great and small, with the treasure chests of the Lord’s ark and the king’s treasures, and carried them away to Babylon. ^54

**55** They burned the Lord’s house, broke down Jerusalem’s walls, and burned its towers with fire. ^55

**56** As for her glorious things, they didn’t stop until they had brought them all to nothing. He carried the people who weren’t slain with the sword to Babylon. ^56

**57** They were servants to him and to his children until the Persians reigned, to fulfill the word of the Lord by the mouth of Jeremy: ^57

**58** “Until the land has enjoyed its Sabbaths, the whole time of her desolation shall she keep Sabbath, to fulfill seventy years. ^58

[[1 Esdras 2 - WEBU]] →
