---
book: 1 Esdras
chapter: 6
version: WEBU
---
# 1 Esdras 6 (WEBU)

← [[1 Esdras 5 - WEBU]] | [[1 Esdras 7 - WEBU]] →

**1** Now in the second year of the reign of Darius, Aggaeus and Zacharius the son of Addo, the prophets, prophesied to the Jews in Judea and Jerusalem in the name of the Lord, the God of Israel. ^1

**2** Then Zorobabel the son of Salathiel and Jesus the son of Josedek stood up and began to build the house of the Lord at Jerusalem, the prophets of the Lord being with them and helping them. ^2

**3** At the same time Sisinnes the governor of Syria and Phoenicia came to them, with Sathrabuzanes and his companions, and said to them, ^3

**4** “By whose authority do you build this house and this roof, and perform all the other things? Who are the builders who do these things?” ^4

**5** Nevertheless, the elders of the Jews obtained favor, because the Lord had visited the captives; ^5

**6** and they were not hindered from building until such time as communication was made to Darius concerning them, and his answer received. ^6

**7** A copy of the letter which Sisinnes, governor of Syria and Phoenicia, and Sathrabuzanes, with their companions, the rulers in Syria and Phoenicia, wrote and sent to Darius: ^7

**8** “To King Darius, greetings. Let it be fully known to our lord the king, that having come into the country of Judea, and entered into the city of Jerusalem, we found in the city of Jerusalem the elders of the Jews that were of the captivity ^8

**9** building a great new house for the Lord of hewn and costly stones, with timber laid in the walls. ^9

**10** Those works are being done with great speed. The work goes on prosperously in their hands, and it is being accomplished with all glory and diligence. ^10

**11** Then we asked these elders, saying, ‘By whose authority are you building this house and laying the foundations of these works?’ ^11

**12** Therefore, to the intent that we might give knowledge to you by writing who the leaders were, we questioned them, and we required of them the names in writing of their principal men. ^12

**13** So they gave us this answer, ‘We are the servants of the Lord who made heaven and earth. ^13

**14** As for this house, it was built many years ago by a great and strong king of Israel, and was finished. ^14

**15** But when our fathers sinned against the Lord of Israel who is in heaven, and provoked him to wrath, he gave them over into the hands of King Nabuchodonosor of Babylon, king of the Chaldeans. ^15

**16** They pulled down the house, burned it, and carried away the people captive to Babylon. ^16

**17** But in the first year that Cyrus reigned over the country of Babylon, King Cyrus wrote that this house should be rebuilt. ^17

**18** The holy vessels of gold and of silver that Nabuchodonosor had carried away out of the house at Jerusalem and had set up in his own temple, those King Cyrus brought out of the temple in Babylonia, and they were delivered to Zorobabel and to Sanabassarus the governor, ^18

**19** with commandment that he should carry away all these vessels, and put them in the temple at Jerusalem, and that the Lord’s temple should be built on its site. ^19

**20** Then Sanabassarus, having come here, laid the foundations of the Lord’s house which is in Jerusalem. From that time to this we are still building. It is not yet fully completed.’ ^20

**21** Now therefore, if it seems good, O king, let a search be made among the royal archives of our lord the king that are in Babylon. ^21

**22** If it is found that the building of the house of the Lord which is in Jerusalem has been done with the consent of King Cyrus, and it seems good to our lord the king, let him send us directions concerning these things.” ^22

**23** Then King Darius commanded that a search be made among the archives that were laid up at Babylon. So at Ekbatana the palace, which is in the country of Media, a scroll was found where these things were recorded: ^23

**24** “In the first year of the reign of Cyrus, King Cyrus commanded to build up the house of the Lord which is in Jerusalem, where they sacrifice with continual fire. ^24

**25** Its height shall be sixty cubits, and the breadth sixty cubits, with three rows of hewn stones, and one row of new wood from that country. Its expenses are to be given out of the house of King Cyrus. ^25

**26** The holy vessels of the house of the Lord, both gold and silver, that Nabuchodonosor took out of the house at Jerusalem and carried away to Babylon, should be restored to the house at Jerusalem, and be set in the place where they were before.” ^26

**27** Also he commanded that Sisinnes the governor of Syria and Phoenicia, and Sathrabuzanes, and their companions, and those who were appointed rulers in Syria and Phoenicia, should be careful not to meddle with the place, but allow Zorobabel, the servant of the Lord, and governor of Judea, and the elders of the Jews, to build that house of the Lord in its place. ^27

**28** “I also command to have it built up whole again; and that they look diligently to help those who are of the captivity of Judea, until the house of the Lord is finished, ^28

**29** and that out of the tribute of Coelesyria and Phoenicia a portion shall be carefully given to these men for the sacrifices of the Lord, that is, to Zorobabel the governor for bulls, rams, and lambs, ^29

**30** and also corn, salt, wine and oil, and that continually every year without further question, according as the priests who are in Jerusalem may direct to be daily spent, ^30

**31** that drink offerings may be made to the Most High God for the king and for his children, and that they may pray for their lives.” ^31

**32** He commanded that whoever should transgress, yes, or neglect anything written here, a beam shall be taken out of his own house, and he shall be hanged on it, and all his goods seized for the king. ^32

**33** “Therefore may the Lord, whose name is called upon there, utterly destroy every king and nation that stretches out his hand to hinder or damage that house of the Lord in Jerusalem. ^33

**34** I, King Darius have ordained that these things be done with diligence.” ^34

← [[1 Esdras 5 - WEBU]] | [[1 Esdras 7 - WEBU]] →
