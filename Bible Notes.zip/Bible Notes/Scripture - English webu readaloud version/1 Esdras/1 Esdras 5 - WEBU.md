---
book: 1 Esdras
chapter: 5
version: WEBU
---
# 1 Esdras 5 (WEBU)

← [[1 Esdras 4 - WEBU]] | [[1 Esdras 6 - WEBU]] →

**1** After this, the chiefs of fathers’ houses were chosen to go up according to their tribes, with their wives, sons, and daughters, with their menservants and maidservants, and their livestock. ^1

**2** Darius sent with them one thousand cavalry to bring them back to Jerusalem with peace, with musical instruments, drums, and flutes. ^2

**3** All their kindred were making merry, and he made them go up together with them. ^3

**4** These are the names of the men who went up, according to their families among their tribes, after their several divisions. ^4

**5** The priests, the sons of Phinees, the sons of Aaron: Jesus the son of Josedek, the son of Saraias, and Joakim the son of Zorobabel, the son of Salathiel, of the house of David, of the lineage of Phares, of the tribe of Judah, ^5

**6** who spoke wise words before Darius the king of Persia in the second year of his reign, in the month Nisan, which is the first month. ^6

**7** These are the of Judeans who came up from the captivity, where they lived as foreigners, whom Nabuchodonosor the king of Babylon had carried away to Babylon. ^7

**8** They returned to Jerusalem and to the other parts of Judea, every man to his own city, who came with Zorobabel, with Jesus, Nehemias, Zaraias, Resaias,Eneneus, Mardocheus, Beelsarus, Aspharsus, Reelias, Roimus, and Baana, their leaders. ^8

**9** The number of them of the nation and their leaders: the sons of Phoros, two thousand one hundred seventy two; the sons of Saphat, four hundred seventy two; ^9

**10** the sons of Ares, seven hundred fifty six; ^10

**11** the sons of Phaath Moab, of the sons of Jesus and Joab, two thousand eight hundred twelve; ^11

**12** the sons of Elam, one thousand two hundred fifty four; the sons of Zathui, nine hundred forty five; the sons of Chorbe, seven hundred five; the sons of Bani, six hundred forty eight; ^12

**13** the sons of Bebai, six hundred twenty three; the sons of Astad, one thousand three hundred twenty two; ^13

**14** the sons of Adonikam, six hundred sixty seven; the sons of Bagoi, two thousand sixty six; the sons of Adinu, four hundred fifty four; ^14

**15** the sons of Ater, of Ezekias, ninety two; the sons of Kilan and Azetas, sixty seven; the sons of Azaru, four hundred thirty two; ^15

**16** the sons of Annis, one hundred one; the sons of Arom, the sons of Bassai, three hundred twenty three; the sons of Arsiphurith, one hundred twelve; ^16

**17** the sons of Baiterus, three thousand five; the sons of Bethlomon, one hundred twenty three; ^17

**18** those from Netophas, fifty five; those from Anathoth, one hundred fifty eight; those from Bethasmoth, forty two; ^18

**19** those from Kariathiarius, twenty five: those from Caphira and Beroth, seven hundred forty three; ^19

**20** the Chadiasai and Ammidioi, four hundred twenty two; those from Kirama and Gabbe, six hundred twenty one; ^20

**21** those from Macalon, one hundred twenty two; those from Betolion, fifty two; the sons of Niphis, one hundred fifty six; ^21

**22** the sons of Calamolalus and Onus, seven hundred twenty five; the sons of Jerechu, three hundred forty five; ^22

**23** and the sons of Sanaas, three thousand three hundred thirty. ^23

**24** The priests: the sons of Jeddu, the son of Jesus, among the sons of Sanasib, nine hundred seventy two; the sons of Emmeruth, one thousand fifty two; ^24

**25** the sons of Phassurus, one thousand two hundred forty seven; and the sons of Charme, one thousand seventeen. ^25

**26** The Levites: the sons of Jesus, Kadmiel, Bannas, and Sudias, seventy four. ^26

**27** The holy singers: the sons of Asaph, one hundred twenty eight. ^27

**28** The gatekeepers: the sons of Salum, the sons of Atar, the sons of Tolman, the sons of Dacubi, the sons of Ateta, the sons of Sabi, in all one hundred thirty nine. ^28

**29** The temple servants: the sons of Esau, the sons of Asipha, the sons of Tabaoth, the sons of Keras, the sons of Sua, the sons of Phaleas, the sons of Labana, the sons of Aggaba. ^29

**30** the sons of Acud, the sons of Uta, the sons of Ketab, the sons of Accaba, the sons of Subai, the sons of Anan, the sons of Cathua, the sons of Geddur, ^30

**31** the sons of Jairus, the sons of Daisan, the sons of Noeba, the sons of Chaseba, the sons of Gazera, the sons of Ozias, the sons of Phinoe, the sons of Asara, the sons of Basthai, the sons of Asana, the sons of Maani, the sons of Naphisi, the sons of Acub, the sons of Achipha, the sons of Asur, the sons of Pharakim, the sons of Basaloth, ^31

**32** the sons of Meedda, the sons of Cutha, the sons of Charea, the sons of Barchus, the sons of Serar, the sons of Thomei, the sons of Nasi, the sons of Atipha. ^32

**33** The sons of the servants of Solomon: the sons of Assaphioth, the sons of Pharida, the sons of Jeeli, the sons of Lozon, the sons of Isdael, the sons of Saphuthi, ^33

**34** the sons of Agia, the sons of Phacareth, the sons of Sabie, the sons of Sarothie, the sons of Masias, the sons of Gas, the sons of Addus, the sons of Subas, the sons of Apherra, the sons of Barodis, the sons of Saphat, the sons of Allon. ^34

**35** All the temple-servants and the sons of the servants of Solomon were three hundred seventy two. ^35

**36** These came up from Thermeleth, and Thelersas, Charaathalan leading them, and Allar; ^36

**37** and they could not show their families, nor their stock, how they were of Israel: the sons of Dalan the son of Ban, the sons of Nekodan, six hundred fifty two. ^37

**38** Of the priests, those who usurped the office of the priesthood and were not found: the sons of Obdia, the sons of Akkos, the sons of Jaddus, who married Augia one of the daughters of Zorzelleus, and was called after his name. ^38

**39** When the description of the kindred of these men was sought in the register and was not found, they were removed from executing the office of the priesthood; ^39

**40** for Nehemias and Attharias told them that they should not be partakers of the holy things until a high priest wearing Urim and Thummim should arise. ^40

**41** So all those of Israel, from twelve years old and upward, beside menservants and women servants, were in number forty two thousand three hundred sixty. ^41

**42** Their menservants and handmaids were seven thousand three hundred thirty and seven; the minstrels and singers, two hundred forty five; ^42

**43** four hundred thirty and five camels, seven thousand thirty six horses, two hundred forty five mules, and five thousand five hundred twenty five beasts of burden. ^43

**44** And some of the chief men of their families, when they came to the temple of God that is in Jerusalem, vowed to set up the house again in its own place according to their ability, ^44

**45** and to give into the holy treasury of the works one thousand minas of gold, five thousand minas of silver, and one hundred priestly vestments. ^45

**46** The priests and the Levites and some of the people lived in Jerusalem and the country. The holy singers also and the gatekeepers and all Israel lived in their villages. ^46

**47** But when the seventh month was at hand, and when the children of Israel were each in their own place, they all came together with one purpose into the broad place before the first porch which is toward the east. ^47

**48** Then Jesus the son of Josedek, his kindred the priests, Zorobabel the son of Salathiel, and his kindred stood up and made the altar of the God of Israel ready ^48

**49** to offer burned sacrifices upon it, in accordance with the express commands in the book of Moses the man of God. ^49

**50** Some people joined them out of the other nations of the land, and they erected the altar upon its own place, because all the nations of the land were hostile to them and oppressed them; and they offered sacrifices at the proper times and burnt offerings to the Lord both morning and evening. ^50

**51** They also held the feast of tabernacles, as it is commanded in the law, and offered sacrifices daily, as appropriate. ^51

**52** After that, they offered the continual oblations and the sacrifices of the Sabbaths, of the new moons, and of all the consecrated feasts. ^52

**53** All those who had made any vow to God began to offer sacrifices to God from the new moon of the seventh month, although the temple of God was not yet built. ^53

**54** They gave money, food, and drink to the masons and carpenters. ^54

**55** They also gave carts to the people of Sidon and Tyre, that they should bring cedar trees from Libanus, and convey them in rafts to the harbor of Joppa, according to the commandment which was written for them by Cyrus king of the Persians. ^55

**56** In the second year after his coming to the temple of God at Jerusalem, in the second month, Zorobabel the son of Salathiel, Jesus the son of Josedek, their kindred, the Levitical priests, and all those who had come to Jerusalem out of the captivity began work. ^56

**57** They laid the foundation of God’s temple on the new moon of the second month, in the second year after they had come to Judea and Jerusalem. ^57

**58** They appointed the Levites who were at least twenty years old over the Lord’s works. Then Jesus, with his sons and kindred, Kadmiel his brother, the sons of Jesus, Emadabun, and the sons of Joda the son of Iliadun, and their sons and kindred, all the Levites, with one accord stood up and started the business, laboring to advance the works in the house of God. So the builders built the Lord’s temple. ^58

**59** The priests stood arrayed in their vestments with musical instruments and trumpets, and the Levites the sons of Asaph with their cymbals, ^59

**60** singing songs of thanksgiving and praising the Lord, according to the directions of King David of Israel. ^60

**61** They sang aloud, praising the Lord in songs of thanksgiving, because his goodness and his glory are forever in all Israel. ^61

**62** All the people sounded trumpets and shouted with a loud voice, singing songs of thanksgiving to the Lord for the raising up of the Lord’s house. ^62

**63** Some of the Levitical priests and of the heads of their families, the elderly who had seen the former house came to the building of this one with lamentation and great weeping. ^63

**64** But many with trumpets and joy shouted with a loud voice, ^64

**65** so that the people couldn’t hear the trumpets for the weeping of the people, for the multitude sounded loudly, so that it was heard far away. ^65

**66** Therefore when the enemies of the tribe of Judah and Benjamin heard it, they came to know what that noise of trumpets meant. ^66

**67** They learned that those who returned from captivity built the temple for the Lord, the God of Israel. ^67

**68** So they went to Zorobabel and Jesus, and to the chief men of the families, and said to them, “We will build together with you. ^68

**69** For we, just like you, obey your Lord, and sacrifice to him from the days of King Asbasareth of the Assyrians, who brought us here.” ^69

**70** Then Zorobabel, Jesus and the chief men of the families of Israel said to them, “It is not for you to build the house for the Lord our God. ^70

**71** We ourselves alone will build for the Lord of Israel, as King Cyrus of the Persians has commanded us.” ^71

**72** But the heathen of the land pressed hard upon the inhabitants of Judea, cut off their supplies, and hindered their building. ^72

**73** By their secret plots, and popular persuasions and commotions, they hindered the finishing of the building all the time that King Cyrus lived. So they were hindered from building for two years, until the reign of Darius. ^73

← [[1 Esdras 4 - WEBU]] | [[1 Esdras 6 - WEBU]] →
