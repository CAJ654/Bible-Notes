---
book: 1 Esdras
chapter: 9
version: WEBU
---
# 1 Esdras 9 (WEBU)

← [[1 Esdras 8 - WEBU]]

**1** Then Esdras rose up from the court of the temple and went to the chamber of Jonas the son of Eliasib, ^1

**2** and lodged there, and ate no bread and drank no water, mourning for the great iniquities of the multitude. ^2

**3** A proclamation was made in all Judea and Jerusalem to all those who returned from captivity, that they should be gathered together at Jerusalem, ^3

**4** and that whoever didn’t meet there within two or three days, in accordance with the ruling of the elders, that their livestock would be seized for the use of the temple, and they would be expelled from the multitude of those who returned from captivity. ^4

**5** Within three days, all those of the tribe of Judah and Benjamin gathered together at Jerusalem. This was the ninth month, on the twentieth day of the month. ^5

**6** All the multitude sat together shivering in the broad place before the temple because of the present foul weather. ^6

**7** So Esdras arose up and said to them, “You have transgressed the law and married foreign wives, increasing the sins of Israel. ^7

**8** Now make confession and give glory to the Lord, the God of our fathers, ^8

**9** and do his will, and separate yourselves from the heathen of the land, and from the foreign women.” ^9

**10** Then the whole multitude cried out, and said with a loud voice, “Just as you have spoken, so we will do. ^10

**11** But because the multitude is great, and it is foul weather, so that we can’t stand outside, and this is not a work of one day or two, seeing our sin in these things has spread far, ^11

**12** therefore let the rulers of the multitude stay, and let all those of our settlements that have foreign wives come at the time appointed, ^12

**13** and with them the rulers and judges of every place, until we turn away the wrath of the Lord from us for this matter.” ^13

**14** So Jonathan the son of Azael and Ezekias the son of Thocanus took the matter on themselves. Mosollamus and Levis and Sabbateus were judges with them. ^14

**15** Those who returned from captivity did according to all these things. ^15

**16** Esdras the priest chose for himself principal men of their families, all by name. On the new moon of the tenth month they met together to examine the matter. ^16

**17** So their cases of men who had foreign wives was brought to an end by the new moon of the first month. ^17

**18** Of the priests who had come together and had foreign wives, there were found ^18

**19** of the sons of Jesus the son of Josedek, and his kindred, Mathelas, Eleazar, and Joribus, and Joadanus. ^19

**20** They gave their hands to put away their wives, and to offer rams to make reconciliation for their error. ^20

**21** Of the sons of Emmer: Ananias, Zabdeus, Manes, Sameus, Hiereel, and Azarias. ^21

**22** Of the sons of Phaisur: Elionas, Massias, Ishmael, Nathanael, Ocidelus, and Saloas. ^22

**23** Of the Levites: Jozabdus, Semeis, Colius who was called Calitas, Patheus, Judas, and Jonas. ^23

**24** Of the holy singers: Eliasibus and Bacchurus. ^24

**25** Of the gatekeepers: Sallumus and Tolbanes. ^25

**26** Of Israel, of the sons of Phoros: Hiermas, Ieddias, Melchias, Maelus, Eleazar, Asibas, and Banneas. ^26

**27** Of the sons of Ela: Matthanias, Zacharias, Jezrielus, Oabdius, Hieremoth, andAedias. ^27

**28** Of the sons of Zamoth: Eliadas, Eliasimus, Othonias, Jarimoth, Sabathus, and Zardeus. ^28

**29** Of the sons of Bebai: Joannes, Ananias, Jozabdus, and Ematheis. ^29

**30** Of the sons of Mani: Olamus, Mamuchus, Jedeus, Jasubas, Jasaelus, and Hieremoth. ^30

**31** Of the sons of Addi: Naathus, Moossias, Laccunus, Naidus, Matthanias, Sesthel, Balnuus, and Manasseas. ^31

**32** Of the sons of Annas: Elionas, Aseas, Melchias, Sabbeus, and Simon Chosameus. ^32

**33** Of the sons of Asom: Maltanneus, Mattathias, Sabanneus, Eliphalat, Manasses, and Semei. ^33

**34** Of the sons of Baani: Jeremias, Momdis, Ismaerus, Juel, Mamdai, Pedias, Anos, Carabasion, Enasibus, Mamnitamenus, Eliasis, Bannus, Eliali, Someis, Selemias, and Nathanias. Of the sons of Ezora: Sesis, Ezril, Azaelus, Samatus, Zambri, and Josephus. ^34

**35** Of the sons of Nooma: Mazitias, Zabadeas, Edos, Juel, and Banaias. ^35

**36** All these had taken foreign wives, and they put them away with their children. ^36

**37** The priests and Levites, and those who were of Israel, lived in Jerusalem and in the country, on the new moon of the seventh month, and the children of Israel in their settlements. ^37

**38** The whole multitude gathered together with one accord into the broad place before the porch of the temple toward the east. ^38

**39** They said to Esdras the priest and reader, “Bring the law of Moses that was given by the Lord, the God of Israel.” ^39

**40** So Esdras the chief priest brought the law to the whole multitude both of men and women, and to all the priests, to hear the law on the new moon of the seventh month. ^40

**41** He read in the broad place before the porch of the temple from morning until midday, before both men and women; and all the multitude gave attention to the law. ^41

**42** Esdras the priest and reader of the law stood up upon the pulpit of wood which had been prepared. ^42

**43** Beside him stood Mattathias, Sammus, Ananias, Azarias, Urias, Ezekias, and Baalsamus on the right hand, ^43

**44** and on his left hand, Phaldeus, Misael, Melchias, Lothasubus, Nabarias, and Zacharias. ^44

**45** Then Esdras took the book of the law before the multitude, and sat honorably in the first place before all. ^45

**46** When he opened the law, they all stood straight up. So Esdras blessed the Lord God Most High, the God of armies, the Almighty. ^46

**47** All the people answered, “Amen.” Lifting up their hands, they fell to the ground and worshiped the Lord. ^47

**48** Also Jesus, Annus, Sarabias, Iadinus, Jacubus, Sabateus, Auteas, Maiannas, Calitas, Azarias, Jozabdus, Ananias, and Phalias, the Levites, taught the law of the Lord, and read to the multitude the law of the Lord, explaining what was read. ^48

**49** Then Attharates said to Esdras the chief priest and reader, and to the Levites who taught the multitude, even to all, ^49

**50** “This day is holy to the Lord—now they all wept when they heard the law— ^50

**51** go then, eat the fat, drink the sweet, and send portions to those who have nothing; ^51

**52** for the day is holy to the Lord. Don’t be sorrowful, for the Lord will bring you to honor.” ^52

**53** So the Levites commanded all things to the people, saying, “This day is holy. Don’t be sorrowful.” ^53

**54** Then they went their way, every one to eat, drink, enjoy themselves, to give portions to those who had nothing, and to rejoice greatly, ^54

**55** because they understood the words they were instructed with, and for which they had been assembled. ^55

← [[1 Esdras 8 - WEBU]]
