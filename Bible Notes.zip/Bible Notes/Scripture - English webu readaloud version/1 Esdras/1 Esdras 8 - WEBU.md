---
book: 1 Esdras
chapter: 8
version: WEBU
---
# 1 Esdras 8 (WEBU)

← [[1 Esdras 7 - WEBU]] | [[1 Esdras 9 - WEBU]] →

**1** After these things, when Artaxerxes the king of the Persians reigned, Esdras came, who was the son of Azaraias, the son of Zechrias, the son of Helkias, the son of Salem, ^1

**2** the son of Sadduk, the son of Ahitob, the son of Amarias, the son of Ozias, the son of Memeroth, the son of Zaraias, the son of Savias, the son of Boccas, the son of Abisne, the son of Phinees, the son of Eleazar, the son of Aaron, the chief priest. ^2

**3** This Esdras went up from Babylon as a skilled scribe in the law of Moses, which was given by the God of Israel. ^3

**4** The king honored him, for he found favor in his sight in all his requests. ^4

**5** There went up with him also some of the children of Israel, and of the priests, Levites, holy singers, gatekeepers, and temple servants to Jerusalem ^5

**6** in the seventh year of the reign of Artaxerxes, in the fifth month (this was the king’s seventh year); for they left Babylon on the new moon of the first month and came to Jerusalem, by the prosperous journey which the Lord gave them for his sake. ^6

**7** For Esdras had very great skill, so that he omitted nothing of the law and commandments of the Lord, but taught all Israel the ordinances and judgments. ^7

**8** Now the commission, which was written from King Artaxerxes, came to Esdras the priest and reader of the law of the Lord, was as follows: ^8

**9** “King Artaxerxes to Esdras the priest and reader of the law of the Lord, greetings. ^9

**10** Having determined to deal graciously, I have given orders that those of the nation of the Jews, and of the priests and Levites, and of those within our realm who are willing and freely choose to, should go with you to Jerusalem. ^10

**11** As many therefore as are so disposed, let them depart with you, as it has seemed good both to me and my seven friends the counselors, ^11

**12** that they may look to the affairs of Judea and Jerusalem, in accordance with what is in the Lord’s law, ^12

**13** and carry the gifts to the Lord of Israel to Jerusalem, which I and my friends have vowed, and that all the gold and silver that can be found in the country of Babylonia for the Lord in Jerusalem, ^13

**14** with that also which is given of the people for the temple of the Lord their God that is at Jerusalem, be collected: even the gold and silver for bulls, rams, and lambs, and what goes with them, ^14

**15** to the end that they may offer sacrifices to the Lord upon the altar of the Lord their God, which is in Jerusalem. ^15

**16** Whatever you and your kindred decide to do with gold and silver, do that according to the will of your God. ^16

**17** The holy vessels of the Lord, which are given you for the use of the temple of your God, which is in Jerusalem, ^17

**18** and whatever else you shall remember for the use of the temple of your God, you shall give it out of the king’s treasury. ^18

**19** I, King Artaxerxes, have also commanded the keepers of the treasures in Syria and Phoenicia, that whatever Esdras the priest and reader of the law of the Most High God shall send for, they should give it to him with all diligence, ^19

**20** to the sum of one hundred talents of silver, likewise also of wheat even to one hundred cors, and one hundred firkins of wine, and salt in abundance. ^20

**21** Let all things be performed after God’s law diligently to the most high God, that wrath come not upon the kingdom of the king and his sons. ^21

**22** I command you also that no tax, nor any other imposition, be laid upon any of the priests, or Levites, or holy singers, or gatekeepers, or temple servants, or any that have employment in this temple, and that no man has authority to impose any tax on them. ^22

**23** You, Esdras, according to the wisdom of God, ordain judges and justices that they may judge in all Syria and Phoenicia all those who know the law of your God; and those who don’t know it, you shall teach. ^23

**24** Whoever transgresses the law of your God and of the king shall be punished diligently, whether it be by death, or other punishment, by penalty of money, or by imprisonment.” ^24

**25** Then Esdras the scribe said, “Blessed be the only Lord, the God of my fathers, who has put these things into the heart of the king, to glorify his house that is in Jerusalem, ^25

**26** and has honored me in the sight of the king, his counselors, and all his friends and nobles. ^26

**27** Therefore I was encouraged by the help of the Lord my God, and gathered together out of Israel men to go up with me. ^27

**28** These are the chiefs according to their families and their several divisions, who went up with me from Babylon in the reign of King Artaxerxes: ^28

**29** of the sons of Phinees, Gerson; of the sons of Ithamar, Gamael; of the sons of David, Attus the son of Sechenias; ^29

**30** of the sons of Phoros, Zacharais; and with him were counted one hundred fifty men; ^30

**31** of the sons of Phaath Moab, Eliaonias the son of Zaraias, and with him two hundred men; ^31

**32** of the sons of Zathoes, Sechenias the son of Jezelus, and with him three hundred men; of the sons of Adin, Obeth the son of Jonathan, and with him two hundred fifty men; ^32

**33** of the sons of Elam, Jesias son of Gotholias, and with him seventy men; ^33

**34** of the sons of Saphatias, Zaraias son of Michael, and with him seventy men; ^34

**35** of the sons of Joab, Abadias son of Jehiel. Jezelus, and with him two hundred twelve men; ^35

**36** of the sons of Banias, Salimoth son of Josaphias, and with him one hundred sixty men; ^36

**37** of the sons of Babi, Zacharias son of Bebai, and with him twenty-eight men; ^37

**38** of the sons of Azgad: Astath, Joannes son of Hakkatan Akatan, and with him one hundred ten men; ^38

**39** of the sons of Adonikam, the last, and these are the names of them, Eliphalat, Jeuel, and Samaias, and with them seventy men; ^39

**40** of the sons of Bago, Uthi the son of Istalcurus, and with him seventy men. ^40

**41** I gathered them together to the river called Theras. There we pitched our tents three days, and I inspected them. ^41

**42** When I had found there none of the priests and Levites, ^42

**43** then sent I to Eleazar, Iduel, Maasmas, ^43

**44** Elnathan, Samaias, Joribus, Nathan, Ennatan, Zacharias, and Mosollamus, principal men and men of understanding. ^44

**45** I asked them to go to Loddeus the captain, who was in the place of the treasury, ^45

**46** and commanded them that they should speak to Loddeus, to his kindred, and to the treasurers in that place, to send us such men as might execute the priests’ office in our Lord’s house. ^46

**47** By the mighty hand of our Lord, they brought to us men of understanding of the sons of Mooli the son of Levi, the son of Israel, Asebebias, and his sons, and his kindred, who were eighteen, ^47

**48** and Asebias, Annuus, and Osaias his brother, of the sons of Chanuneus, and their sons were twenty men; ^48

**49** and of the temple servants whom David and the principal men had appointed for the servants of the Levites, two hundred twenty temple servants. The list of all their names was reported. ^49

**50** There I vowed a fast for the young men before our Lord, to seek from him a prosperous journey both for us and for our children and livestock that were with us; ^50

**51** for I was ashamed to ask of the king infantry, cavalry, and an escort for protection against our adversaries. ^51

**52** For we had said to the king that the power of our Lord would be with those who seek him, to support them in all ways. ^52

**53** Again we prayed to our lord about these things, and found him to be merciful. ^53

**54** Then I set apart twelve men of the chiefs of the priests, Eserebias, Assamias, and ten men of their kindred with them. ^54

**55** I weighed out to them the silver, the gold, and the holy vessels of the house of our Lord, which the king, his counselors, the nobles, and all Israel had given. ^55

**56** When I had weighed it, I delivered to them six hundred fifty talents of silver, silver vessels weighing one hundred talents, one hundred talents of gold, ^56

**57** twenty golden vessels, and twelve vessels of brass, even of fine brass, glittering like gold. ^57

**58** I said to them, “You are holy to the Lord, the vessels are holy, and the gold and the silver are a vow to the Lord, the Lord of our fathers. ^58

**59** Watch and keep them until you deliver them to the chiefs of the priests and Levites, and to the principal men of the families of Israel in Jerusalem, in the chambers of our Lord’s house. ^59

**60** So the priests and the Levites who received the silver, the gold, and the vessels which were in Jerusalem, brought them into the temple of the Lord. ^60

**61** We left the river Theras on the twelfth day of the first month. We came to Jerusalem by the mighty hand of our Lord which was upon us. The Lord delivered us from every enemy on the way, and so we came to Jerusalem. ^61

**62** When we had been there three days, the silver and gold was weighed and delivered in our Lord’s house on the fourth day to Marmoth the priest the son of Urias. ^62

**63** With him was Eleazar the son of Phinees, and with them were Josabdus the son of Jesus and Moeth the son of Sabannus, the Levites. All was delivered to them by number and weight. ^63

**64** All the weight of them was recorded at the same hour. ^64

**65** Moreover those who had come out of captivity offered sacrifices to the Lord, the God of Israel, even twelve bulls for all Israel, ninety-six rams, ^65

**66** seventy-two lambs, and twelve goats for a peace offering—all of them a sacrifice to the Lord. ^66

**67** They delivered the king’s commandments to the king’s stewards and to the governors of Coelesyria and Phoenicia; and they honored the people and the temple of the Lord. ^67

**68** Now when these things were done, the principal men came to me and said, ^68

**69** “The nation of Israel, the princes, the priests, and the Levites haven’t put away from themselves the foreign people of the land nor the uncleannesses of the Gentiles—the Canaanites, Hittites, Pherezites, Jebusites, Moabites, Egyptians, and Edomites. ^69

**70** For both they and their sons have married with their daughters, and the holy seed is mixed with the foreign people of the land. From the beginning of this matter the rulers and the nobles have been partakers of this iniquity.” ^70

**71** And as soon as I had heard these things, I tore my clothes and my holy garment, and plucked the hair from off my head and beard, and sat down sad and full of heaviness. ^71

**72** So all those who were moved at the word of the Lord, the God of Israel, assembled to me while I mourned for the iniquity, but I sat still full of heaviness until the evening sacrifice. ^72

**73** Then rising up from the fast with my clothes and my holy garment torn, and bowing my knees and stretching out my hands to the Lord, ^73

**74** I said, “O Lord, I am ashamed and confounded before your face, ^74

**75** for our sins are multiplied above our heads, and our errors have reached up to heaven ^75

**76** ever since the time of our fathers. We are in great sin, even to this day. ^76

**77** For our sins and our fathers’ sins we with our kindred, our kings, and our priests were given up to the kings of the earth, to the sword, and to captivity, and for a prey with shame, to this day. ^77

**78** Now in some measure mercy has been shown to us from you, O Lord, that there should be left us a root and a name in the place of your sanctuary, ^78

**79** and to uncover a light in the house of the Lord our God, and to give us food in the time of our servitude. ^79

**80** Yes, when we were in bondage, we were not forsaken by our Lord, but he gave us favor before the kings of Persia, so that they gave us food, ^80

**81** glorified the temple of our Lord, and raised up the desolate Zion, to give us a sure dwelling in Judea and Jerusalem. ^81

**82** “Now, O Lord, what shall we say, having these things? For we have transgressed your commandments which you gave by the hand of your servants the prophets, saying, ^82

**83** ‘The land, which you enter into to possess as an inheritance, is a land polluted with the pollutions of the foreigners of the land, and they have filled it with their uncleanness. ^83

**84** Therefore now you shall not join your daughters to their sons, neither shall you take their daughters for your sons. ^84

**85** You shall never seek to have peace with them, that you may be strong, and eat the good things of the land, and that you may leave it for an inheritance to your children for evermore.’ ^85

**86** All that has happened is done to us for our wicked works and great sins, for you, O Lord, made our sins light, ^86

**87** and gave to us such a root; but we have turned back again to transgress your law in mingling ourselves with the uncleanness of the heathen of the land. ^87

**88** You weren’t angry with us to destroy us until you had left us neither root, seed, nor name. ^88

**89** O Lord of Israel, you are true, for we are left a root this day. ^89

**90** Behold, now we are before you in our iniquities, for we can’t stand any longer before you because of these things.” ^90

**91** As Esdras in his prayer made his confession, weeping, and lying flat on the ground before the temple, a very great throng of men, women, and children gathered to him from Jerusalem; for there was great weeping among the multitude. ^91

**92** Then Jechonias the son of Jeelus, one of the sons of Israel, called out, and said, “O Esdras, we have sinned against the Lord God, we have married foreign women of the heathen of the land, but there is still hope for Israel. ^92

**93** Let’s make an oath to the Lord about this, that we will put away all our foreign wives with their children, ^93

**94** as seems good to you, and to as many as obey the Lord’s Law. ^94

**95** Arise, and take action, for this is your task, and we will be with you to do valiantly.” ^95

**96** So Esdras arose, and took an oath from the chief of the priests and Levites of all Israel to do these things; and they swore to it. ^96

← [[1 Esdras 7 - WEBU]] | [[1 Esdras 9 - WEBU]] →
