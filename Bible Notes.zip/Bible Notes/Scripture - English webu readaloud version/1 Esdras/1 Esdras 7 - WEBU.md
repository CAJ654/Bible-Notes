---
book: 1 Esdras
chapter: 7
version: WEBU
---
# 1 Esdras 7 (WEBU)

← [[1 Esdras 6 - WEBU]] | [[1 Esdras 8 - WEBU]] →

**1** Then Sisinnes the governor of Coelesyria and Phoenicia, and Sathrabuzanes, with their companions, following the commandments of King Darius, ^1

**2** very carefully supervised the holy work, assisting the elders of the Jews and rulers of the temple. ^2

**3** So the holy work prospered, while Aggaeus and Zacharias the prophets prophesied. ^3

**4** They finished these things by the commandment of the Lord, the God of Israel, and with the consent of Cyrus, Darius, and Artaxerxes, kings of the Persians. ^4

**5** So the holy house was finished by the twenty-third day of the month Adar, in the sixth year of King Darius. ^5

**6** The children of Israel, the priests, the Levites, and the others who returned from captivity who joined them did what was written in the book of Moses. ^6

**7** For the dedication of the Lord’s temple, they offered one hundred bulls, two hundred rams, four hundred lambs, ^7

**8** and twelve male goats for the sin of all Israel, according to the number of the twelve princes of the tribes of Israel. ^8

**9** The priests and the Levites stood arrayed in their vestments, according to their kindred, for the services of the Lord, the God of Israel, according to the book of Moses. The gatekeepers were at every gate. ^9

**10** The children of Israel who came out of captivity held the Passover the fourteenth day of the first month, when the priests and the Levites were sanctified together, ^10

**11** with all those who returned from captivity; for they were sanctified. For the Levites were all sanctified together, ^11

**12** and they offered the Passover for all who returned from captivity, for their kindred the priests, and for themselves. ^12

**13** The children of Israel who came out of the captivity ate, even all those who had separated themselves from the abominations of the heathen of the land, and sought the Lord. ^13

**14** They kept the feast of unleavened bread seven days, rejoicing before the Lord, ^14

**15** because he had turned the counsel of the king of Assyria toward them, to strengthen their hands in the works of the Lord, the God of Israel. ^15

← [[1 Esdras 6 - WEBU]] | [[1 Esdras 8 - WEBU]] →
