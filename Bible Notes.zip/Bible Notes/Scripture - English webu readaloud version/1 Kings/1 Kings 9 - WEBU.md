---
book: 1 Kings
chapter: 9
version: WEBU
---
# 1 Kings 9 (WEBU)

← [[1 Kings 8 - WEBU]] | [[1 Kings 10 - WEBU]] →

**1** When Solomon had finished the building of the LORD’s house, the king’s house, and all Solomon’s desire which he was pleased to do, ^1

**2** The LORD appeared to Solomon the second time, as he had appeared to him at Gibeon. ^2

**3** The LORD said to him, “I have heard your prayer and your supplication that you have made before me. I have made this house holy, which you have built, to put my name there forever; and my eyes and my heart shall be there perpetually. ^3

**4** As for you, if you will walk before me as David your father walked, in integrity of heart and in uprightness, to do according to all that I have commanded you, and will keep my statutes and my ordinances, ^4

**5** then I will establish the throne of your kingdom over Israel forever, as I promised to David your father, saying, ‘There shall not fail from you a man on the throne of Israel.’ ^5

**6** But if you turn away from following me, you or your children, and not keep my commandments and my statutes which I have set before you, but go and serve other gods and worship them, ^6

**7** then I will cut off Israel out of the land which I have given them; and I will cast this house, which I have made holy for my name, out of my sight; and Israel will be a proverb and a byword among all peoples. ^7

**8** Though this house is so high, yet everyone who passes by it will be astonished and hiss; and they will say, ‘Why has the LORD done this to this land and to this house?’ ^8

**9** and they will answer, ‘Because they abandoned the LORD their God, who brought their fathers out of the land of Egypt, and embraced other gods, and worshiped them, and served them. Therefore the LORD has brought all this evil on them.’” ^9

**10** At the end of twenty years, in which Solomon had built the two houses, the LORD’s house and the king’s house ^10

**11** (now Hiram the king of Tyre had furnished Solomon with cedar trees and cypress trees, and with gold, according to all his desire), King Solomon gave Hiram twenty cities in the land of Galilee. ^11

**12** Hiram came out of Tyre to see the cities which Solomon had given him; and they didn’t please him. ^12

**13** He said, “What cities are these which you have given me, my brother?” He called them the land of Cabul to this day. ^13

**14** Hiram sent to the king one hundred twenty talents of gold. ^14

**15** This is the reason of the forced labor which King Solomon conscripted: to build the LORD’s house, his own house, Millo, Jerusalem’s wall, Hazor, Megiddo, and Gezer. ^15

**16** Pharaoh king of Egypt had gone up, taken Gezer, burned it with fire, killed the Canaanites who lived in the city, and given it for a wedding gift to his daughter, Solomon’s wife. ^16

**17** Solomon built in the land Gezer, Beth Horon the lower, ^17

**18** Baalath, Tamar in the wilderness, ^18

**19** all the storage cities that Solomon had, the cities for his chariots, the cities for his horsemen, and that which Solomon desired to build for his pleasure in Jerusalem, and in Lebanon, and in all the land of his dominion. ^19

**20** As for all the people who were left of the Amorites, the Hittites, the Perizzites, the Hivites, and the Jebusites, who were not of the children of Israel— ^20

**21** their children who were left after them in the land, whom the children of Israel were not able utterly to destroy—of them Solomon raised a levy of bondservants to this day. ^21

**22** But of the children of Israel Solomon made no bondservants; but they were the men of war, his servants, his princes, his captains, and rulers of his chariots and of his horsemen. ^22

**23** These were the five hundred fifty chief officers who were over Solomon’s work, who ruled over the people who labored in the work. ^23

**24** But Pharaoh’s daughter came up out of David’s city to her house which Solomon had built for her. Then he built Millo. ^24

**25** Solomon offered burnt offerings and peace offerings on the altar which he built to the LORD three times per year, burning incense with them on the altar that was before the LORD. So he finished the house. ^25

**26** King Solomon made a fleet of ships in Ezion Geber, which is beside Eloth, on the shore of the Red Sea, in the land of Edom. ^26

**27** Hiram sent in the fleet his servants, sailors who had knowledge of the sea, with the servants of Solomon. ^27

**28** They came to Ophir, and fetched from there gold, four hundred and twenty talents, and brought it to King Solomon. ^28

← [[1 Kings 8 - WEBU]] | [[1 Kings 10 - WEBU]] →
