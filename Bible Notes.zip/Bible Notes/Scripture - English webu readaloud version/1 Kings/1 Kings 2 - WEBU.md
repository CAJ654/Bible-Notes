---
book: 1 Kings
chapter: 2
version: WEBU
---
# 1 Kings 2 (WEBU)

← [[1 Kings 1 - WEBU]] | [[1 Kings 3 - WEBU]] →

**1** Now the days of David came near that he should die; and he commanded Solomon his son, saying, ^1

**2** “I am going the way of all the earth. You be strong therefore, and show yourself a man; ^2

**3** and keep the instruction of the LORD your God, to walk in his ways, to keep his statutes, his commandments, his ordinances, and his testimonies, according to that which is written in the law of Moses, that you may prosper in all that you do and wherever you turn yourself. ^3

**4** Then the LORD may establish his word which he spoke concerning me, saying, ‘If your children are careful of their way, to walk before me in truth with all their heart and with all their soul, there shall not fail you,’ he said, ‘a man on the throne of Israel.’ ^4

**5** “Moreover you know also what Joab the son of Zeruiah did to me, even what he did to the two captains of the armies of Israel, to Abner the son of Ner and to Amasa the son of Jether, whom he killed, and shed the blood of war in peace, and put the blood of war on his sash that was around his waist and in his sandals that were on his feet. ^5

**6** Do therefore according to your wisdom, and don’t let his gray head go down to Sheol in peace. ^6

**7** But show kindness to the sons of Barzillai the Gileadite, and let them be among those who eat at your table; for so they came to me when I fled from Absalom your brother. ^7

**8** “Behold, there is with you Shimei the son of Gera, the Benjamite of Bahurim, who cursed me with a grievous curse in the day when I went to Mahanaim; but he came down to meet me at the Jordan, and I swore to him by the LORD, saying, ‘I will not put you to death with the sword.’ ^8

**9** Now therefore don’t hold him guiltless, for you are a wise man; and you will know what you ought to do to him, and you shall bring his gray head down to Sheol with blood.” ^9

**10** David slept with his fathers, and was buried in David’s city. ^10

**11** The days that David reigned over Israel were forty years; he reigned seven years in Hebron, and he reigned thirty-three years in Jerusalem. ^11

**12** Solomon sat on David his father’s throne; and his kingdom was firmly established. ^12

**13** Then Adonijah the son of Haggith came to Bathsheba the mother of Solomon. She said, “Do you come peaceably?” He said, “Peaceably. ^13

**14** He said moreover, I have something to tell you.” She said, “Say on.” ^14

**15** He said, “You know that the kingdom was mine, and that all Israel set their faces on me, that I should reign. However, the kingdom is turned around, and has become my brother’s; for it was his from the LORD. ^15

**16** Now I ask one petition of you. Don’t deny me.” She said to him, “Say on.” ^16

**17** He said, “Please speak to Solomon the king (for he will not tell you ‘no’), that he give me Abishag the Shunammite as wife.” ^17

**18** Bathsheba said, “All right. I will speak for you to the king.” ^18

**19** Bathsheba therefore went to King Solomon, to speak to him for Adonijah. The king rose up to meet her and bowed himself to her, and sat down on his throne and caused a throne to be set for the king’s mother; and she sat on his right hand. ^19

**20** Then she said, “I ask one small petition of you; don’t deny me.” The king said to her, “Ask on, my mother, for I will not deny you.” ^20

**21** She said, “Let Abishag the Shunammite be given to Adonijah your brother as wife.” ^21

**22** King Solomon answered his mother, “Why do you ask Abishag the Shunammite for Adonijah? Ask for him the kingdom also, for he is my elder brother; even for him, and for Abiathar the priest, and for Joab the son of Zeruiah.” ^22

**23** Then King Solomon swore by the LORD, saying, “God do so to me, and more also, if Adonijah has not spoken this word against his own life. ^23

**24** Now therefore as the LORD lives, who has established me and set me on my father David’s throne, and who has made me a house as he promised, surely Adonijah shall be put to death today.” ^24

**25** King Solomon sent Benaiah the son of Jehoiada; and he fell on him, so that he died. ^25

**26** To Abiathar the priest the king said, “Go to Anathoth, to your own fields, for you are worthy of death. But I will not at this time put you to death, because you bore the Lord GOD’s ark before David my father, and because you were afflicted in all in which my father was afflicted.” ^26

**27** So Solomon thrust Abiathar out from being priest to the LORD, that he might fulfill the LORD’s word which he spoke concerning the house of Eli in Shiloh. ^27

**28** This news came to Joab; for Joab had followed Adonijah, although he didn’t follow Absalom. Joab fled to the LORD’s Tent, and held onto the horns of the altar. ^28

**29** King Solomon was told, “Joab has fled to the LORD’s Tent; and behold, he is by the altar.” Then Solomon sent Benaiah the son of Jehoiada, saying, “Go, fall on him.” ^29

**30** Benaiah came to the LORD’s Tent, and said to him, “The king says, ‘Come out!’” He said, “No; but I will die here.” Benaiah brought the king word again, saying, “This is what Joab said, and this is how he answered me.” ^30

**31** The king said to him, “Do as he has said, and fall on him, and bury him, that you may take away the blood, which Joab shed without cause, from me and from my father’s house. ^31

**32** The LORD will return his blood on his own head, because he fell on two men more righteous and better than he, and killed them with the sword, and my father David didn’t know it: Abner the son of Ner, captain of the army of Israel, and Amasa the son of Jether, captain of the army of Judah. ^32

**33** So their blood will return on the head of Joab and on the head of his offspring forever. But for David, for his offspring, for his house, and for his throne, there will be peace forever from the LORD.” ^33

**34** Then Benaiah the son of Jehoiada went up and fell on him, and killed him; and he was buried in his own house in the wilderness. ^34

**35** The king put Benaiah the son of Jehoiada in his place over the army; and the king put Zadok the priest in the place of Abiathar. ^35

**36** The king sent and called for Shimei, and said to him, “Build yourself a house in Jerusalem, and live there, and don’t go anywhere else. ^36

**37** For on the day you go out and pass over the brook Kidron, know for certain that you will surely die. Your blood will be on your own head.” ^37

**38** Shimei said to the king, “What you say is good. As my lord the king has said, so will your servant do.” Shimei lived in Jerusalem many days. ^38

**39** At the end of three years, two of Shimei’s slaves ran away to Achish, son of Maacah, king of Gath. They told Shimei, saying, “Behold, your slaves are in Gath.” ^39

**40** Shimei arose, saddled his donkey, and went to Gath to Achish to seek his slaves; and Shimei went and brought his slaves from Gath. ^40

**41** Solomon was told that Shimei had gone from Jerusalem to Gath, and had come again. ^41

**42** The king sent and called for Shimei, and said to him, “Didn’t I adjure you by the LORD and warn you, saying, ‘Know for certain that on the day you go out and walk anywhere else, you shall surely die’? You said to me, ‘The saying that I have heard is good.’ ^42

**43** Why then have you not kept the oath of the LORD and the commandment that I have instructed you with?” ^43

**44** The king said moreover to Shimei, “You know in your heart all the wickedness that you did to David my father. Therefore the LORD will return your wickedness on your own head. ^44

**45** But King Solomon will be blessed, and David’s throne will be established before the LORD forever.” ^45

**46** So the king commanded Benaiah the son of Jehoiada; and he went out, and fell on him, so that he died. The kingdom was established in the hand of Solomon. ^46

← [[1 Kings 1 - WEBU]] | [[1 Kings 3 - WEBU]] →
