---
book: 1 Kings
chapter: 22
version: WEBU
---
# 1 Kings 22 (WEBU)

← [[1 Kings 21 - WEBU]]

**1** They continued three years without war between Syria and Israel. ^1

**2** In the third year, Jehoshaphat the king of Judah came down to the king of Israel. ^2

**3** The king of Israel said to his servants, “You know that Ramoth Gilead is ours, and we do nothing, and don’t take it out of the hand of the king of Syria?” ^3

**4** He said to Jehoshaphat, “Will you go with me to battle to Ramoth Gilead?” Jehoshaphat said to the king of Israel, “I am as you are, my people as your people, my horses as your horses.” ^4

**5** Jehoshaphat said to the king of Israel, “Please inquire first for the LORD’s word.” ^5

**6** Then the king of Israel gathered the prophets together, about four hundred men, and said to them, “Should I go against Ramoth Gilead to battle, or should I refrain?” They said, “Go up; for the Lord will deliver it into the hand of the king.” ^6

**7** But Jehoshaphat said, “Isn’t there here a prophet of the LORD, that we may inquire of him?” ^7

**8** The king of Israel said to Jehoshaphat, “There is yet one man by whom we may inquire of the LORD, Micaiah the son of Imlah; but I hate him, for he does not prophesy good concerning me, but evil.” Jehoshaphat said, “Don’t let the king say so.” ^8

**9** Then the king of Israel called an officer, and said, “Quickly get Micaiah the son of Imlah.” ^9

**10** Now the king of Israel and Jehoshaphat the king of Judah were sitting each on his throne, arrayed in their robes, in an open place at the entrance of the gate of Samaria; and all the prophets were prophesying before them. ^10

**11** Zedekiah the son of Chenaanah made himself horns of iron, and said, “The LORD says, ‘With these you will push the Syrians, until they are consumed.’” ^11

**12** All the prophets prophesied so, saying, “Go up to Ramoth Gilead and prosper; for the LORD will deliver it into the hand of the king.” ^12

**13** The messenger who went to call Micaiah spoke to him, saying, “See now, the prophets declare good to the king with one mouth. Please let your word be like the word of one of them, and speak good.” ^13

**14** Micaiah said, “As the LORD lives, what the LORD says to me, that I will speak.” ^14

**15** When he had come to the king, the king said to him, “Micaiah, shall we go to Ramoth Gilead to battle, or shall we forbear?” He answered him, “Go up and prosper; and the LORD will deliver it into the hand of the king.” ^15

**16** The king said to him, “How many times do I have to adjure you that you speak to me nothing but the truth in the LORD’s name?” ^16

**17** He said, “I saw all Israel scattered on the mountains, as sheep that have no shepherd. The LORD said, ‘These have no master. Let them each return to his house in peace.’” ^17

**18** The king of Israel said to Jehoshaphat, “Didn’t I tell you that he would not prophesy good concerning me, but evil?” ^18

**19** Micaiah said, “Therefore hear the LORD’s word. I saw the LORD sitting on his throne, and all the army of heaven standing by him on his right hand and on his left. ^19

**20** The LORD said, ‘Who will entice Ahab, that he may go up and fall at Ramoth Gilead?’ One said one thing, and another said another. ^20

**21** A spirit came out and stood before the LORD, and said, ‘I will entice him.’ ^21

**22** The LORD said to him, ‘How?’ He said, ‘I will go out and will be a lying spirit in the mouth of all his prophets.’ He said, ‘You will entice him, and will also prevail. Go out and do so.’ ^22

**23** Now therefore, behold, the LORD has put a lying spirit in the mouth of all these your prophets; and the LORD has spoken evil concerning you.” ^23

**24** Then Zedekiah the son of Chenaanah came near and struck Micaiah on the cheek, and said, “Which way did the LORD’s Spirit go from me to speak to you?” ^24

**25** Micaiah said, “Behold, you will see on that day when you go into an inner room to hide yourself.” ^25

**26** The king of Israel said, “Take Micaiah, and carry him back to Amon the governor of the city and to Joash the king’s son. ^26

**27** Say, ‘The king says, “Put this fellow in the prison, and feed him with bread of affliction and with water of affliction, until I come in peace.”’” ^27

**28** Micaiah said, “If you return at all in peace, the LORD has not spoken by me.” He said, “Listen, all you people!” ^28

**29** So the king of Israel and Jehoshaphat the king of Judah went up to Ramoth Gilead. ^29

**30** The king of Israel said to Jehoshaphat, “I will disguise myself and go into the battle, but you put on your robes.” The king of Israel disguised himself and went into the battle. ^30

**31** Now the king of Syria had commanded the thirty-two captains of his chariots, saying, “Don’t fight with small nor great, except only with the king of Israel.” ^31

**32** When the captains of the chariots saw Jehoshaphat, they said, “Surely that is the king of Israel!” and they came over to fight against him. Jehoshaphat cried out. ^32

**33** When the captains of the chariots saw that it was not the king of Israel, they turned back from pursuing him. ^33

**34** A certain man drew his bow at random, and struck the king of Israel between the joints of the armor. Therefore he said to the driver of his chariot, “Turn around, and carry me out of the battle, for I am severely wounded.” ^34

**35** The battle increased that day. The king was propped up in his chariot facing the Syrians, and died at evening. The blood ran out of the wound into the bottom of the chariot. ^35

**36** A cry went throughout the army about the going down of the sun, saying, “Every man to his city, and every man to his country!” ^36

**37** So the king died, and was brought to Samaria; and they buried the king in Samaria. ^37

**38** They washed the chariot by the pool of Samaria; and the dogs licked up his blood where the prostitutes washed themselves, according to the LORD’s word which he spoke. ^38

**39** Now the rest of the acts of Ahab, and all that he did, and the ivory house which he built, and all the cities that he built, aren’t they written in the book of the chronicles of the kings of Israel? ^39

**40** So Ahab slept with his fathers; and Ahaziah his son reigned in his place. ^40

**41** Jehoshaphat the son of Asa began to reign over Judah in the fourth year of Ahab king of Israel. ^41

**42** Jehoshaphat was thirty-five years old when he began to reign; and he reigned twenty-five years in Jerusalem. His mother’s name was Azubah the daughter of Shilhi. ^42

**43** He walked in all the way of Asa his father. He didn’t turn away from it, doing that which was right in the LORD’s eyes. However, the high places were not taken away. The people still sacrificed and burned incense on the high places. ^43

**44** Jehoshaphat made peace with the king of Israel. ^44

**45** Now the rest of the acts of Jehoshaphat, and his might that he showed, and how he fought, aren’t they written in the book of the chronicles of the kings of Judah? ^45

**46** The remnant of the sodomites, that remained in the days of his father Asa, he put away out of the land. ^46

**47** There was no king in Edom. A deputy ruled. ^47

**48** Jehoshaphat made ships of Tarshish to go to Ophir for gold, but they didn’t go, for the ships wrecked at Ezion Geber. ^48

**49** Then Ahaziah the son of Ahab said to Jehoshaphat, “Let my servants go with your servants in the ships.” But Jehoshaphat would not. ^49

**50** Jehoshaphat slept with his fathers, and was buried with his fathers in his father David’s city. Jehoram his son reigned in his place. ^50

**51** Ahaziah the son of Ahab began to reign over Israel in Samaria in the seventeenth year of Jehoshaphat king of Judah, and he reigned two years over Israel. ^51

**52** He did that which was evil in the LORD’s sight, and walked in the way of his father, and in the way of his mother, and in the way of Jeroboam the son of Nebat, in which he made Israel to sin. ^52

**53** He served Baal and worshiped him, and provoked the LORD, the God of Israel, to anger in all the ways that his father had done so. ^53

← [[1 Kings 21 - WEBU]]
