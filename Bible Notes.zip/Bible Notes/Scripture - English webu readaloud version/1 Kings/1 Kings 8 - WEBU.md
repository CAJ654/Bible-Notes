---
book: 1 Kings
chapter: 8
version: WEBU
---
# 1 Kings 8 (WEBU)

← [[1 Kings 7 - WEBU]] | [[1 Kings 9 - WEBU]] →

**1** Then Solomon assembled the elders of Israel with all the heads of the tribes, the princes of the fathers’ households of the children of Israel, to King Solomon in Jerusalem, to bring up the ark of the LORD’s covenant out of David’s city, which is Zion. ^1

**2** All the men of Israel assembled themselves to King Solomon at the feast in the month Ethanim, which is the seventh month. ^2

**3** All the elders of Israel came, and the priests picked up the ark. ^3

**4** They brought up the LORD’s ark, the Tent of Meeting, and all the holy vessels that were in the Tent. The priests and the Levites brought these up. ^4

**5** King Solomon and all the congregation of Israel, who were assembled to him, were with him before the ark, sacrificing sheep and cattle that could not be counted or numbered for multitude. ^5

**6** The priests brought in the ark of the LORD’s covenant to its place, into the inner sanctuary of the house, to the most holy place, even under the cherubim’s wings. ^6

**7** For the cherubim spread their wings out over the place of the ark, and the cherubim covered the ark and its poles above. ^7

**8** The poles were so long that the ends of the poles were seen from the holy place before the inner sanctuary, but they were not seen outside. They are there to this day. ^8

**9** There was nothing in the ark except the two stone tablets which Moses put there at Horeb, when the LORD made a covenant with the children of Israel, when they came out of the land of Egypt. ^9

**10** It came to pass, when the priests had come out of the holy place, that the cloud filled the LORD’s house, ^10

**11** so that the priests could not stand to minister by reason of the cloud; for the LORD’s glory filled the LORD’s house. ^11

**12** Then Solomon said, “The LORD has said that he would dwell in the thick darkness. ^12

**13** I have surely built you a house of habitation, a place for you to dwell in forever.” ^13

**14** The king turned his face around and blessed all the assembly of Israel; and all the assembly of Israel stood. ^14

**15** He said, “Blessed is the LORD, the God of Israel, who spoke with his mouth to David your father, and has with his hand fulfilled it, saying, ^15

**16** ‘Since the day that I brought my people Israel out of Egypt, I chose no city out of all the tribes of Israel to build a house, that my name might be there; but I chose David to be over my people Israel.’ ^16

**17** “Now it was in the heart of David my father to build a house for the name of the LORD, the God of Israel. ^17

**18** But the LORD said to David my father, ‘Whereas it was in your heart to build a house for my name, you did well that it was in your heart. ^18

**19** Nevertheless, you shall not build the house; but your son who shall come out of your body, he shall build the house for my name.’ ^19

**20** The LORD has established his word that he spoke; for I have risen up in the place of David my father, and I sit on the throne of Israel, as the LORD promised, and have built the house for the name of the LORD, the God of Israel. ^20

**21** There I have set a place for the ark, in which is the LORD’s covenant, which he made with our fathers when he brought them out of the land of Egypt.” ^21

**22** Solomon stood before the LORD’s altar in the presence of all the assembly of Israel, and spread out his hands toward heaven; ^22

**23** and he said, “LORD, the God of Israel, there is no God like you, in heaven above, or on earth beneath; who keeps covenant and loving kindness with your servants who walk before you with all their heart; ^23

**24** who has kept with your servant David my father that which you promised him. Yes, you spoke with your mouth, and have fulfilled it with your hand, as it is today. ^24

**25** Now therefore, may LORD, the God of Israel, keep with your servant David my father that which you have promised him, saying, ‘There shall not fail from you a man in my sight to sit on the throne of Israel, if only your children take heed to their way, to walk before me as you have walked before me.’ ^25

**26** “Now therefore, God of Israel, please let your word be verified, which you spoke to your servant David my father. ^26

**27** But will God in very deed dwell on the earth? Behold, heaven and the heaven of heavens can’t contain you; how much less this house that I have built! ^27

**28** Yet have respect for the prayer of your servant and for his supplication, LORD my God, to listen to the cry and to the prayer which your servant prays before you today; ^28

**29** that your eyes may be open toward this house night and day, even toward the place of which you have said, ‘My name shall be there;’ to listen to the prayer which your servant prays toward this place. ^29

**30** Listen to the supplication of your servant, and of your people Israel, when they pray toward this place. Yes, hear in heaven, your dwelling place; and when you hear, forgive. ^30

**31** “If a man sins against his neighbor, and an oath is laid on him to cause him to swear, and he comes and swears before your altar in this house, ^31

**32** then hear in heaven, and act, and judge your servants, condemning the wicked, to bring his way on his own head, and justifying the righteous, to give him according to his righteousness. ^32

**33** “When your people Israel are struck down before the enemy because they have sinned against you, if they turn again to you and confess your name, and pray and make supplication to you in this house, ^33

**34** then hear in heaven, and forgive the sin of your people Israel, and bring them again to the land which you gave to their fathers. ^34

**35** “When the sky is shut up and there is no rain because they have sinned against you, if they pray toward this place and confess your name, and turn from their sin when you afflict them, ^35

**36** then hear in heaven, and forgive the sin of your servants, and of your people Israel, when you teach them the good way in which they should walk; and send rain on your land which you have given to your people for an inheritance. ^36

**37** “If there is famine in the land, if there is pestilence, if there is blight, mildew, locust or caterpillar; if their enemy besieges them in the land of their cities, whatever plague, whatever sickness there is, ^37

**38** whatever prayer and supplication is made by any man, or by all your people Israel, who shall each know the plague of his own heart, and spread out his hands toward this house, ^38

**39** then hear in heaven, your dwelling place, and forgive, and act, and give to every man according to all his ways, whose heart you know (for you, even you only, know the hearts of all the children of men); ^39

**40** that they may fear you all the days that they live in the land which you gave to our fathers. ^40

**41** “Moreover, concerning the foreigner, who is not of your people Israel, when he comes out of a far country for your name’s sake ^41

**42** (for they shall hear of your great name and of your mighty hand and of your outstretched arm), when he comes and prays toward this house, ^42

**43** hear in heaven, your dwelling place, and do according to all that the foreigner calls to you for; that all the peoples of the earth may know your name, to fear you, as do your people Israel, and that they may know that this house which I have built is called by your name. ^43

**44** “If your people go out to battle against their enemy, by whatever way you shall send them, and they pray to the LORD toward the city which you have chosen, and toward the house which I have built for your name, ^44

**45** then hear in heaven their prayer and their supplication, and maintain their cause. ^45

**46** If they sin against you (for there is no man who doesn’t sin), and you are angry with them and deliver them to the enemy, so that they carry them away captive to the land of the enemy, far off or near; ^46

**47** yet if they repent in the land where they are carried captive, and turn again, and make supplication to you in the land of those who carried them captive, saying, ‘We have sinned and have done perversely; we have dealt wickedly,’ ^47

**48** if they return to you with all their heart and with all their soul in the land of their enemies who carried them captive, and pray to you toward their land which you gave to their fathers, the city which you have chosen and the house which I have built for your name, ^48

**49** then hear their prayer and their supplication in heaven, your dwelling place, and maintain their cause; ^49

**50** and forgive your people who have sinned against you, and all their transgressions in which they have transgressed against you; and give them compassion before those who carried them captive, that they may have compassion on them ^50

**51** (for they are your people and your inheritance, which you brought out of Egypt, from the middle of the iron furnace); ^51

**52** that your eyes may be open to the supplication of your servant and to the supplication of your people Israel, to listen to them whenever they cry to you. ^52

**53** For you separated them from among all the peoples of the earth to be your inheritance, as you spoke by Moses your servant, when you brought our fathers out of Egypt, Lord GOD.” ^53

**54** It was so, that when Solomon had finished praying all this prayer and supplication to the LORD, he arose from before the LORD’s altar, from kneeling on his knees with his hands spread out toward heaven. ^54

**55** He stood and blessed all the assembly of Israel with a loud voice, saying, ^55

**56** “Blessed be the LORD, who has given rest to his people Israel, according to all that he promised. There has not failed one word of all his good promise, which he promised by Moses his servant. ^56

**57** May the LORD our God be with us as he was with our fathers. Let him not leave us or forsake us, ^57

**58** that he may incline our hearts to him, to walk in all his ways, and to keep his commandments, his statutes, and his ordinances, which he commanded our fathers. ^58

**59** Let these my words, with which I have made supplication before the LORD, be near to the LORD our God day and night, that he may maintain the cause of his servant and the cause of his people Israel, as every day requires; ^59

**60** that all the peoples of the earth may know that the LORD himself is God. There is no one else. ^60

**61** “Let your heart therefore be perfect with the LORD our God, to walk in his statutes, and to keep his commandments, as it is today.” ^61

**62** The king, and all Israel with him, offered sacrifice before the LORD. ^62

**63** Solomon offered for the sacrifice of peace offerings, which he offered to the LORD, twenty two thousand head of cattle and one hundred twenty thousand sheep. So the king and all the children of Israel dedicated the LORD’s house. ^63

**64** The same day the king made the middle of the court holy that was before the LORD’s house; for there he offered the burnt offering, the meal offering, and the fat of the peace offerings, because the bronze altar that was before the LORD was too little to receive the burnt offering, the meal offering, and the fat of the peace offerings. ^64

**65** So Solomon held the feast at that time, and all Israel with him, a great assembly, from the entrance of Hamath to the brook of Egypt, before the LORD our God, seven days and seven more days, even fourteen days. ^65

**66** On the eighth day he sent the people away; and they blessed the king, and went to their tents joyful and glad in their hearts for all the goodness that the LORD had shown to David his servant, and to Israel his people. ^66

← [[1 Kings 7 - WEBU]] | [[1 Kings 9 - WEBU]] →
