---
book: 1 Kings
chapter: 12
version: WEBU
---
# 1 Kings 12 (WEBU)

← [[1 Kings 11 - WEBU]] | [[1 Kings 13 - WEBU]] →

**1** Rehoboam went to Shechem, for all Israel had come to Shechem to make him king. ^1

**2** When Jeroboam the son of Nebat heard of it (for he was yet in Egypt, where he had fled from the presence of King Solomon, and Jeroboam lived in Egypt; ^2

**3** and they sent and called him), Jeroboam and all the assembly of Israel came, and spoke to Rehoboam, saying, ^3

**4** “Your father made our yoke difficult. Now therefore make the hard service of your father, and his heavy yoke which he put on us, lighter, and we will serve you.” ^4

**5** He said to them, “Depart for three days, then come back to me.” So the people departed. ^5

**6** King Rehoboam took counsel with the old men who had stood before Solomon his father while he yet lived, saying, “What counsel do you give me to answer these people?” ^6

**7** They replied, “If you will be a servant to this people today, and will serve them, and answer them with good words, then they will be your servants forever.” ^7

**8** But he abandoned the counsel of the old men which they had given him, and took counsel with the young men who had grown up with him, who stood before him. ^8

**9** He said to them, “What counsel do you give, that we may answer these people who have spoken to me, saying, ‘Make the yoke that your father put on us lighter’?” ^9

**10** The young men who had grown up with him said to him, “Tell these people who spoke to you, saying, ‘Your father made our yoke heavy, but make it lighter to us’—tell them, ‘My little finger is thicker than my father’s waist. ^10

**11** Now my father burdened you with a heavy yoke, but I will add to your yoke. My father chastised you with whips, but I will chastise you with scorpions.’” ^11

**12** So Jeroboam and all the people came to Rehoboam the third day, as the king asked, saying, “Come to me again the third day.” ^12

**13** The king answered the people roughly, and abandoned the counsel of the old men which they had given him, ^13

**14** and spoke to them according to the counsel of the young men, saying, “My father made your yoke heavy, but I will add to your yoke. My father chastised you with whips, but I will chastise you with scorpions.” ^14

**15** So the king didn’t listen to the people; for it was a thing brought about from the LORD, that he might establish his word, which the LORD spoke by Ahijah the Shilonite to Jeroboam the son of Nebat. ^15

**16** When all Israel saw that the king didn’t listen to them, the people answered the king, saying, “What portion have we in David? We don’t have an inheritance in the son of Jesse. To your tents, Israel! Now see to your own house, David.” So Israel departed to their tents. ^16

**17** But as for the children of Israel who lived in the cities of Judah, Rehoboam reigned over them. ^17

**18** Then King Rehoboam sent Adoram, who was over the men subject to forced labor; and all Israel stoned him to death with stones. King Rehoboam hurried to get himself up to his chariot, to flee to Jerusalem. ^18

**19** So Israel rebelled against David’s house to this day. ^19

**20** When all Israel heard that Jeroboam had returned, they sent and called him to the congregation, and made him king over all Israel. There was no one who followed David’s house, except for the tribe of Judah only. ^20

**21** When Rehoboam had come to Jerusalem, he assembled all the house of Judah and the tribe of Benjamin, a hundred and eighty thousand chosen men who were warriors, to fight against the house of Israel, to bring the kingdom again to Rehoboam the son of Solomon. ^21

**22** But the word of God came to Shemaiah the man of God, saying, ^22

**23** “Speak to Rehoboam the son of Solomon, king of Judah, and to all the house of Judah and Benjamin, and to the rest of the people, saying, ^23

**24** ‘The LORD says, “You shall not go up or fight against your brothers, the children of Israel. Everyone return to his house; for this thing is from me.”’” So they listened to the LORD’s word, and returned and went their way, according to the LORD’s word. ^24

**25** Then Jeroboam built Shechem in the hill country of Ephraim, and lived in it; and he went out from there and built Penuel. ^25

**26** Jeroboam said in his heart, “Now the kingdom will return to David’s house. ^26

**27** If this people goes up to offer sacrifices in the LORD’s house at Jerusalem, then the heart of this people will turn again to their lord, even to Rehoboam king of Judah; and they will kill me, and return to Rehoboam king of Judah.” ^27

**28** So the king took counsel, and made two calves of gold; and he said to them, “It is too much for you to go up to Jerusalem. Look and behold your gods, Israel, which brought you up out of the land of Egypt!” ^28

**29** He set the one in Bethel, and the other he put in Dan. ^29

**30** This thing became a sin, for the people went even as far as Dan to worship before the one there. ^30

**31** He made houses of high places, and made priests from among all the people, who were not of the sons of Levi. ^31

**32** Jeroboam ordained a feast in the eighth month, on the fifteenth day of the month, like the feast that is in Judah, and he went up to the altar. He did so in Bethel, sacrificing to the calves that he had made, and he placed in Bethel the priests of the high places that he had made. ^32

**33** He went up to the altar which he had made in Bethel on the fifteenth day in the eighth month, even in the month which he had devised of his own heart; and he ordained a feast for the children of Israel, and went up to the altar to burn incense. ^33

← [[1 Kings 11 - WEBU]] | [[1 Kings 13 - WEBU]] →
