---
book: 1 Kings
chapter: 13
version: WEBU
---
# 1 Kings 13 (WEBU)

← [[1 Kings 12 - WEBU]] | [[1 Kings 14 - WEBU]] →

**1** Behold, a man of God came out of Judah by the LORD’s word to Bethel; and Jeroboam was standing by the altar to burn incense. ^1

**2** He cried against the altar by the LORD’s word, and said, “Altar! Altar! The LORD says: ‘Behold, a son will be born to David’s house, Josiah by name. On you he will sacrifice the priests of the high places who burn incense on you, and they will burn men’s bones on you.’” ^2

**3** He gave a sign the same day, saying, “This is the sign which the LORD has spoken: Behold, the altar will be split apart, and the ashes that are on it will be poured out.” ^3

**4** When the king heard the saying of the man of God, which he cried against the altar in Bethel, Jeroboam put out his hand from the altar, saying, “Seize him!” His hand, which he put out against him, dried up, so that he could not draw it back again to himself. ^4

**5** The altar was also split apart, and the ashes poured out from the altar, according to the sign which the man of God had given by the LORD’s word. ^5

**6** The king answered the man of God, “Now intercede for the favor of the LORD your God, and pray for me, that my hand may be restored to me.” The man of God interceded with the LORD, and the king’s hand was restored to him, and became as it was before. ^6

**7** The king said to the man of God, “Come home with me and refresh yourself, and I will give you a reward.” ^7

**8** The man of God said to the king, “Even if you gave me half of your house, I would not go in with you, neither would I eat bread nor drink water in this place; ^8

**9** for so was it commanded me by the LORD’s word, saying, ‘You shall eat no bread, drink no water, and don’t return by the way that you came.’” ^9

**10** So he went another way, and didn’t return by the way that he came to Bethel. ^10

**11** Now an old prophet lived in Bethel, and one of his sons came and told him all the works that the man of God had done that day in Bethel. They also told their father the words which he had spoken to the king. ^11

**12** Their father said to them, “Which way did he go?” Now his sons had seen which way the man of God went, who came from Judah. ^12

**13** He said to his sons, “Saddle the donkey for me.” So they saddled the donkey for him; and he rode on it. ^13

**14** He went after the man of God, and found him sitting under an oak. He said to him, “Are you the man of God who came from Judah?” He said, “I am.” ^14

**15** Then he said to him, “Come home with me and eat bread.” ^15

**16** He said, “I may not return with you, nor go in with you. I will not eat bread or drink water with you in this place. ^16

**17** For it was said to me by the LORD’s word, ‘You shall eat no bread or drink water there, and don’t turn again to go by the way that you came.’” ^17

**18** He said to him, “I also am a prophet as you are; and an angel spoke to me by the LORD’s word, saying, ‘Bring him back with you into your house, that he may eat bread and drink water.’” He lied to him. ^18

**19** So he went back with him, ate bread in his house, and drank water. ^19

**20** As they sat at the table, the LORD’s word came to the prophet who brought him back; ^20

**21** and he cried out to the man of God who came from Judah, saying, “The LORD says, ‘Because you have been disobedient to the LORD’s word, and have not kept the commandment which the LORD your God commanded you, ^21

**22** but came back, and have eaten bread and drank water in the place of which he said to you, “Eat no bread, and drink no water,” your body will not come to the tomb of your fathers.’” ^22

**23** After he had eaten bread and after he drank, he saddled the donkey for the prophet whom he had brought back. ^23

**24** When he had gone, a lion met him by the way and killed him. His body was thrown on the path, and the donkey stood by it. The lion also stood by the body. ^24

**25** Behold, men passed by and saw the body thrown on the path, and the lion standing by the body; and they came and told it in the city where the old prophet lived. ^25

**26** When the prophet who brought him back from the way heard of it, he said, “It is the man of God who was disobedient to the LORD’s word. Therefore the LORD has delivered him to the lion, which has mauled him and slain him, according to the LORD’s word which he spoke to him.” ^26

**27** He said to his sons, saying, “Saddle the donkey for me,” and they saddled it. ^27

**28** He went and found his body thrown on the path, and the donkey and the lion standing by the body. The lion had not eaten the body nor mauled the donkey. ^28

**29** The prophet took up the body of the man of God, and laid it on the donkey, and brought it back. He came to the city of the old prophet to mourn, and to bury him. ^29

**30** He laid his body in his own grave; and they mourned over him, saying, “Alas, my brother!” ^30

**31** After he had buried him, he spoke to his sons, saying, “When I am dead, bury me in the tomb in which the man of God is buried. Lay my bones beside his bones. ^31

**32** For the saying which he cried by the LORD’s word against the altar in Bethel, and against all the houses of the high places which are in the cities of Samaria, will surely happen.” ^32

**33** After this thing, Jeroboam didn’t turn from his evil way, but again made priests of the high places from among all the people. Whoever wanted to, he consecrated him, that there might be priests of the high places. ^33

**34** This thing became sin to the house of Jeroboam, even to cut it off and to destroy it from off the surface of the earth. ^34

← [[1 Kings 12 - WEBU]] | [[1 Kings 14 - WEBU]] →
