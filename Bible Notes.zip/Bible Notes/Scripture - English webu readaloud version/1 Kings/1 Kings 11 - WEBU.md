---
book: 1 Kings
chapter: 11
version: WEBU
---
# 1 Kings 11 (WEBU)

← [[1 Kings 10 - WEBU]] | [[1 Kings 12 - WEBU]] →

**1** Now King Solomon loved many foreign women, together with the daughter of Pharaoh: women of the Moabites, Ammonites, Edomites, Sidonians, and Hittites, ^1

**2** of the nations concerning which the LORD said to the children of Israel, “You shall not go among them, neither shall they come among you, for surely they will turn away your heart after their gods.” Solomon joined to these in love. ^2

**3** He had seven hundred wives, princesses, and three hundred concubines. His wives turned his heart away. ^3

**4** When Solomon was old, his wives turned away his heart after other gods; and his heart was not perfect with the LORD his God, as the heart of David his father was. ^4

**5** For Solomon went after Ashtoreth the goddess of the Sidonians, and after Milcom the abomination of the Ammonites. ^5

**6** Solomon did that which was evil in the LORD’s sight, and didn’t go fully after the LORD, as David his father did. ^6

**7** Then Solomon built a high place for Chemosh the abomination of Moab, on the mountain that is before Jerusalem, and for Molech the abomination of the children of Ammon. ^7

**8** So he did for all his foreign wives, who burned incense and sacrificed to their gods. ^8

**9** The LORD was angry with Solomon, because his heart was turned away from the LORD, the God of Israel, who had appeared to him twice, ^9

**10** and had commanded him concerning this thing, that he should not go after other gods; but he didn’t keep that which the LORD commanded. ^10

**11** Therefore the LORD said to Solomon, “Because this is done by you, and you have not kept my covenant and my statutes, which I have commanded you, I will surely tear the kingdom from you, and will give it to your servant. ^11

**12** Nevertheless, I will not do it in your days, for David your father’s sake; but I will tear it out of your son’s hand. ^12

**13** However, I will not tear away all the kingdom; but I will give one tribe to your son, for David my servant’s sake, and for Jerusalem’s sake which I have chosen.” ^13

**14** The LORD raised up an adversary to Solomon: Hadad the Edomite. He was one of the king’s offspring in Edom. ^14

**15** For when David was in Edom, and Joab the captain of the army had gone up to bury the slain, and had struck every male in Edom ^15

**16** (for Joab and all Israel remained there six months, until he had cut off every male in Edom), ^16

**17** Hadad fled, he and certain Edomites of his father’s servants with him, to go into Egypt, when Hadad was still a little child. ^17

**18** They arose out of Midian and came to Paran; and they took men with them out of Paran, and they came to Egypt, to Pharaoh king of Egypt, who gave him a house, and appointed him food, and gave him land. ^18

**19** Hadad found great favor in the sight of Pharaoh, so that he gave him as wife the sister of his own wife, the sister of Tahpenes the queen. ^19

**20** The sister of Tahpenes bore him Genubath his son, whom Tahpenes weaned in Pharaoh’s house; and Genubath was in Pharaoh’s house among the sons of Pharaoh. ^20

**21** When Hadad heard in Egypt that David slept with his fathers, and that Joab the captain of the army was dead, Hadad said to Pharaoh, “Let me depart, that I may go to my own country.” ^21

**22** Then Pharaoh said to him, “But what have you lacked with me, that behold, you seek to go to your own country?” He answered, “Nothing, however only let me depart.” ^22

**23** God raised up an adversary to him, Rezon the son of Eliada, who had fled from his lord, Hadadezer king of Zobah. ^23

**24** He gathered men to himself, and became captain over a troop, when David killed them of Zobah. They went to Damascus and lived there, and reigned in Damascus. ^24

**25** He was an adversary to Israel all the days of Solomon, in addition to the mischief of Hadad. He abhorred Israel, and reigned over Syria. ^25

**26** Jeroboam the son of Nebat, an Ephraimite of Zeredah, a servant of Solomon, whose mother’s name was Zeruah, a widow, also lifted up his hand against the king. ^26

**27** This was the reason why he lifted up his hand against the king: Solomon built Millo, and repaired the breach of his father David’s city. ^27

**28** The man Jeroboam was a mighty man of valor; and Solomon saw that the young man was industrious, and he put him in charge of all the labor of the house of Joseph. ^28

**29** At that time, when Jeroboam went out of Jerusalem, the prophet Ahijah the Shilonite found him on the way. Now Ahijah had clad himself with a new garment; and the two of them were alone in the field. ^29

**30** Ahijah took the new garment that was on him, and tore it in twelve pieces. ^30

**31** He said to Jeroboam, “Take ten pieces; for the LORD, the God of Israel, says, ‘Behold, I will tear the kingdom out of the hand of Solomon and will give ten tribes to you ^31

**32** (but he shall have one tribe, for my servant David’s sake and for Jerusalem’s sake, the city which I have chosen out of all the tribes of Israel), ^32

**33** because they have forsaken me, and have worshiped Ashtoreth the goddess of the Sidonians, Chemosh the god of Moab, and Milcom the god of the children of Ammon. They have not walked in my ways, to do that which is right in my eyes, and to keep my statutes and my ordinances, as David his father did. ^33

**34** “‘However, I will not take the whole kingdom out of his hand, but I will make him prince all the days of his life for David my servant’s sake whom I chose, who kept my commandments and my statutes, ^34

**35** but I will take the kingdom out of his son’s hand and will give it to you, even ten tribes. ^35

**36** I will give one tribe to his son, that David my servant may have a lamp always before me in Jerusalem, the city which I have chosen for myself to put my name there. ^36

**37** I will take you, and you shall reign according to all that your soul desires, and shall be king over Israel. ^37

**38** It shall be, if you will listen to all that I command you, and will walk in my ways, and do that which is right in my eyes, to keep my statutes and my commandments, as David my servant did, that I will be with you, and will build you a sure house, as I built for David, and will give Israel to you. ^38

**39** I will afflict the offspring of David for this, but not forever.’” ^39

**40** Therefore Solomon sought to kill Jeroboam, but Jeroboam arose and fled into Egypt, to Shishak king of Egypt, and was in Egypt until the death of Solomon. ^40

**41** Now the rest of the acts of Solomon, and all that he did, and his wisdom, aren’t they written in the book of the acts of Solomon? ^41

**42** The time that Solomon reigned in Jerusalem over all Israel was forty years. ^42

**43** Solomon slept with his fathers, and was buried in his father David’s city; and Rehoboam his son reigned in his place. ^43

← [[1 Kings 10 - WEBU]] | [[1 Kings 12 - WEBU]] →
