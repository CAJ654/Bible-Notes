---
book: 1 Kings
chapter: 14
version: WEBU
---
# 1 Kings 14 (WEBU)

← [[1 Kings 13 - WEBU]] | [[1 Kings 15 - WEBU]] →

**1** At that time Abijah the son of Jeroboam became sick. ^1

**2** Jeroboam said to his wife, “Please get up and disguise yourself, so that you won’t be recognized as Jeroboam’s wife. Go to Shiloh. Behold, Ahijah the prophet is there, who said that I would be king over this people. ^2

**3** Take with you ten loaves of bread, some cakes, and a jar of honey, and go to him. He will tell you what will become of the child.” ^3

**4** Jeroboam’s wife did so, and arose and went to Shiloh, and came to Ahijah’s house. Now Ahijah could not see, for his eyes were set by reason of his age. ^4

**5** The LORD said to Ahijah, “Behold, Jeroboam’s wife is coming to inquire of you concerning her son, for he is sick. Tell her such and such; for it will be, when she comes in, that she will pretend to be another woman.” ^5

**6** So when Ahijah heard the sound of her feet as she came in at the door, he said, “Come in, Jeroboam’s wife! Why do you pretend to be another? For I am sent to you with heavy news. ^6

**7** Go, tell Jeroboam, ‘The LORD, the God of Israel, says: “Because I exalted you from among the people, and made you prince over my people Israel, ^7

**8** and tore the kingdom away from David’s house, and gave it to you; and yet you have not been as my servant David, who kept my commandments, and who followed me with all his heart, to do that only which was right in my eyes, ^8

**9** but have done evil above all who were before you, and have gone and made for yourself other gods, molten images, to provoke me to anger, and have cast me behind your back, ^9

**10** therefore, behold, I will bring evil on the house of Jeroboam, and will cut off from Jeroboam everyone who urinates on a wall, he who is shut up and he who is left at large in Israel, and will utterly sweep away the house of Jeroboam, as a man sweeps away dung until it is all gone. ^10

**11** The dogs will eat whoever belongs to Jeroboam who dies in the city; and the birds of the sky will eat whoever dies in the field, for the LORD has spoken it.”’ ^11

**12** Arise therefore, and go to your house. When your feet enter into the city, the child will die. ^12

**13** All Israel will mourn for him and bury him; for he only of Jeroboam will come to the grave, because in him there is found some good thing toward the LORD, the God of Israel, in the house of Jeroboam. ^13

**14** Moreover the LORD will raise up a king for himself over Israel who will cut off the house of Jeroboam. This is the day! What? Even now. ^14

**15** For the LORD will strike Israel, as a reed is shaken in the water; and he will root up Israel out of this good land which he gave to their fathers, and will scatter them beyond the River, because they have made their Asherah poles, provoking the LORD to anger. ^15

**16** He will give Israel up because of the sins of Jeroboam, which he has sinned, and with which he has made Israel to sin.” ^16

**17** Jeroboam’s wife arose and departed, and came to Tirzah. As she came to the threshold of the house, the child died. ^17

**18** All Israel buried him and mourned for him, according to the LORD’s word, which he spoke by his servant Ahijah the prophet. ^18

**19** The rest of the acts of Jeroboam, how he fought and how he reigned, behold, they are written in the book of the chronicles of the kings of Israel. ^19

**20** The days which Jeroboam reigned were twenty two years; then he slept with his fathers, and Nadab his son reigned in his place. ^20

**21** Rehoboam the son of Solomon reigned in Judah. Rehoboam was forty-one years old when he began to reign, and he reigned seventeen years in Jerusalem, the city which the LORD had chosen out of all the tribes of Israel, to put his name there. His mother’s name was Naamah the Ammonitess. ^21

**22** Judah did that which was evil in the LORD’s sight, and they provoked him to jealousy with their sins which they committed, above all that their fathers had done. ^22

**23** For they also built for themselves high places, sacred pillars, and Asherah poles on every high hill and under every green tree. ^23

**24** There were also sodomites in the land. They did according to all the abominations of the nations which the LORD drove out before the children of Israel. ^24

**25** In the fifth year of King Rehoboam, Shishak king of Egypt came up against Jerusalem; ^25

**26** and he took away the treasures of the LORD’s house and the treasures of the king’s house. He even took away all of it, including all the gold shields which Solomon had made. ^26

**27** King Rehoboam made shields of bronze in their place, and committed them to the hands of the captains of the guard, who guarded the door of the king’s house. ^27

**28** It was so, that as often as the king went into the LORD’s house, the guard bore them, and brought them back into the guard room. ^28

**29** Now the rest of the acts of Rehoboam, and all that he did, aren’t they written in the book of the chronicles of the kings of Judah? ^29

**30** There was war between Rehoboam and Jeroboam continually. ^30

**31** Rehoboam slept with his fathers, and was buried with his fathers in David’s city. His mother’s name was Naamah the Ammonitess. Abijam his son reigned in his place. ^31

← [[1 Kings 13 - WEBU]] | [[1 Kings 15 - WEBU]] →
