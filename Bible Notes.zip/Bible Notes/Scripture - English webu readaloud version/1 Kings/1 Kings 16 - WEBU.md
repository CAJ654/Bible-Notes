---
book: 1 Kings
chapter: 16
version: WEBU
---
# 1 Kings 16 (WEBU)

← [[1 Kings 15 - WEBU]] | [[1 Kings 17 - WEBU]] →

**1** The LORD’s word came to Jehu the son of Hanani against Baasha, saying, ^1

**2** “Because I exalted you out of the dust and made you prince over my people Israel, and you have walked in the way of Jeroboam and have made my people Israel to sin, to provoke me to anger with their sins, ^2

**3** behold, I will utterly sweep away Baasha and his house; and I will make your house like the house of Jeroboam the son of Nebat. ^3

**4** The dogs will eat Baasha’s descendants who die in the city; and he who dies of his in the field, the birds of the sky will eat.” ^4

**5** Now the rest of the acts of Baasha, and what he did, and his might, aren’t they written in the book of the chronicles of the kings of Israel? ^5

**6** Baasha slept with his fathers, and was buried in Tirzah; and Elah his son reigned in his place. ^6

**7** Moreover the LORD’s word came by the prophet Jehu the son of Hanani against Baasha and against his house, both because of all the evil that he did in the LORD’s sight, to provoke him to anger with the work of his hands, in being like the house of Jeroboam, and because he struck him. ^7

**8** In the twenty-sixth year of Asa king of Judah, Elah the son of Baasha began to reign over Israel in Tirzah for two years. ^8

**9** His servant Zimri, captain of half his chariots, conspired against him. Now he was in Tirzah, drinking himself drunk in the house of Arza, who was over the household in Tirzah; ^9

**10** and Zimri went in and struck him and killed him in the twenty-seventh year of Asa king of Judah, and reigned in his place. ^10

**11** When he began to reign, as soon as he sat on his throne, he attacked all the house of Baasha. He didn’t leave him a single one who urinates on a wall among his relatives or his friends. ^11

**12** Thus Zimri destroyed all the house of Baasha, according to the LORD’s word which he spoke against Baasha by Jehu the prophet, ^12

**13** for all the sins of Baasha, and the sins of Elah his son, which they sinned and with which they made Israel to sin, to provoke the LORD, the God of Israel, to anger with their vanities. ^13

**14** Now the rest of the acts of Elah, and all that he did, aren’t they written in the book of the chronicles of the kings of Israel? ^14

**15** In the twenty-seventh year of Asa king of Judah, Zimri reigned seven days in Tirzah. Now the people were encamped against Gibbethon, which belonged to the Philistines. ^15

**16** The people who were encamped heard that Zimri had conspired, and had also killed the king. Therefore all Israel made Omri, the captain of the army, king over Israel that day in the camp. ^16

**17** Omri went up from Gibbethon, and all Israel with him, and they besieged Tirzah. ^17

**18** When Zimri saw that the city was taken, he went into the fortified part of the king’s house and burned the king’s house over him with fire, and died, ^18

**19** for his sins which he sinned in doing that which was evil in the LORD’s sight, in walking in the way of Jeroboam, and in his sin which he did to make Israel to sin. ^19

**20** Now the rest of the acts of Zimri, and his treason that he committed, aren’t they written in the book of the chronicles of the kings of Israel? ^20

**21** Then the people of Israel were divided into two parts: half of the people followed Tibni the son of Ginath, to make him king, and half followed Omri. ^21

**22** But the people who followed Omri prevailed against the people who followed Tibni the son of Ginath; so Tibni died, and Omri reigned. ^22

**23** In the thirty-first year of Asa king of Judah, Omri began to reign over Israel for twelve years. He reigned six years in Tirzah. ^23

**24** He bought the hill Samaria of Shemer for two talents of silver; and he built on the hill, and called the name of the city which he built, Samaria, after the name of Shemer, the owner of the hill. ^24

**25** Omri did that which was evil in the LORD’s sight, and dealt wickedly above all who were before him. ^25

**26** For he walked in all the way of Jeroboam the son of Nebat, and in his sins with which he made Israel to sin, to provoke the LORD, the God of Israel, to anger with their vanities. ^26

**27** Now the rest of the acts of Omri which he did, and his might that he showed, aren’t they written in the book of the chronicles of the kings of Israel? ^27

**28** So Omri slept with his fathers, and was buried in Samaria; and Ahab his son reigned in his place. ^28

**29** In the thirty-eighth year of Asa king of Judah, Ahab the son of Omri began to reign over Israel. Ahab the son of Omri reigned over Israel in Samaria twenty-two years. ^29

**30** Ahab the son of Omri did that which was evil in the LORD’s sight above all that were before him. ^30

**31** As if it had been a light thing for him to walk in the sins of Jeroboam the son of Nebat, he took as wife Jezebel the daughter of Ethbaal king of the Sidonians, and went and served Baal and worshiped him. ^31

**32** He raised up an altar for Baal in the house of Baal, which he had built in Samaria. ^32

**33** Ahab made the Asherah; and Ahab did more yet to provoke the LORD, the God of Israel, to anger than all the kings of Israel who were before him. ^33

**34** In his days Hiel the Bethelite built Jericho. He laid its foundation with the loss of Abiram his firstborn, and set up its gates with the loss of his youngest son Segub, according to the LORD’s word, which he spoke by Joshua the son of Nun. ^34

← [[1 Kings 15 - WEBU]] | [[1 Kings 17 - WEBU]] →
