---
book: 1 Kings
chapter: 19
version: WEBU
---
# 1 Kings 19 (WEBU)

← [[1 Kings 18 - WEBU]] | [[1 Kings 20 - WEBU]] →

**1** Ahab told Jezebel all that Elijah had done, and how he had killed all the prophets with the sword. ^1

**2** Then Jezebel sent a messenger to Elijah, saying, “So let the gods do to me, and more also, if I don’t make your life as the life of one of them by tomorrow about this time!” ^2

**3** When he saw that, he arose and ran for his life, and came to Beersheba, which belongs to Judah, and left his servant there. ^3

**4** But he himself went a day’s journey into the wilderness, and came and sat down under a juniper tree. Then he requested for himself that he might die, and said, “It is enough. Now, O LORD, take away my life; for I am not better than my fathers.” ^4

**5** He lay down and slept under a juniper tree; and behold, an angel touched him, and said to him, “Arise and eat!” ^5

**6** He looked, and behold, there was at his head a cake baked on the coals, and a jar of water. He ate and drank, and lay down again. ^6

**7** The LORD’s angel came again the second time, and touched him, and said, “Arise and eat, because the journey is too great for you.” ^7

**8** He arose, and ate and drank, and went in the strength of that food forty days and forty nights to Horeb, God’s Mountain. ^8

**9** He came to a cave there, and camped there; and behold, the LORD’s word came to him, and he said to him, “What are you doing here, Elijah?” ^9

**10** He said, “I have been very jealous for the LORD, the God of Armies; for the children of Israel have forsaken your covenant, thrown down your altars, and killed your prophets with the sword. I, even I only, am left; and they seek my life, to take it away.” ^10

**11** He said, “Go out and stand on the mountain before the LORD.” Behold, the LORD passed by, and a great and strong wind tore the mountains and broke in pieces the rocks before the LORD; but the LORD was not in the wind. After the wind there was an earthquake; but the LORD was not in the earthquake. ^11

**12** After the earthquake a fire passed; but the LORD was not in the fire. After the fire, there was a still small voice. ^12

**13** When Elijah heard it, he wrapped his face in his mantle, went out, and stood in the entrance of the cave. Behold, a voice came to him, and said, “What are you doing here, Elijah?” ^13

**14** He said, “I have been very jealous for the LORD, the God of Armies; for the children of Israel have forsaken your covenant, thrown down your altars, and killed your prophets with the sword. I, even I only, am left; and they seek my life, to take it away.” ^14

**15** The LORD said to him, “Go, return on your way to the wilderness of Damascus. When you arrive, anoint Hazael to be king over Syria. ^15

**16** Anoint Jehu the son of Nimshi to be king over Israel; and anoint Elisha the son of Shaphat of Abel Meholah to be prophet in your place. ^16

**17** He who escapes from the sword of Hazael, Jehu will kill; and he who escapes from the sword of Jehu, Elisha will kill. ^17

**18** Yet I reserved seven thousand in Israel, all the knees of which have not bowed to Baal, and every mouth that has not kissed him.” ^18

**19** So he departed from there and found Elisha the son of Shaphat, who was plowing with twelve yoke of oxen before him, and he with the twelfth. Elijah went over to him and put his mantle on him. ^19

**20** Elisha left the oxen and ran after Elijah, and said, “Let me please kiss my father and my mother, and then I will follow you.” He said to him, “Go back again; for what have I done to you?” ^20

**21** He returned from following him, and took the yoke of oxen, killed them, and boiled their meat with the oxen’s equipment, and gave to the people; and they ate. Then he arose, and went after Elijah, and served him. ^21

← [[1 Kings 18 - WEBU]] | [[1 Kings 20 - WEBU]] →
