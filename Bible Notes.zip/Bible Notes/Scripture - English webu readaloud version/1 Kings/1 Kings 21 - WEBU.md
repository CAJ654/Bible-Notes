---
book: 1 Kings
chapter: 21
version: WEBU
---
# 1 Kings 21 (WEBU)

← [[1 Kings 20 - WEBU]] | [[1 Kings 22 - WEBU]] →

**1** After these things, Naboth the Jezreelite had a vineyard which was in Jezreel, next to the palace of Ahab king of Samaria. ^1

**2** Ahab spoke to Naboth, saying, “Give me your vineyard, that I may have it for a garden of herbs, because it is near my house; and I will give you for it a better vineyard than it. Or, if it seems good to you, I will give you its worth in money.” ^2

**3** Naboth said to Ahab, “May the LORD forbid me, that I should give the inheritance of my fathers to you!” ^3

**4** Ahab came into his house sullen and angry because of the word which Naboth the Jezreelite had spoken to him, for he had said, “I will not give you the inheritance of my fathers.” He laid himself down on his bed, and turned away his face, and would eat no bread. ^4

**5** But Jezebel his wife came to him, and said to him, “Why is your spirit so sad that you eat no bread?” ^5

**6** He said to her, “Because I spoke to Naboth the Jezreelite, and said to him, ‘Give me your vineyard for money; or else, if it pleases you, I will give you another vineyard for it.’ He answered, ‘I will not give you my vineyard.’” ^6

**7** Jezebel his wife said to him, “Do you now govern the kingdom of Israel? Arise, and eat bread, and let your heart be merry. I will give you the vineyard of Naboth the Jezreelite.” ^7

**8** So she wrote letters in Ahab’s name and sealed them with his seal, and sent the letters to the elders and to the nobles who were in his city, who lived with Naboth. ^8

**9** She wrote in the letters, saying, “Proclaim a fast, and set Naboth on high among the people. ^9

**10** Set two men, wicked fellows, before him, and let them testify against him, saying, ‘You cursed God and the king!’ Then carry him out, and stone him to death.” ^10

**11** The men of his city, even the elders and the nobles who lived in his city, did as Jezebel had instructed them in the letters which she had written and sent to them. ^11

**12** They proclaimed a fast, and set Naboth on high among the people. ^12

**13** The two men, the wicked fellows, came in and sat before him. The wicked fellows testified against him, even against Naboth, in the presence of the people, saying, “Naboth cursed God and the king!” Then they carried him out of the city and stoned him to death with stones. ^13

**14** Then they sent to Jezebel, saying, “Naboth has been stoned and is dead.” ^14

**15** When Jezebel heard that Naboth had been stoned and was dead, Jezebel said to Ahab, “Arise, take possession of the vineyard of Naboth the Jezreelite, which he refused to give you for money; for Naboth is not alive, but dead.” ^15

**16** When Ahab heard that Naboth was dead, Ahab rose up to go down to the vineyard of Naboth the Jezreelite, to take possession of it. ^16

**17** The LORD’s word came to Elijah the Tishbite, saying, ^17

**18** “Arise, go down to meet Ahab king of Israel, who dwells in Samaria. Behold, he is in the vineyard of Naboth, where he has gone down to take possession of it. ^18

**19** You shall speak to him, saying, ‘The LORD says, “Have you killed and also taken possession?”’ You shall speak to him, saying, ‘The LORD says, “In the place where dogs licked the blood of Naboth, dogs will lick your blood, even yours.”’” ^19

**20** Ahab said to Elijah, “Have you found me, my enemy?” He answered, “I have found you, because you have sold yourself to do that which is evil in the LORD’s sight. ^20

**21** Behold, I will bring evil on you, and will utterly sweep you away and will cut off from Ahab everyone who urinates against a wall, and him who is shut up and him who is left at large in Israel. ^21

**22** I will make your house like the house of Jeroboam the son of Nebat, and like the house of Baasha the son of Ahijah, for the provocation with which you have provoked me to anger, and have made Israel to sin.” ^22

**23** The LORD also spoke of Jezebel, saying, “The dogs will eat Jezebel by the rampart of Jezreel. ^23

**24** The dogs will eat whoever dies of Ahab in the city; and the birds of the sky will eat whoever dies in the field.” ^24

**25** But there was no one like Ahab, who sold himself to do that which was evil in the LORD’s sight, whom Jezebel his wife stirred up. ^25

**26** He did very abominably in following idols, according to all that the Amorites did, whom the LORD cast out before the children of Israel. ^26

**27** When Ahab heard those words, he tore his clothes, put sackcloth on his body, fasted, lay in sackcloth, and went about despondently. ^27

**28** The LORD’s word came to Elijah the Tishbite, saying, ^28

**29** “See how Ahab humbles himself before me? Because he humbles himself before me, I will not bring the evil in his days; but I will bring the evil on his house in his son’s day.” ^29

← [[1 Kings 20 - WEBU]] | [[1 Kings 22 - WEBU]] →
