---
book: 1 Kings
chapter: 20
version: WEBU
---
# 1 Kings 20 (WEBU)

← [[1 Kings 19 - WEBU]] | [[1 Kings 21 - WEBU]] →

**1** Ben Hadad the king of Syria gathered all his army together; and there were thirty-two kings with him, with horses and chariots. He went up and besieged Samaria, and fought against it. ^1

**2** He sent messengers into the city to Ahab king of Israel and said to him, “Ben Hadad says, ^2

**3** ‘Your silver and your gold are mine. Your wives also and your children, even the best, are mine.’” ^3

**4** The king of Israel answered, “It is according to your saying, my lord, O king. I am yours, and all that I have.” ^4

**5** The messengers came again and said, “Ben Hadad says, ‘I sent indeed to you, saying, “You shall deliver me your silver, your gold, your wives, and your children; ^5

**6** but I will send my servants to you tomorrow about this time, and they will search your house and the houses of your servants. Whatever is pleasant in your eyes, they will put it in their hand, and take it away.”’” ^6

**7** Then the king of Israel called all the elders of the land, and said, “Please notice how this man seeks mischief; for he sent to me for my wives, and for my children, and for my silver, and for my gold; and I didn’t deny him.” ^7

**8** All the elders and all the people said to him, “Don’t listen, and don’t consent.” ^8

**9** Therefore he said to the messengers of Ben Hadad, “Tell my lord the king, ‘All that you sent for to your servant at the first I will do, but this thing I cannot do.’” The messengers departed and brought him back the message. ^9

**10** Ben Hadad sent to him, and said, “The gods do so to me, and more also, if the dust of Samaria will be enough for handfuls for all the people who follow me.” ^10

**11** The king of Israel answered, “Tell him, ‘Don’t let him who puts on his armor brag like he who takes it off.’” ^11

**12** When Ben Hadad heard this message as he was drinking, he and the kings in the pavilions, he said to his servants, “Prepare to attack!” So they prepared to attack the city. ^12

**13** Behold, a prophet came near to Ahab king of Israel, and said, “The LORD says, ‘Have you seen all this great multitude? Behold, I will deliver it into your hand today. Then you will know that I am the LORD.’” ^13

**14** Ahab said, “By whom?” He said, “The LORD says, ‘By the young men of the princes of the provinces.’” Then he said, “Who shall begin the battle?” He answered, “You.” ^14

**15** Then he mustered the young men of the princes of the provinces, and they were two hundred and thirty-two. After them, he mustered all the people, even all the children of Israel, being seven thousand. ^15

**16** They went out at noon. But Ben Hadad was drinking himself drunk in the pavilions, he and the kings, the thirty-two kings who helped him. ^16

**17** The young men of the princes of the provinces went out first; and Ben Hadad sent out, and they told him, saying, “Men are coming out from Samaria.” ^17

**18** He said, “If they have come out for peace, take them alive; or if they have come out for war, take them alive.” ^18

**19** So these went out of the city, the young men of the princes of the provinces, and the army which followed them. ^19

**20** They each killed his man. The Syrians fled, and Israel pursued them. Ben Hadad the king of Syria escaped on a horse with horsemen. ^20

**21** The king of Israel went out and struck the horses and chariots, and killed the Syrians with a great slaughter. ^21

**22** The prophet came near to the king of Israel and said to him, “Go, strengthen yourself, and plan what you must do, for at the return of the year, the king of Syria will come up against you.” ^22

**23** The servants of the king of Syria said to him, “Their god is a god of the hills; therefore they were stronger than we. But let’s fight against them in the plain, and surely we will be stronger than they. ^23

**24** Do this thing: take the kings away, every man out of his place, and put captains in their place. ^24

**25** Muster an army like the army that you have lost, horse for horse and chariot for chariot. We will fight against them in the plain, and surely we will be stronger than they are.” He listened to their voice and did so. ^25

**26** At the return of the year, Ben Hadad mustered the Syrians and went up to Aphek to fight against Israel. ^26

**27** The children of Israel were mustered and given provisions, and went against them. The children of Israel encamped before them like two little flocks of young goats, but the Syrians filled the country. ^27

**28** A man of God came near and spoke to the king of Israel, and said, “The LORD says, ‘Because the Syrians have said, “The LORD is a god of the hills, but he is not a god of the valleys,” therefore I will deliver all this great multitude into your hand, and you shall know that I am the LORD.’” ^28

**29** They encamped opposite each other for seven days. Then on the seventh day the battle was joined; and the children of Israel killed one hundred thousand footmen of the Syrians in one day. ^29

**30** But the rest fled to Aphek, into the city; and the wall fell on twenty-seven thousand men who were left. Ben Hadad fled and came into the city, into an inner room. ^30

**31** His servants said to him, “See now, we have heard that the kings of the house of Israel are merciful kings. Please let us put sackcloth on our bodies and ropes on our heads, and go out to the king of Israel. Maybe he will save your life.” ^31

**32** So they put sackcloth on their bodies and ropes on their heads, and came to the king of Israel, and said, “Your servant Ben Hadad says, ‘Please let me live.’” He said, “Is he still alive? He is my brother.” ^32

**33** Now the men observed diligently and hurried to take this phrase; and they said, “Your brother Ben Hadad.” Then he said, “Go, bring him.” Then Ben Hadad came out to him; and he caused him to come up into the chariot. ^33

**34** Ben Hadad said to him, “The cities which my father took from your father I will restore. You shall make streets for yourself in Damascus, as my father made in Samaria.” “I”, said Ahab, “will let you go with this covenant.” So he made a covenant with him and let him go. ^34

**35** A certain man of the sons of the prophets said to his fellow by the LORD’s word, “Please strike me!” The man refused to strike him. ^35

**36** Then he said to him, “Because you have not obeyed the LORD’s voice, behold, as soon as you have departed from me, a lion will kill you.” As soon as he had departed from him, a lion found him and killed him. ^36

**37** Then he found another man, and said, “Please strike me.” The man struck him and wounded him. ^37

**38** So the prophet departed and waited for the king by the way, and disguised himself with his headband over his eyes. ^38

**39** As the king passed by, he cried to the king, and he said, “Your servant went out into the middle of the battle; and behold, a man came over and brought a man to me, and said, ‘Guard this man! If by any means he is missing, then your life shall be for his life, or else you shall pay a talent of silver.’ ^39

**40** As your servant was busy here and there, he was gone.” The king of Israel said to him, “So shall your judgment be. You yourself have decided it.” ^40

**41** He hurried, and took the headband away from his eyes; and the king of Israel recognized that he was one of the prophets. ^41

**42** He said to him, “The LORD says, ‘Because you have let go out of your hand the man whom I had devoted to destruction, therefore your life will take the place of his life, and your people take the place of his people.’” ^42

**43** The king of Israel went to his house sullen and angry, and came to Samaria. ^43

← [[1 Kings 19 - WEBU]] | [[1 Kings 21 - WEBU]] →
