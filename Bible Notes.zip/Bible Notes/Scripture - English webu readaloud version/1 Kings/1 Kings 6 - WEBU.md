---
book: 1 Kings
chapter: 6
version: WEBU
---
# 1 Kings 6 (WEBU)

← [[1 Kings 5 - WEBU]] | [[1 Kings 7 - WEBU]] →

**1** In the four hundred and eightieth year after the children of Israel had come out of the land of Egypt, in the fourth year of Solomon’s reign over Israel, in the month Ziv, which is the second month, he began to build the LORD’s house. ^1

**2** The house which King Solomon built for the LORD had a length of sixty cubits, and its width twenty, and its height thirty cubits. ^2

**3** The porch in front of the temple of the house had a length of twenty cubits, which was along the width of the house. Ten cubits was its width in front of the house. ^3

**4** He made windows of fixed lattice work for the house. ^4

**5** Against the wall of the house, he built floors all around, against the walls of the house all around, both of the temple and of the inner sanctuary; and he made side rooms all around. ^5

**6** The lowest floor was five cubits wide, and the middle was six cubits wide, and the third was seven cubits wide; for on the outside he made offsets in the wall of the house all around, that the beams should not be inserted into the walls of the house. ^6

**7** The house, when it was under construction, was built of stone prepared at the quarry; and no hammer or ax or any tool of iron was heard in the house while it was under construction. ^7

**8** The door for the middle side rooms was in the right side of the house. They went up by winding stairs into the middle floor, and out of the middle into the third. ^8

**9** So he built the house and finished it; and he covered the house with beams and planks of cedar. ^9

**10** He built the floors all along the house, each five cubits high; and they rested on the house with timbers of cedar. ^10

**11** The LORD’s word came to Solomon, saying, ^11

**12** “Concerning this house which you are building, if you will walk in my statutes, and execute my ordinances, and keep all my commandments to walk in them, then I will establish my word with you, which I spoke to David your father. ^12

**13** I will dwell among the children of Israel, and will not forsake my people Israel.” ^13

**14** So Solomon built the house and finished it. ^14

**15** He built the walls of the house within with boards of cedar; from the floor of the house to the walls of the ceiling, he covered them on the inside with wood. He covered the floor of the house with cypress boards. ^15

**16** He built twenty cubits of the back part of the house with boards of cedar from the floor to the ceiling. He built this within, for an inner sanctuary, even for the most holy place. ^16

**17** In front of the temple sanctuary was forty cubits long. ^17

**18** There was cedar on the house within, carved with buds and open flowers. All was cedar. No stone was visible. ^18

**19** He prepared an inner sanctuary in the middle of the house within, to set the ark of the LORD’s covenant there. ^19

**20** Within the inner sanctuary was twenty cubits in length, and twenty cubits in width, and twenty cubits in its height. He overlaid it with pure gold. He covered the altar with cedar. ^20

**21** So Solomon overlaid the house within with pure gold. He drew chains of gold across before the inner sanctuary, and he overlaid it with gold. ^21

**22** He overlaid the whole house with gold, until all the house was finished. He also overlaid the whole altar that belonged to the inner sanctuary with gold. ^22

**23** In the inner sanctuary he made two cherubim of olive wood, each ten cubits high. ^23

**24** Five cubits was the length of one wing of the cherub, and five cubits was the length of the other wing of the cherub. From the tip of one wing to the tip of the other was ten cubits. ^24

**25** The other cherub was ten cubits. Both the cherubim were of one measure and one form. ^25

**26** One cherub was ten cubits high, and so was the other cherub. ^26

**27** He set the cherubim within the inner house. The wings of the cherubim were stretched out, so that the wing of the one touched the one wall and the wing of the other cherub touched the other wall; and their wings touched one another in the middle of the house. ^27

**28** He overlaid the cherubim with gold. ^28

**29** He carved all the walls of the house around with carved figures of cherubim, palm trees, and open flowers, inside and outside. ^29

**30** He overlaid the floor of the house with gold, inside and outside. ^30

**31** For the entrance of the inner sanctuary, he made doors of olive wood. The lintel and door posts were a fifth part of the wall. ^31

**32** So he made two doors of olive wood; and he carved on them carvings of cherubim, palm trees, and open flowers, and overlaid them with gold. He spread the gold on the cherubim and on the palm trees. ^32

**33** He also made the entrance of the temple door posts of olive wood, out of a fourth part of the wall, ^33

**34** and two doors of cypress wood. The two leaves of the one door were folding, and the two leaves of the other door were folding. ^34

**35** He carved cherubim, palm trees, and open flowers; and he overlaid them with gold fitted on the engraved work. ^35

**36** He built the inner court with three courses of cut stone and a course of cedar beams. ^36

**37** The foundation of the LORD’s house was laid in the fourth year, in the month Ziv. ^37

**38** In the eleventh year, in the month Bul, which is the eighth month, the house was finished throughout all its parts and according to all its specifications. So he spent seven years building it. ^38

← [[1 Kings 5 - WEBU]] | [[1 Kings 7 - WEBU]] →
