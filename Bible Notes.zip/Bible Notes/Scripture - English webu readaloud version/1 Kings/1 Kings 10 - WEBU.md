---
book: 1 Kings
chapter: 10
version: WEBU
---
# 1 Kings 10 (WEBU)

← [[1 Kings 9 - WEBU]] | [[1 Kings 11 - WEBU]] →

**1** When the queen of Sheba heard of the fame of Solomon concerning the LORD’s name, she came to test him with hard questions. ^1

**2** She came to Jerusalem with a very great caravan, with camels that bore spices, very much gold, and precious stones; and when she had come to Solomon, she talked with him about all that was in her heart. ^2

**3** Solomon answered all her questions. There wasn’t anything hidden from the king which he didn’t tell her. ^3

**4** When the queen of Sheba had seen all the wisdom of Solomon, the house that he had built, ^4

**5** the food of his table, the sitting of his servants, the attendance of his officials, their clothing, his cup bearers, and his ascent by which he went up to the LORD’s house, there was no more spirit in her. ^5

**6** She said to the king, “It was a true report that I heard in my own land of your acts and of your wisdom. ^6

**7** However, I didn’t believe the words until I came and my eyes had seen it. Behold, not even half was told me! Your wisdom and prosperity exceed the fame which I heard. ^7

**8** Happy are your men, happy are these your servants who stand continually before you, who hear your wisdom. ^8

**9** Blessed is the LORD your God, who delighted in you, to set you on the throne of Israel. Because the LORD loved Israel forever, therefore he made you king, to do justice and righteousness.” ^9

**10** She gave the king one hundred twenty talents of gold, and a very great quantity of spices, and precious stones. Never again was there such an abundance of spices as these which the queen of Sheba gave to King Solomon. ^10

**11** The fleet of Hiram that brought gold from Ophir also brought in from Ophir great quantities of almug trees and precious stones. ^11

**12** The king made of the almug trees pillars for the LORD’s house and for the king’s house, harps also and stringed instruments for the singers; no such almug trees came or were seen to this day. ^12

**13** King Solomon gave to the queen of Sheba all her desire, whatever she asked, in addition to that which Solomon gave her of his royal bounty. So she turned and went to her own land, she and her servants. ^13

**14** Now the weight of gold that came to Solomon in one year was six hundred sixty-six talents of gold, ^14

**15** in addition to that which the traders brought, and the traffic of the merchants, and of all the kings of the mixed people, and of the governors of the country. ^15

**16** King Solomon made two hundred bucklers of beaten gold; six hundred shekels of gold went to one buckler. ^16

**17** He made three hundred shields of beaten gold; three minas of gold went to one shield; and the king put them in the House of the Forest of Lebanon. ^17

**18** Moreover the king made a great throne of ivory, and overlaid it with the finest gold. ^18

**19** There were six steps to the throne, and the top of the throne was round behind; and there were armrests on either side by the place of the seat, and two lions standing beside the armrests. ^19

**20** Twelve lions stood there on the one side and on the other on the six steps. Nothing like it was made in any kingdom. ^20

**21** All King Solomon’s drinking vessels were of gold, and all the vessels of the House of the Forest of Lebanon were of pure gold. None were of silver, because it was considered of little value in the days of Solomon. ^21

**22** For the king had a fleet of ships of Tarshish at sea with Hiram’s fleet. Once every three years the fleet of Tarshish came bringing gold, silver, ivory, apes, and peacocks. ^22

**23** So King Solomon exceeded all the kings of the earth in riches and in wisdom. ^23

**24** All the earth sought the presence of Solomon to hear his wisdom which God had put in his heart. ^24

**25** Year after year, every man brought his tribute, vessels of silver, vessels of gold, clothing, armor, spices, horses, and mules. ^25

**26** Solomon gathered together chariots and horsemen. He had one thousand four hundred chariots and twelve thousand horsemen. He kept them in the chariot cities and with the king at Jerusalem. ^26

**27** The king made silver as common as stones in Jerusalem, and cedars as common as the sycamore trees that are in the lowland. ^27

**28** The horses which Solomon had were brought out of Egypt. The king’s merchants received them in droves, each drove at a price. ^28

**29** A chariot was imported from Egypt for six hundred shekels of silver, and a horse for one hundred fifty shekels; and so they exported them to all the kings of the Hittites and to the kings of Syria. ^29

← [[1 Kings 9 - WEBU]] | [[1 Kings 11 - WEBU]] →
