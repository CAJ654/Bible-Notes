---
book: 1 Kings
chapter: 3
version: WEBU
---
# 1 Kings 3 (WEBU)

← [[1 Kings 2 - WEBU]] | [[1 Kings 4 - WEBU]] →

**1** Solomon made a marriage alliance with Pharaoh king of Egypt. He took Pharaoh’s daughter and brought her into David’s city until he had finished building his own house, the LORD’s house, and the wall around Jerusalem. ^1

**2** However, the people sacrificed in the high places, because there was not yet a house built for the LORD’s name. ^2

**3** Solomon loved the LORD, walking in the statutes of David his father, except that he sacrificed and burned incense in the high places. ^3

**4** The king went to Gibeon to sacrifice there, for that was the great high place. Solomon offered a thousand burnt offerings on that altar. ^4

**5** In Gibeon, the LORD appeared to Solomon in a dream by night; and God said, “Ask for what I should give you.” ^5

**6** Solomon said, “You have shown to your servant David my father great loving kindness, because he walked before you in truth, in righteousness, and in uprightness of heart with you. You have kept for him this great loving kindness, that you have given him a son to sit on his throne, as it is today. ^6

**7** Now, LORD my God, you have made your servant king instead of David my father. I am just a little child. I don’t know how to go out or come in. ^7

**8** Your servant is among your people which you have chosen, a great people, that can’t be numbered or counted for multitude. ^8

**9** Give your servant therefore an understanding heart to judge your people, that I may discern between good and evil; for who is able to judge this great people of yours?” ^9

**10** This request pleased the Lord, that Solomon had asked this thing. ^10

**11** God said to him, “Because you have asked this thing, and have not asked for yourself long life, nor have you asked for riches for yourself, nor have you asked for the life of your enemies, but have asked for yourself understanding to discern justice, ^11

**12** behold, I have done according to your word. Behold, I have given you a wise and understanding heart, so that there has been no one like you before you, and after you none will arise like you. ^12

**13** I have also given you that which you have not asked, both riches and honor, so that there will not be any among the kings like you for all your days. ^13

**14** If you will walk in my ways, to keep my statutes and my commandments, as your father David walked, then I will lengthen your days.” ^14

**15** Solomon awoke; and behold, it was a dream. Then he came to Jerusalem and stood before the ark of the LORD’s covenant, and offered up burnt offerings, offered peace offerings, and made a feast for all his servants. ^15

**16** Then two women who were prostitutes came to the king, and stood before him. ^16

**17** The one woman said, “Oh, my lord, I and this woman dwell in one house. I delivered a child with her in the house. ^17

**18** The third day after I delivered, this woman delivered also. We were together. There was no stranger with us in the house, just us two in the house. ^18

**19** This woman’s child died in the night, because she lay on it. ^19

**20** She arose at midnight, and took my son from beside me while your servant slept, and laid it in her bosom, and laid her dead child in my bosom. ^20

**21** When I rose in the morning to nurse my child, behold, he was dead; but when I had looked at him in the morning, behold, it was not my son whom I bore.” ^21

**22** The other woman said, “No! But the living one is my son, and the dead one is your son.” The first one said, “No! But the dead one is your son, and the living one is my son.” They argued like this before the king. ^22

**23** Then the king said, “One says, ‘This is my son who lives, and your son is the dead one;’ and the other says, ‘No! But your son is the dead one, and my son is the living one.’” ^23

**24** The king said, “Get me a sword.” So they brought a sword before the king. ^24

**25** The king said, “Divide the living child in two, and give half to the one, and half to the other.” ^25

**26** Then the woman whose the living child was spoke to the king, for her heart yearned over her son, and she said, “Oh, my lord, give her the living child, and in no way kill him!” But the other said, “He shall be neither mine nor yours. Divide him.” ^26

**27** Then the king answered, “Give the first woman the living child, and definitely do not kill him. She is his mother.” ^27

**28** All Israel heard of the judgment which the king had judged; and they feared the king, for they saw that the wisdom of God was in him to do justice. ^28

← [[1 Kings 2 - WEBU]] | [[1 Kings 4 - WEBU]] →
