---
book: 1 Kings
chapter: 17
version: WEBU
---
# 1 Kings 17 (WEBU)

← [[1 Kings 16 - WEBU]] | [[1 Kings 18 - WEBU]] →

**1** Elijah the Tishbite, who was one of the settlers of Gilead, said to Ahab, “As the LORD, the God of Israel, lives, before whom I stand, there shall not be dew nor rain these years, but according to my word.” ^1

**2** Then the LORD’s word came to him, saying, ^2

**3** “Go away from here, turn eastward, and hide yourself by the brook Cherith, that is before the Jordan. ^3

**4** You shall drink from the brook. I have commanded the ravens to feed you there.” ^4

**5** So he went and did according to the LORD’s word, for he went and lived by the brook Cherith that is before the Jordan. ^5

**6** The ravens brought him bread and meat in the morning, and bread and meat in the evening; and he drank from the brook. ^6

**7** After a while, the brook dried up, because there was no rain in the land. ^7

**8** The LORD’s word came to him, saying, ^8

**9** “Arise, go to Zarephath, which belongs to Sidon, and stay there. Behold, I have commanded a widow there to sustain you.” ^9

**10** So he arose and went to Zarephath; and when he came to the gate of the city, behold, a widow was there gathering sticks. He called to her and said, “Please get me a little water in a jar, that I may drink.” ^10

**11** As she was going to get it, he called to her and said, “Please bring me a morsel of bread in your hand.” ^11

**12** She said, “As the LORD your God lives, I don’t have anything baked, but only a handful of meal in a jar and a little oil in a jar. Behold, I am gathering two sticks, that I may go in and bake it for me and my son, that we may eat it, and die.” ^12

**13** Elijah said to her, “Don’t be afraid. Go and do as you have said; but make me a little cake from it first, and bring it out to me, and afterward make some for you and for your son. ^13

**14** For the LORD, the God of Israel, says, ‘The jar of meal will not run out, and the jar of oil will not fail, until the day that the LORD sends rain on the earth.’” ^14

**15** She went and did according to the saying of Elijah; and she, he, and her household ate many days. ^15

**16** The jar of meal didn’t run out and the jar of oil didn’t fail, according to the LORD’s word, which he spoke by Elijah. ^16

**17** After these things, the son of the woman, the mistress of the house, became sick; and his sickness was so severe that there was no breath left in him. ^17

**18** She said to Elijah, “What have I to do with you, you man of God? You have come to me to bring my sin to memory, and to kill my son!” ^18

**19** He said to her, “Give me your son.” He took him out of her bosom, and carried him up into the room where he stayed, and laid him on his own bed. ^19

**20** He cried to the LORD and said, “LORD my God, have you also brought evil on the widow with whom I am staying, by killing her son?” ^20

**21** He stretched himself on the child three times, and cried to the LORD and said, “LORD my God, please let this child’s soul come into him again.” ^21

**22** The LORD listened to the voice of Elijah; and the soul of the child came into him again, and he revived. ^22

**23** Elijah took the child and brought him down out of the room into the house, and delivered him to his mother; and Elijah said, “Behold, your son lives.” ^23

**24** The woman said to Elijah, “Now I know that you are a man of God, and that the LORD’s word in your mouth is truth.” ^24

← [[1 Kings 16 - WEBU]] | [[1 Kings 18 - WEBU]] →
