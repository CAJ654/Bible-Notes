---
book: 1 Kings
chapter: 1
version: WEBU
---
# 1 Kings 1 (WEBU)

[[1 Kings 2 - WEBU]] →

**1** Now King David was old and advanced in years; and they covered him with clothes, but he couldn’t keep warm. ^1

**2** Therefore his servants said to him, “Let a young virgin be sought for my lord the king. Let her stand before the king, and cherish him; and let her lie in your bosom, that my lord the king may keep warm.” ^2

**3** So they sought for a beautiful young lady throughout all the borders of Israel, and found Abishag the Shunammite, and brought her to the king. ^3

**4** The young lady was very beautiful; and she cherished the king, and served him; but the king didn’t know her intimately. ^4

**5** Then Adonijah the son of Haggith exalted himself, saying, “I will be king.” Then he prepared him chariots and horsemen, and fifty men to run before him. ^5

**6** His father had not displeased him at any time in saying, “Why have you done so?” and he was also a very handsome man; and he was born after Absalom. ^6

**7** He conferred with Joab the son of Zeruiah and with Abiathar the priest; and they followed Adonijah and helped him. ^7

**8** But Zadok the priest, Benaiah the son of Jehoiada, Nathan the prophet, Shimei, Rei, and the mighty men who belonged to David, were not with Adonijah. ^8

**9** Adonijah killed sheep, cattle, and fatlings by the stone of Zoheleth, which is beside En Rogel; and he called all his brothers, the king’s sons, and all the men of Judah, the king’s servants; ^9

**10** but he didn’t call Nathan the prophet, and Benaiah, and the mighty men, and Solomon his brother. ^10

**11** Then Nathan spoke to Bathsheba the mother of Solomon, saying, “Haven’t you heard that Adonijah the son of Haggith reigns, and David our lord doesn’t know it? ^11

**12** Now therefore come, please let me give you counsel, that you may save your own life and your son Solomon’s life. ^12

**13** Go in to King David, and tell him, ‘Didn’t you, my lord the king, swear to your servant, saying, “Assuredly Solomon your son shall reign after me, and he shall sit on my throne”? Why then does Adonijah reign?’ ^13

**14** Behold, while you are still talking there with the king, I will also come in after you and confirm your words.” ^14

**15** Bathsheba went in to the king in his room. The king was very old; and Abishag the Shunammite was serving the king. ^15

**16** Bathsheba bowed and showed respect to the king. The king said, “What would you like?” ^16

**17** She said to him, “My lord, you swore by the LORD your God to your servant, ‘Assuredly Solomon your son shall reign after me, and he shall sit on my throne.’ ^17

**18** Now, behold, Adonijah reigns; and you, my lord the king, don’t know it. ^18

**19** He has slain cattle and fatlings and sheep in abundance, and has called all the sons of the king, Abiathar the priest, and Joab the captain of the army; but he hasn’t called Solomon your servant. ^19

**20** You, my lord the king, the eyes of all Israel are on you, that you should tell them who will sit on the throne of my lord the king after him. ^20

**21** Otherwise it will happen, when my lord the king sleeps with his fathers, that I and my son Solomon will be considered criminals.” ^21

**22** Behold, while she was still talking with the king, Nathan the prophet came in. ^22

**23** They told the king, saying, “Behold, Nathan the prophet!” When he had come in before the king, he bowed himself before the king with his face to the ground. ^23

**24** Nathan said, “My lord, King, have you said, ‘Adonijah shall reign after me, and he shall sit on my throne’? ^24

**25** For he has gone down today, and has slain cattle, fatlings, and sheep in abundance, and has called all the king’s sons, the captains of the army, and Abiathar the priest. Behold, they are eating and drinking before him, and saying, ‘Long live King Adonijah!’ ^25

**26** But he hasn’t called me, even me your servant, Zadok the priest, Benaiah the son of Jehoiada, and your servant Solomon. ^26

**27** Was this thing done by my lord the king, and you haven’t shown to your servants who should sit on the throne of my lord the king after him?” ^27

**28** Then King David answered, “Call Bathsheba in to me.” She came into the king’s presence and stood before the king. ^28

**29** The king vowed and said, “As the LORD lives, who has redeemed my soul out of all adversity, ^29

**30** most certainly as I swore to you by the LORD, the God of Israel, saying, ‘Assuredly Solomon your son shall reign after me, and he shall sit on my throne in my place;’ I will most certainly do this today.” ^30

**31** Then Bathsheba bowed with her face to the earth and showed respect to the king, and said, “Let my lord King David live forever!” ^31

**32** King David said, “Call to me Zadok the priest, Nathan the prophet, and Benaiah the son of Jehoiada.” They came before the king. ^32

**33** The king said to them, “Take with you the servants of your lord, and cause Solomon my son to ride on my own mule, and bring him down to Gihon. ^33

**34** Let Zadok the priest and Nathan the prophet anoint him there king over Israel. Blow the trumpet, and say, ‘Long live King Solomon!’ ^34

**35** Then come up after him, and he shall come and sit on my throne; for he shall be king in my place. I have appointed him to be prince over Israel and over Judah.” ^35

**36** Benaiah the son of Jehoiada answered the king, and said, “Amen. May the LORD, the God of my lord the king, say so. ^36

**37** As the LORD has been with my lord the king, even so may he be with Solomon, and make his throne greater than the throne of my lord King David.” ^37

**38** So Zadok the priest, Nathan the prophet, Benaiah the son of Jehoiada, and the Cherethites and the Pelethites went down and had Solomon ride on King David’s mule, and brought him to Gihon. ^38

**39** Zadok the priest took the horn of oil from the Tent, and anointed Solomon. They blew the trumpet; and all the people said, “Long live King Solomon!” ^39

**40** All the people came up after him, and the people piped with pipes, and rejoiced with great joy, so that the earth shook with their sound. ^40

**41** Adonijah and all the guests who were with him heard it as they had finished eating. When Joab heard the sound of the trumpet, he said, “Why is this noise of the city being in an uproar?” ^41

**42** While he yet spoke, behold, Jonathan the son of Abiathar the priest came; and Adonijah said, “Come in; for you are a worthy man, and bring good news.” ^42

**43** Jonathan answered Adonijah, “Most certainly our lord King David has made Solomon king. ^43

**44** The king has sent with him Zadok the priest, Nathan the prophet, Benaiah the son of Jehoiada, and the Cherethites and the Pelethites; and they have caused him to ride on the king’s mule. ^44

**45** Zadok the priest and Nathan the prophet have anointed him king in Gihon. They have come up from there rejoicing, so that the city rang again. This is the noise that you have heard. ^45

**46** Also, Solomon sits on the throne of the kingdom. ^46

**47** Moreover the king’s servants came to bless our lord King David, saying, ‘May your God make the name of Solomon better than your name, and make his throne greater than your throne;’ and the king bowed himself on the bed. ^47

**48** Also thus said the king, ‘Blessed be the LORD, the God of Israel, who has given one to sit on my throne today, my eyes even seeing it.’” ^48

**49** All the guests of Adonijah were afraid, and rose up, and each man went his way. ^49

**50** Adonijah was afraid because of Solomon; and he arose, and went, and hung onto the horns of the altar. ^50

**51** Solomon was told, “Behold, Adonijah fears King Solomon; for, behold, he is hanging onto the horns of the altar, saying, ‘Let King Solomon swear to me first that he will not kill his servant with the sword.’” ^51

**52** Solomon said, “If he shows himself a worthy man, not a hair of his shall fall to the earth; but if wickedness is found in him, he shall die.” ^52

**53** So King Solomon sent, and they brought him down from the altar. He came and bowed down to King Solomon; and Solomon said to him, “Go to your house.” ^53

[[1 Kings 2 - WEBU]] →
